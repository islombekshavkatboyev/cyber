"""
Payment webhooks — Click, Payme, Humo callbacklarni qabul qilish.
"""
from fastapi import APIRouter, Request, HTTPException, Header
from loguru import logger
from typing import Optional

from bot.config import settings

router = APIRouter(prefix="/webhook/payment", tags=["payments"])


# ══════════════════════════════════════════════════════════
# CLICK WEBHOOKS
# ══════════════════════════════════════════════════════════
@router.post("/click/prepare")
async def click_prepare(request: Request):
    """Click PREPARE webhook (action=0)"""
    data = await request.form()
    data_dict = dict(data)
    logger.info(f"[Click] Prepare: {data_dict.get('merchant_trans_id')}")

    from payment.providers.click import ClickProvider
    provider = ClickProvider(
        service_id=settings.click_service_id,
        merchant_id=settings.click_merchant_id,
        secret_key=settings.click_secret_key,
    )

    # Imzoni tekshirish
    if not provider.verify_webhook(data_dict):
        return {"error": -1, "error_note": "Noto'g'ri imzo"}

    order_id = data_dict.get("merchant_trans_id", "")

    # Buyurtma mavjudligini tekshirish
    from database.db_manager import DBManager
    async with DBManager() as db:
        order = await db.orders.get_by_id(order_id)
        if not order:
            return {"error": -5, "error_note": "Buyurtma topilmadi"}

    return provider.handle_prepare(data_dict)


@router.post("/click/complete")
async def click_complete(request: Request):
    """Click COMPLETE webhook (action=1)"""
    data = await request.form()
    data_dict = dict(data)
    logger.info(f"[Click] Complete: {data_dict.get('merchant_trans_id')}")

    from payment.providers.click import ClickProvider
    provider = ClickProvider(
        service_id=settings.click_service_id,
        merchant_id=settings.click_merchant_id,
        secret_key=settings.click_secret_key,
    )

    if not provider.verify_webhook(data_dict):
        return {"error": -1, "error_note": "Noto'g'ri imzo"}

    order_id = data_dict.get("merchant_trans_id", "")
    click_trans_id = data_dict.get("click_trans_id", "")

    error = int(data_dict.get("error", "0"))
    if error < 0:
        logger.warning(f"[Click] To'lov bekor: {error}")
        return provider.handle_complete(data_dict)

    # To'lov muvaffaqiyatli — DB yangilash va generatsiya boshlash
    await _process_successful_payment(
        order_id=order_id,
        transaction_id=click_trans_id,
        provider="click",
        provider_data=data_dict,
    )

    return provider.handle_complete(data_dict)


# ══════════════════════════════════════════════════════════
# PAYME WEBHOOKS (JSON-RPC 2.0)
# ══════════════════════════════════════════════════════════
@router.post("/payme")
async def payme_webhook(
    request: Request,
    authorization: Optional[str] = Header(None),
):
    """Payme JSON-RPC webhook"""
    from payment.providers.payme import PaymeProvider

    provider = PaymeProvider(
        merchant_id=settings.payme_merchant_id,
        key=settings.payme_key,
    )

    # Auth tekshirish
    if not authorization or not provider.verify_rpc_auth(authorization):
        raise HTTPException(status_code=401, detail="Unauthorized")

    body = await request.json()
    method = body.get("method", "")
    params = body.get("params", {})
    request_id = body.get("id", 1)

    logger.info(f"[Payme] Method: {method}")

    result = None
    error = None

    try:
        if method == "CheckPerformTransaction":
            result = provider.handle_check_perform_transaction(params)

        elif method == "CreateTransaction":
            result = provider.handle_create_transaction(params)

        elif method == "PerformTransaction":
            # To'lov tasdiqlandi
            result = provider.handle_perform_transaction(params)
            order_id = params.get("account", {}).get("order_id", "")
            trans_id = params.get("id", "")
            if order_id:
                await _process_successful_payment(
                    order_id=order_id,
                    transaction_id=trans_id,
                    provider="payme",
                    provider_data=params,
                )

        elif method == "CancelTransaction":
            result = provider.handle_cancel_transaction(params)

        elif method == "CheckTransaction":
            result = provider.handle_check_transaction(params)

        else:
            error = {"code": -32601, "message": "Method not found"}

    except Exception as e:
        logger.error(f"[Payme] Xatolik: {e}")
        error = {"code": -31001, "message": str(e)}

    response = {"jsonrpc": "2.0", "id": request_id}
    if error:
        response["error"] = error
    else:
        response["result"] = result

    return response


# ══════════════════════════════════════════════════════════
# HUMO WEBHOOKS
# ══════════════════════════════════════════════════════════
@router.post("/humo")
async def humo_webhook(
    request: Request,
    x_signature: Optional[str] = Header(None, alias="X-Signature"),
):
    """Humo payment webhook"""
    from payment.providers.humo import HumoProvider

    body = await request.json()
    logger.info(f"[Humo] Webhook: {body.get('status')}")

    provider = HumoProvider(
        merchant_id=settings.humo_merchant_id,
        secret_key=settings.humo_secret_key,
        api_url=settings.humo_api_url,
    )

    # Imzo tekshirish
    if x_signature and not provider.verify_webhook(body, x_signature):
        raise HTTPException(status_code=400, detail="Noto'g'ri imzo")

    status = body.get("status", "")
    if status in ("PAID", "SUCCESS", "COMPLETED"):
        order_id = body.get("order_id", "")
        invoice_id = body.get("invoice_id", "")
        if order_id:
            await _process_successful_payment(
                order_id=order_id,
                transaction_id=invoice_id,
                provider="humo",
                provider_data=body,
            )

    return {"status": "ok"}


# ══════════════════════════════════════════════════════════
# UMUMIY TO'LOV QAYTA ISHLASH
# ══════════════════════════════════════════════════════════
async def _process_successful_payment(
    order_id: str,
    transaction_id: str,
    provider: str,
    provider_data: dict,
):
    """To'lov muvaffaqiyatli — DB yangilash va generatsiya boshlash"""
    from database.db_manager import DBManager
    from workers.tasks.generation import generate_document

    logger.info(f"[Payment] Muvaffaqiyatli: order_id={order_id} provider={provider}")

    async with DBManager() as db:
        # Payment topish
        payment = await db.payments.get_by_order_id(order_id)
        if payment and payment.status != "paid":
            await db.payments.mark_paid(
                payment_id=payment.id,
                transaction_id=transaction_id,
                provider_response=provider_data,
            )

        # Order holatini yangilash
        order = await db.orders.get_by_id(order_id)
        if order and order.status in ("pending", "cancelled"):
            await db.orders.update_status(order_id, "paid")

    # Generatsiya boshlash
    generate_document.delay(order_id)
    logger.info(f"[Payment] Generatsiya navbatga qo'yildi: {order_id}")
