"""
Admin API — statistika va boshqaruv endpointlari.
"""
from fastapi import APIRouter, Depends, HTTPException, Header
from typing import Optional

from bot.config import settings

router = APIRouter(prefix="/admin", tags=["admin"])


def verify_admin_token(x_admin_token: Optional[str] = Header(None)):
    if x_admin_token != settings.api_secret_key:
        raise HTTPException(status_code=403, detail="Forbidden")
    return True


@router.get("/stats", dependencies=[Depends(verify_admin_token)])
async def get_stats():
    from database.db_manager import DBManager
    from locales.i18n import format_price

    async with DBManager() as db:
        return {
            "users": {
                "total": await db.users.count_total(),
                "today": await db.users.count_today(),
                "active_today": await db.users.count_active_today(),
            },
            "orders": {
                "today": await db.orders.count_today(),
                "pending": await db.orders.count_by_status("pending"),
                "processing": await db.orders.count_by_status("processing"),
                "completed": await db.orders.count_by_status("completed"),
                "failed": await db.orders.count_by_status("failed"),
                "by_service": await db.orders.count_by_service_today(),
            },
            "payments": {
                "revenue_today": float(await db.payments.sum_revenue_today()),
                "revenue_total": float(await db.payments.sum_revenue_total()),
                "active": await db.payments.count_active_payments(),
                "by_provider": await db.payments.count_by_provider_today(),
            },
        }


@router.get("/orders", dependencies=[Depends(verify_admin_token)])
async def get_orders(limit: int = 20, offset: int = 0):
    from database.db_manager import DBManager

    async with DBManager() as db:
        orders = await db.orders.get_recent_for_admin(limit=limit, offset=offset)
        return [
            {
                "id": str(o.id),
                "service_type": o.service_type,
                "topic": o.topic,
                "status": o.status,
                "price": float(o.price),
                "created_at": o.created_at.isoformat(),
                "user_telegram_id": o.user.telegram_id if o.user else None,
            }
            for o in orders
        ]


@router.get("/payments", dependencies=[Depends(verify_admin_token)])
async def get_payments(limit: int = 20, offset: int = 0):
    from database.db_manager import DBManager

    async with DBManager() as db:
        payments = await db.payments.get_recent_for_admin(limit=limit, offset=offset)
        return [
            {
                "id": str(p.id),
                "provider": p.provider,
                "amount": float(p.amount),
                "status": p.status,
                "created_at": p.created_at.isoformat(),
                "paid_at": p.paid_at.isoformat() if p.paid_at else None,
            }
            for p in payments
        ]


@router.post("/orders/{order_id}/resend", dependencies=[Depends(verify_admin_token)])
async def resend_order_files(order_id: str):
    """Buyurtma fayllarini qayta yuborish"""
    from workers.tasks.notification import send_order_notification
    from database.db_manager import DBManager

    async with DBManager() as db:
        order = await db.orders.get_by_id_with_user(order_id)
        if not order:
            raise HTTPException(status_code=404, detail="Buyurtma topilmadi")
        if not order.file_url_docx and not order.file_url_pptx:
            raise HTTPException(status_code=400, detail="Fayllar mavjud emas")

    from workers.tasks.generation import generate_document
    # Fayllar mavjud bo'lsa to'g'ri foydalanuvchiga qayta yuborish
    # Yoki generatsiyani qayta boshlash
    generate_document.delay(order_id)
    return {"status": "queued", "order_id": order_id}


@router.post("/orders/{order_id}/retry", dependencies=[Depends(verify_admin_token)])
async def retry_order(order_id: str):
    """Muvaffaqiyatsiz buyurtmani qayta generatsiya qilish"""
    from workers.tasks.generation import generate_document
    generate_document.delay(order_id)
    return {"status": "queued", "order_id": order_id}
