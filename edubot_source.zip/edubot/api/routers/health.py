from fastapi import APIRouter
from datetime import datetime

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check():
    return {"status": "ok", "time": datetime.utcnow().isoformat()}


@router.get("/")
async def root():
    return {"service": "EduBot API", "version": "1.0.0"}
