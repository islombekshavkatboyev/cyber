"""
FastAPI application — payment webhooks va admin API.

CRASH #3 FIX: sentry_sdk.init() was called at module level, before logging
was configured and before the environment was fully available. Moved into
the lifespan startup hook.
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger

from bot.config import settings
from api.routers import payments, admin, health


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup va shutdown"""
    logger.info("FastAPI ishga tushmoqda...")

    # Sentry — initialised here, not at module level
    if settings.sentry_dsn:
        import sentry_sdk
        sentry_sdk.init(dsn=settings.sentry_dsn, traces_sample_rate=0.1)
        logger.info("Sentry ulandi (FastAPI)")

    # DB init — safety net for local dev.
    # In production, `migrate` service runs `alembic upgrade head` first.
    from database.connection import init_db
    await init_db()

    yield

    logger.info("FastAPI to'xtatilmoqda...")


app = FastAPI(
    title="EduBot API",
    version="1.0.0",
    docs_url="/docs" if settings.log_level == "DEBUG" else None,
    redoc_url=None,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(payments.router)
app.include_router(admin.router)
