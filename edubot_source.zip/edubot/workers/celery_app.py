"""
Celery application — task queue konfiguratsiyasi.
"""
from celery import Celery
from celery.schedules import crontab

from bot.config import settings

app = Celery(
    "edubot",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=[
        "workers.tasks.generation",
        "workers.tasks.notification",
        "workers.tasks.cleanup",
    ],
)

# ─── Celery konfiguratsiyasi ──────────────────────────────
app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Asia/Tashkent",
    enable_utc=True,

    # Task navbatlari
    task_queues={
        "generation": {"exchange": "generation", "routing_key": "generation"},
        "notifications": {"exchange": "notifications", "routing_key": "notifications"},
        "default": {"exchange": "default", "routing_key": "default"},
    },
    task_default_queue="default",
    task_routes={
        "workers.tasks.generation.*": {"queue": "generation"},
        "workers.tasks.notification.*": {"queue": "notifications"},
        "workers.tasks.cleanup.*": {"queue": "default"},
    },

    # Retry sozlamalari
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    worker_prefetch_multiplier=1,

    # Timeout
    task_soft_time_limit=600,   # 10 daqiqa soft limit
    task_time_limit=900,        # 15 daqiqa hard limit

    # Result expiry
    result_expires=3600,
)

# ─── Davriy tasklar (Beat) ────────────────────────────────
app.conf.beat_schedule = {
    # Muddati o'tgan to'lovlarni tekshirish — har 5 daqiqada
    "check-expired-payments": {
        "task": "workers.tasks.cleanup.expire_old_payments",
        "schedule": crontab(minute="*/5"),
    },
    # Eski fayllarni o'chirish — har kuni yarim tunda
    "cleanup-old-files": {
        "task": "workers.tasks.cleanup.cleanup_old_files",
        "schedule": crontab(hour=0, minute=0),
    },
}
