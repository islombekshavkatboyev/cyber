"""
Generation task — asosiy hujjat generatsiya Celery taski.

FIX #5: GenerationTask._bot was a class-level singleton that reused a single
Bot instance across Celery tasks. asyncio.run() creates a NEW event loop each
call, so the old Bot's aiohttp ClientSession (bound to the previous loop)
becomes invalid and raises "Session is closed" on the second task.
Fix: create a fresh Bot per asyncio.run() call inside the async helper, and
always close it in a finally block.

FIX #14: Removed unused top-level imports: os, uuid, datetime.
"""
import asyncio

from celery import Task
from loguru import logger

from workers.celery_app import app


class GenerationTask(Task):
    """Base task class — no longer holds a Bot singleton."""
    abstract = True


@app.task(
    bind=True,
    base=GenerationTask,
    name="workers.tasks.generation.generate_document",
    max_retries=3,
    default_retry_delay=60,
    queue="generation",
)
def generate_document(self, order_id: str):
    """
    Asosiy generatsiya taski.
    Celery sinxron, lekin AI async — asyncio.run() bilan ishga tushiramiz.
    """
    logger.info(f"[Task] generate_document boshlandi: order_id={order_id}")

    try:
        asyncio.run(_generate_document_async(order_id))
    except Exception as exc:
        logger.error(f"[Task] Xatolik order_id={order_id}: {exc}")
        try:
            raise self.retry(exc=exc, countdown=60 * (self.request.retries + 1))
        except self.MaxRetriesExceededError:
            asyncio.run(_mark_failed(order_id, str(exc)))


async def _make_bot():
    """
    FIX #5: Always create a fresh Bot instance inside the current event loop.
    Never reuse a Bot across asyncio.run() calls — the underlying aiohttp
    ClientSession is loop-bound and will error on reuse.
    """
    from aiogram import Bot
    from aiogram.client.default import DefaultBotProperties
    from aiogram.enums import ParseMode
    from bot.config import settings

    return Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )


async def _generate_document_async(order_id: str):
    """Async generatsiya logikasi"""
    from ai.context_builder import GenerationContext
    from ai.orchestrator import AIOrchestrator
    from database.db_manager import DBManager
    from generators.docx_generator import DocxGenerator
    from generators.pdf_converter import PdfConverter
    from generators.pptx_generator import PptxGenerator
    from storage.s3_client import get_s3_client

    bot = await _make_bot()

    try:
        async with DBManager() as db:
            order = await db.orders.get_by_id_with_user(order_id)
            if not order:
                logger.error(f"[Task] Buyurtma topilmadi: {order_id}")
                return

            if order.status == "completed":
                logger.info(f"[Task] Buyurtma allaqachon tugallangan: {order_id}")
                return

            await db.orders.update_status(order_id, "processing")

            try:
                await bot.send_message(
                    chat_id=order.user.telegram_id,
                    text="🤖 <b>Hujjat tayyorlanmoqda...</b>\n\nIltimos, kuting. Bu biroz vaqt olishi mumkin.",
                    parse_mode="HTML",
                )
            except Exception:
                pass

        # Re-fetch after commit so relationships are accessible
        async with DBManager() as db:
            order = await db.orders.get_by_id_with_user(order_id)

        ctx = GenerationContext.from_order(order)

        logger.info(f"[Task] AI generatsiya: {order.service_type}")
        orchestrator = AIOrchestrator()
        result = await orchestrator.generate(ctx)

        s3 = get_s3_client()
        safe_topic = "".join(c for c in order.topic[:30] if c.isalnum() or c in " -_")
        base_filename = f"{order.service_type}_{safe_topic}_{order_id[:8]}"

        file_url_docx = None
        file_url_pdf = None
        file_url_pptx = None

        if order.service_type == "presentation":
            pptx_gen = PptxGenerator()
            pptx_bytes = pptx_gen.generate(ctx, result)
            obj_name = s3.make_object_name(order_id, f"{base_filename}.pptx")
            s3.upload_bytes(pptx_bytes, obj_name, s3.get_content_type(".pptx"))
            file_url_pptx = obj_name
            logger.info(f"[Task] PPTX yuklandi: {obj_name}")
        else:
            docx_gen = DocxGenerator()
            docx_bytes = docx_gen.generate(ctx, result)
            obj_name_docx = s3.make_object_name(order_id, f"{base_filename}.docx")
            s3.upload_bytes(docx_bytes, obj_name_docx, s3.get_content_type(".docx"))
            file_url_docx = obj_name_docx
            logger.info(f"[Task] DOCX yuklandi: {obj_name_docx}")

            pdf_conv = PdfConverter()
            pdf_bytes = pdf_conv.convert_sync(docx_bytes, base_filename)
            if pdf_bytes:
                obj_name_pdf = s3.make_object_name(order_id, f"{base_filename}.pdf")
                s3.upload_bytes(pdf_bytes, obj_name_pdf, s3.get_content_type(".pdf"))
                file_url_pdf = obj_name_pdf
                logger.info(f"[Task] PDF yuklandi: {obj_name_pdf}")

        async with DBManager() as db:
            await db.orders.update_files(
                order_id=order_id,
                file_url_docx=file_url_docx,
                file_url_pdf=file_url_pdf,
                file_url_pptx=file_url_pptx,
            )
            await db.orders.update_status(order_id, "completed")

        await _send_files_to_user(
            bot=bot,
            telegram_id=order.user.telegram_id,
            order_id=order_id,
            service_type=order.service_type,
            file_url_docx=file_url_docx,
            file_url_pdf=file_url_pdf,
            file_url_pptx=file_url_pptx,
            s3=s3,
        )

        logger.info(f"[Task] Muvaffaqiyatli tugadi: order_id={order_id}")

    finally:
        await bot.session.close()


async def _send_files_to_user(
    bot,
    telegram_id: int,
    order_id: str,
    service_type: str,
    file_url_docx,
    file_url_pdf,
    file_url_pptx,
    s3,
):
    """Fayllarni Telegram orqali yuborish"""
    from aiogram.types import BufferedInputFile
    from locales.i18n import t

    try:
        await bot.send_message(
            chat_id=telegram_id,
            text=t("order.completed"),
            parse_mode="HTML",
        )

        if file_url_docx:
            docx_bytes = s3.download_bytes(file_url_docx)
            filename = f"{service_type}_{order_id[:8]}.docx"
            await bot.send_document(
                chat_id=telegram_id,
                document=BufferedInputFile(docx_bytes, filename=filename),
                caption="📄 DOCX fayl",
            )

        if file_url_pdf:
            pdf_bytes = s3.download_bytes(file_url_pdf)
            filename = f"{service_type}_{order_id[:8]}.pdf"
            await bot.send_document(
                chat_id=telegram_id,
                document=BufferedInputFile(pdf_bytes, filename=filename),
                caption="📋 PDF fayl",
            )

        if file_url_pptx:
            pptx_bytes = s3.download_bytes(file_url_pptx)
            filename = f"{service_type}_{order_id[:8]}.pptx"
            await bot.send_document(
                chat_id=telegram_id,
                document=BufferedInputFile(pptx_bytes, filename=filename),
                caption="📊 PowerPoint fayl",
            )

        # Baholash so'rovi
        from aiogram.utils.keyboard import InlineKeyboardBuilder
        builder = InlineKeyboardBuilder()
        for i in range(1, 6):
            stars = "⭐" * i
            builder.button(text=stars, callback_data=f"rate:{i}:{order_id}")
        builder.adjust(5)

        await bot.send_message(
            chat_id=telegram_id,
            text=t("order.rate_prompt"),
            reply_markup=builder.as_markup(),
            parse_mode="HTML",
        )

    except Exception as e:
        logger.error(f"[Task] Fayl yuborishda xato telegram_id={telegram_id}: {e}")


async def _mark_failed(order_id: str, error: str):
    """Buyurtmani muvaffaqiyatsiz deb belgilash va xabardor qilish"""
    from database.db_manager import DBManager
    from locales.i18n import t
    from bot.keyboards.service_menu import retry_order_kb
    from bot.config import settings

    bot = await _make_bot()

    try:
        async with DBManager() as db:
            order = await db.orders.get_by_id_with_user(order_id)
            if order:
                await db.orders.mark_failed(order_id, error)

                try:
                    await bot.send_message(
                        chat_id=order.user.telegram_id,
                        text=t("order.failed"),
                        reply_markup=retry_order_kb(order_id),
                        parse_mode="HTML",
                    )
                except Exception:
                    pass

                for admin_id in settings.admin_ids:
                    try:
                        await bot.send_message(
                            chat_id=admin_id,
                            text=(
                                f"❌ <b>Generatsiya muvaffaqiyatsiz!</b>\n\n"
                                f"Order ID: <code>{order_id}</code>\n"
                                f"Xizmat: {order.service_type}\n"
                                f"Mavzu: {order.topic[:50]}\n"
                                f"Xato: {error[:200]}"
                            ),
                            parse_mode="HTML",
                        )
                    except Exception:
                        pass
    finally:
        await bot.session.close()
