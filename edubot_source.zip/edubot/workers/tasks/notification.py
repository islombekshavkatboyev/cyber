"""
Notification tasks — Telegram xabar yuborish tasklari.
"""
import asyncio

from loguru import logger

from workers.celery_app import app


@app.task(
    name="workers.tasks.notification.broadcast_message",
    queue="notifications",
    max_retries=2,
)
def broadcast_message(text: str, parse_mode: str = "HTML"):
    """Barcha aktiv foydalanuvchilarga xabar yuborish"""
    asyncio.run(_broadcast_async(text, parse_mode))


async def _broadcast_async(text: str, parse_mode: str):
    from aiogram import Bot
    from bot.config import settings
    from database.db_manager import DBManager

    bot = Bot(token=settings.bot_token)
    sent = 0
    failed = 0

    try:
        async with DBManager() as db:
            users = await db.users.get_all_active(limit=10000)

        logger.info(f"[Broadcast] {len(users)} ta foydalanuvchiga yuborilmoqda")

        for user in users:
            try:
                await bot.send_message(
                    chat_id=user.telegram_id,
                    text=text,
                    parse_mode=parse_mode,
                )
                sent += 1
                # Anti-flood: har 30 ta xabardan keyin 1 soniya kutish
                if sent % 30 == 0:
                    await asyncio.sleep(1)
            except Exception as e:
                failed += 1
                logger.debug(f"[Broadcast] {user.telegram_id} xato: {e}")

        logger.info(f"[Broadcast] Tugadi: yuborildi={sent}, xato={failed}")

        # Adminlarga natija
        for admin_id in settings.admin_ids:
            try:
                await bot.send_message(
                    chat_id=admin_id,
                    text=f"📢 Broadcast tugadi!\n✅ Yuborildi: {sent}\n❌ Xato: {failed}",
                )
            except Exception:
                pass

    finally:
        await bot.session.close()


@app.task(
    name="workers.tasks.notification.send_order_notification",
    queue="notifications",
)
def send_order_notification(telegram_id: int, message: str, parse_mode: str = "HTML"):
    """Bitta foydalanuvchiga xabar"""
    asyncio.run(_send_single(telegram_id, message, parse_mode))


async def _send_single(telegram_id: int, message: str, parse_mode: str):
    from aiogram import Bot
    from bot.config import settings

    bot = Bot(token=settings.bot_token)
    try:
        await bot.send_message(
            chat_id=telegram_id,
            text=message,
            parse_mode=parse_mode,
        )
    except Exception as e:
        logger.error(f"[Notify] {telegram_id} ga yuborishda xato: {e}")
    finally:
        await bot.session.close()
