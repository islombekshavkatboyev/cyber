"""
Cleanup tasks — muddati o'tgan to'lovlar va eski fayllarni tozalash.
"""
import asyncio
from datetime import datetime, timedelta

from loguru import logger

from workers.celery_app import app


@app.task(
    name="workers.tasks.cleanup.expire_old_payments",
    queue="default",
)
def expire_old_payments():
    """Muddati o'tgan pending to'lovlarni expired deb belgilash"""
    asyncio.run(_expire_payments_async())


async def _expire_payments_async():
    from database.db_manager import DBManager

    async with DBManager() as db:
        expired = await db.payments.get_expired_pending()

        count = 0
        for payment in expired:
            await db.payments.mark_expired(payment.id)
            # Agar buyurtma hali pending bo'lsa — cancelled ga o'tkazish
            order = await db.orders.get_by_id(payment.order_id)
            if order and order.status == "pending":
                await db.orders.update_status(payment.order_id, "cancelled")
            count += 1

        if count:
            logger.info(f"[Cleanup] {count} ta muddati o'tgan to'lov expired qilindi")


@app.task(
    name="workers.tasks.cleanup.cleanup_old_files",
    queue="default",
)
def cleanup_old_files():
    """
    FILE_EXPIRY_DAYS kundan eski S3 fayllarni o'chirish.
    DB dagi file_url larni ham tozalash.
    """
    asyncio.run(_cleanup_files_async())


async def _cleanup_files_async():
    from database.db_manager import DBManager
    from storage.s3_client import get_s3_client
    from bot.config import settings
    from sqlalchemy import select
    from database.models import Order

    expiry_date = datetime.utcnow() - timedelta(days=settings.file_expiry_days)
    s3 = get_s3_client()

    async with DBManager() as db:
        # Eski, tugallangan buyurtmalar
        result = await db._session.execute(
            select(Order)
            .where(
                Order.status == "completed",
                Order.completed_at < expiry_date,
                Order.file_url_docx.isnot(None),
            )
            .limit(100)
        )
        orders = result.scalars().all()

        cleaned = 0
        for order in orders:
            try:
                s3.delete_order_files(str(order.id))
                # DB dan fayl URL larni tozalash
                await db.orders.update_files(
                    order_id=str(order.id),
                    file_url_docx=None,
                    file_url_pdf=None,
                    file_url_pptx=None,
                )
                cleaned += 1
            except Exception as e:
                logger.warning(f"[Cleanup] {order.id} tozalashda xato: {e}")

        if cleaned:
            logger.info(f"[Cleanup] {cleaned} ta eski buyurtma fayllari o'chirildi")
