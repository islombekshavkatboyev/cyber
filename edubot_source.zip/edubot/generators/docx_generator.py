"""
DocxGenerator — Professional akademik DOCX fayl generatori.

Standartlar:
- O'zbekiston GOST (OzDSt) va xalqaro akademik format
- Times New Roman 14pt
- 1.5 interval
- Chegaralar: yuqori/pastki 2sm, chap 3sm, o'ng 1.5sm
- Sahifa raqamlari (pastki markaz)
- Muqova sahifasi
- Mundarija
"""
import io
import re
from datetime import datetime
from typing import Optional

from docx import Document
from docx.enum.section import WD_ORIENTATION
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from loguru import logger

from ai.context_builder import GenerationContext


class DocxGenerator:

    # ─── Standart sozlamalar ──────────────────────────────
    FONT_NAME = "Times New Roman"
    FONT_SIZE = Pt(14)
    FONT_SIZE_HEADING1 = Pt(14)
    FONT_SIZE_HEADING2 = Pt(14)
    FONT_SIZE_SMALL = Pt(12)

    MARGIN_TOP = Cm(2.0)
    MARGIN_BOTTOM = Cm(2.0)
    MARGIN_LEFT = Cm(3.0)
    MARGIN_RIGHT = Cm(1.5)

    def generate(self, ctx: GenerationContext, text: str) -> bytes:
        """
        Matndan professional DOCX fayl yaratish.
        Returns: DOCX fayl bytes
        """
        logger.info(f"[DOCX] Generatsiya boshlandi: {ctx.topic[:40]}")

        doc = Document()
        self._setup_document(doc)

        # 1. Muqova sahifasi
        if ctx.university_format:
            self._add_title_page(doc, ctx)
            self._add_page_break(doc)

        # 2. Mundarija placeholder
        if ctx.university_format and ctx.service_type in ("course_work", "diploma"):
            self._add_toc_placeholder(doc)
            self._add_page_break(doc)

        # 3. Asosiy matn
        self._add_content(doc, text, ctx)

        # 4. Sahifa raqamlari
        self._add_page_numbers(doc)

        # Fayl bytes ga saqlash
        buffer = io.BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        result = buffer.read()

        logger.info(f"[DOCX] Tayyor: {len(result)} bytes")
        return result

    # ══════════════════════════════════════════════════════
    # SAHIFA SOZLAMALARI
    # ══════════════════════════════════════════════════════
    def _setup_document(self, doc: Document):
        """A4 o'lcham, chegaralar, default stil"""
        section = doc.sections[0]
        section.page_width = Cm(21.0)
        section.page_height = Cm(29.7)
        section.top_margin = self.MARGIN_TOP
        section.bottom_margin = self.MARGIN_BOTTOM
        section.left_margin = self.MARGIN_LEFT
        section.right_margin = self.MARGIN_RIGHT

        # Normal stil
        style = doc.styles["Normal"]
        font = style.font
        font.name = self.FONT_NAME
        font.size = self.FONT_SIZE

        pf = style.paragraph_format
        pf.space_before = Pt(0)
        pf.space_after = Pt(6)
        pf.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE

    # ══════════════════════════════════════════════════════
    # MUQOVA SAHIFASI
    # ══════════════════════════════════════════════════════
    def _add_title_page(self, doc: Document, ctx: GenerationContext):
        """Rasmiy muqova sahifasi"""

        def center_para(text: str, bold: bool = False, size: int = 14) -> None:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(text)
            run.font.name = self.FONT_NAME
            run.font.size = Pt(size)
            run.bold = bold
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.space_before = Pt(4)

        def right_para(text: str, bold: bool = False) -> None:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            run = p.add_run(text)
            run.font.name = self.FONT_NAME
            run.font.size = self.FONT_SIZE
            run.bold = bold
            p.paragraph_format.space_after = Pt(4)

        # O'zbekiston Respublikasi
        center_para("O'ZBEKISTON RESPUBLIKASI")
        if ctx.university_name:
            center_para(ctx.university_name.upper(), bold=True)
        if ctx.faculty:
            center_para(ctx.faculty, bold=False)

        # Bo'sh joylar
        for _ in range(3):
            doc.add_paragraph()

        # Ish turi
        service_names = {
            "referat": "REFERAT",
            "independent": "MUSTAQIL ISH",
            "course_work": "KURS ISHI",
            "diploma": "BITIRUV MALAKAVIY ISH",
            "presentation": "PREZENTATSIYA",
        }
        service_label = service_names.get(ctx.service_type, "AKADEMIK ISH")

        # Til bo'yicha
        if ctx.doc_language == "ru":
            service_names_ru = {
                "referat": "РЕФЕРАТ",
                "independent": "САМОСТОЯТЕЛЬНАЯ РАБОТА",
                "course_work": "КУРСОВАЯ РАБОТА",
                "diploma": "ДИПЛОМНАЯ РАБОТА",
            }
            service_label = service_names_ru.get(ctx.service_type, service_label)
        elif ctx.doc_language == "en":
            service_names_en = {
                "referat": "ESSAY",
                "independent": "INDEPENDENT WORK",
                "course_work": "COURSE WORK",
                "diploma": "THESIS",
            }
            service_label = service_names_en.get(ctx.service_type, service_label)

        center_para(service_label, bold=True, size=16)

        # Fan nomi
        if ctx.subject:
            if ctx.doc_language == "uz":
                center_para(f"Fan: {ctx.subject}")
            elif ctx.doc_language == "ru":
                center_para(f"Дисциплина: {ctx.subject}")
            else:
                center_para(f"Subject: {ctx.subject}")

        # Mavzu
        doc.add_paragraph()
        if ctx.doc_language == "uz":
            center_para(f'Mavzu: "{ctx.topic}"', bold=True)
        elif ctx.doc_language == "ru":
            center_para(f'Тема: «{ctx.topic}»', bold=True)
        else:
            center_para(f'Topic: "{ctx.topic}"', bold=True)

        # Bo'sh joylar
        for _ in range(3):
            doc.add_paragraph()

        # Talaba/O'qituvchi ma'lumotlari (o'ng tomon)
        if ctx.doc_language == "uz":
            labels = {
                "student": "Bajardi",
                "group": "Guruh",
                "teacher": "Tekshirdi",
            }
        elif ctx.doc_language == "ru":
            labels = {
                "student": "Выполнил(а)",
                "group": "Группа",
                "teacher": "Проверил(а)",
            }
        else:
            labels = {
                "student": "Submitted by",
                "group": "Group",
                "teacher": "Supervisor",
            }

        if ctx.student_name:
            right_para(f"{labels['student']}: {ctx.student_name}")
        if ctx.group_number:
            right_para(f"{labels['group']}: {ctx.group_number}")
        if ctx.teacher_name:
            right_para(f"{labels['teacher']}: {ctx.teacher_name}")

        # Pastda yil
        for _ in range(4):
            doc.add_paragraph()

        city_year = f"Toshkent — {datetime.now().year}"
        if ctx.doc_language == "ru":
            city_year = f"Ташкент — {datetime.now().year}"
        elif ctx.doc_language == "en":
            city_year = f"Tashkent — {datetime.now().year}"

        center_para(city_year)

    # ══════════════════════════════════════════════════════
    # MUNDARIJA
    # ══════════════════════════════════════════════════════
    def _add_toc_placeholder(self, doc: Document):
        """Mundarija sahifasi"""
        # FIX #11: removed the dead toc_title dict that was assigned but never
        # referenced — it was inside a branch that always evaluated to True
        # (FONT_NAME is always "Times New Roman") and the dict was never used.
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("MUNDARIJA")
        run.font.name = self.FONT_NAME
        run.font.size = self.FONT_SIZE_HEADING1
        run.bold = True

        doc.add_paragraph()

        note = doc.add_paragraph()
        note_run = note.add_run(
            "[ Mundarija matn tayyor bo'lgandan so'ng Microsoft Word da "
            "avtomatik yangilash orqali to'ldiring: "
            "Havolalar → Mundarijani yangilash ]"
        )
        note_run.font.name = self.FONT_NAME
        note_run.font.size = Pt(11)
        note_run.italic = True
        note_run.font.color.rgb = RGBColor(0x88, 0x88, 0x88)

    # ══════════════════════════════════════════════════════
    # ASOSIY MATN
    # ══════════════════════════════════════════════════════
    def _add_content(self, doc: Document, text: str, ctx: GenerationContext):
        """Matnni parse qilib, DOCX formatida qo'shish"""
        lines = text.split("\n")

        for line in lines:
            stripped = line.strip()
            if not stripped:
                doc.add_paragraph()
                continue

            # Heading 1: # yoki BOB / ГЛАВА / CHAPTER / to'liq bosh harf
            if self._is_heading1(stripped):
                self._add_heading(doc, stripped, level=1)

            # Heading 2: ## yoki raqamli kichik bo'lim
            elif self._is_heading2(stripped):
                self._add_heading(doc, stripped, level=2)

            # Bullet point
            elif stripped.startswith(("-", "•", "*")) and len(stripped) > 2:
                self._add_bullet(doc, stripped[1:].strip())

            # Oddiy paragraf
            else:
                self._add_paragraph(doc, stripped)

    def _is_heading1(self, text: str) -> bool:
        if text.startswith("# "):
            return True
        upper = text.upper()
        keywords = ["BOB", "ГЛАВА", "CHAPTER", "KIRISH", "ВВЕДЕНИЕ", "INTRODUCTION",
                    "XULOSA", "ЗАКЛЮЧЕНИЕ", "CONCLUSION", "FOYDALANILGAN",
                    "СПИСОК", "REFERENCES", "ANNOTATSIYA", "АННОТАЦИЯ", "ABSTRACT",
                    "MUNDARIJA", "СОДЕРЖАНИЕ"]
        for kw in keywords:
            if upper.startswith(kw) and len(text) < 120:
                return True
        # Faqat bosh harf, 3-80 belgi
        if text.isupper() and 3 < len(text) < 80:
            return True
        return False

    def _is_heading2(self, text: str) -> bool:
        if text.startswith("## "):
            return True
        # 1.1, 2.3, I.1 kabi
        if re.match(r"^[IVX\d]+\.\d+[\s\.]", text):
            return True
        return False

    def _add_heading(self, doc: Document, text: str, level: int = 1):
        # Markdown # belgisini olib tashlash
        text = re.sub(r"^#+\s*", "", text).strip()

        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER if level == 1 else WD_ALIGN_PARAGRAPH.LEFT
        run = p.add_run(text)
        run.font.name = self.FONT_NAME
        run.font.size = self.FONT_SIZE_HEADING1 if level == 1 else self.FONT_SIZE_HEADING2
        run.bold = True
        p.paragraph_format.space_before = Pt(12)
        p.paragraph_format.space_after = Pt(6)

    def _add_paragraph(self, doc: Document, text: str):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        run = p.add_run(text)
        run.font.name = self.FONT_NAME
        run.font.size = self.FONT_SIZE
        p.paragraph_format.first_line_indent = Cm(1.25)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE

    def _add_bullet(self, doc: Document, text: str):
        p = doc.add_paragraph(style="List Bullet")
        run = p.add_run(text)
        run.font.name = self.FONT_NAME
        run.font.size = self.FONT_SIZE
        p.paragraph_format.left_indent = Cm(1.0)
        p.paragraph_format.space_after = Pt(2)

    # ══════════════════════════════════════════════════════
    # SAHIFA RAQAMLARI
    # ══════════════════════════════════════════════════════
    def _add_page_numbers(self, doc: Document):
        """Footer ga sahifa raqami qo'shish"""
        for section in doc.sections:
            footer = section.footer
            paragraph = footer.paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            paragraph.clear()

            run = paragraph.add_run()
            run.font.name = self.FONT_NAME
            run.font.size = Pt(12)

            # Word field: PAGE
            fldChar_begin = OxmlElement("w:fldChar")
            fldChar_begin.set(qn("w:fldCharType"), "begin")

            instrText = OxmlElement("w:instrText")
            instrText.set(qn("xml:space"), "preserve")
            instrText.text = "PAGE"

            fldChar_end = OxmlElement("w:fldChar")
            fldChar_end.set(qn("w:fldCharType"), "end")

            run._r.append(fldChar_begin)
            run._r.append(instrText)
            run._r.append(fldChar_end)

    @staticmethod
    def _add_page_break(doc: Document):
        doc.add_page_break()
