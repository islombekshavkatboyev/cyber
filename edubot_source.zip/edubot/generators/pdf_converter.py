"""
PdfConverter — DOCX → PDF konvertatsiya.
LibreOffice subprocess orqali (eng ishonchli usul).
"""
import asyncio
import os
import subprocess
import tempfile
from pathlib import Path

from loguru import logger

from bot.config import settings


class PdfConverter:

    LIBREOFFICE_CMD = "libreoffice"
    TIMEOUT = 120  # soniya

    async def convert(self, docx_bytes: bytes, filename: str = "document") -> bytes | None:
        """
        DOCX bytes → PDF bytes.
        LibreOffice CLI orqali konvertatsiya.

        Returns: PDF bytes yoki None (xatolik bo'lsa)
        """
        logger.info(f"[PDF] Konvertatsiya boshlandi: {filename}")

        temp_dir = Path(settings.temp_dir)
        temp_dir.mkdir(parents=True, exist_ok=True)

        # Vaqtinchalik fayllar
        docx_path = temp_dir / f"{filename}.docx"
        pdf_path = temp_dir / f"{filename}.pdf"

        try:
            # DOCX ni vaqtinchalik faylga yozish
            docx_path.write_bytes(docx_bytes)

            # LibreOffice orqali konvertatsiya
            success = await self._run_libreoffice(docx_path, temp_dir)

            if not success or not pdf_path.exists():
                logger.error(f"[PDF] LibreOffice konvertatsiya muvaffaqiyatsiz")
                return None

            pdf_bytes = pdf_path.read_bytes()
            logger.info(f"[PDF] Tayyor: {len(pdf_bytes)} bytes")
            return pdf_bytes

        except Exception as e:
            logger.error(f"[PDF] Xatolik: {e}")
            return None

        finally:
            # Vaqtinchalik fayllarni tozalash
            for path in [docx_path, pdf_path]:
                try:
                    if path.exists():
                        path.unlink()
                except Exception:
                    pass

    async def _run_libreoffice(self, docx_path: Path, output_dir: Path) -> bool:
        """LibreOffice ni subprocess sifatida ishga tushirish"""
        cmd = [
            self.LIBREOFFICE_CMD,
            "--headless",
            "--convert-to", "pdf",
            "--outdir", str(output_dir),
            str(docx_path),
        ]

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=self.TIMEOUT,
            )

            if process.returncode != 0:
                logger.error(
                    f"[PDF] LibreOffice xato: {stderr.decode()[:500]}"
                )
                return False

            return True

        except asyncio.TimeoutError:
            logger.error(f"[PDF] LibreOffice timeout ({self.TIMEOUT}s)")
            try:
                process.kill()
            except Exception:
                pass
            return False

        except FileNotFoundError:
            logger.error("[PDF] LibreOffice topilmadi! sudo apt install libreoffice")
            return False

    def convert_sync(self, docx_bytes: bytes, filename: str = "document") -> bytes | None:
        """Sinxron versiya (Celery worker uchun)"""
        temp_dir = Path(settings.temp_dir)
        temp_dir.mkdir(parents=True, exist_ok=True)

        docx_path = temp_dir / f"{filename}.docx"
        pdf_path = temp_dir / f"{filename}.pdf"

        try:
            docx_path.write_bytes(docx_bytes)

            cmd = [
                self.LIBREOFFICE_CMD,
                "--headless",
                "--convert-to", "pdf",
                "--outdir", str(temp_dir),
                str(docx_path),
            ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.TIMEOUT,
            )

            if result.returncode != 0:
                logger.error(f"[PDF] Xato: {result.stderr[:300]}")
                return None

            if not pdf_path.exists():
                return None

            return pdf_path.read_bytes()

        except subprocess.TimeoutExpired:
            logger.error("[PDF] Timeout")
            return None
        except Exception as e:
            logger.error(f"[PDF] Xatolik: {e}")
            return None
        finally:
            for path in [docx_path, pdf_path]:
                try:
                    if path.exists():
                        path.unlink()
                except Exception:
                    pass
