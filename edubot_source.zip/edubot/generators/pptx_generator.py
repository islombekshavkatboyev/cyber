"""
PptxGenerator — Professional PowerPoint prezentatsiya generatori.
AI dan kelgan slaydlar ro'yxatidan PPTX fayl yaratadi.
"""
import io
from typing import Optional

from loguru import logger
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Emu, Inches, Pt

from ai.context_builder import GenerationContext


# ─── Rang sxemasi ─────────────────────────────────────────
class Theme:
    PRIMARY = RGBColor(0x1A, 0x5F, 0x7A)       # To'q ko'k
    SECONDARY = RGBColor(0x57, 0xC5, 0xB6)     # Yashil-ko'k
    ACCENT = RGBColor(0xF4, 0xA2, 0x61)        # To'q sariq
    WHITE = RGBColor(0xFF, 0xFF, 0xFF)
    DARK = RGBColor(0x1C, 0x1C, 0x1C)
    LIGHT_BG = RGBColor(0xF0, 0xF4, 0xF8)
    GRAY = RGBColor(0x6C, 0x75, 0x7D)
    SLIDE_BG = RGBColor(0xFA, 0xFB, 0xFC)


class PptxGenerator:

    def generate(self, ctx: GenerationContext, slides_data: list[dict]) -> bytes:
        """
        Slaydlar ro'yxatidan PPTX fayl yaratish.
        Returns: PPTX fayl bytes
        """
        logger.info(
            f"[PPTX] Generatsiya boshlandi: {ctx.topic[:40]} "
            f"({len(slides_data)} slayd)"
        )

        prs = Presentation()

        # 16:9 format
        prs.slide_width = Emu(9_144_000)
        prs.slide_height = Emu(5_143_500)

        for slide_data in slides_data:
            slide_type = slide_data.get("type", "content")

            if slide_type == "title":
                self._add_title_slide(prs, slide_data, ctx)
            elif slide_type == "closing":
                self._add_closing_slide(prs, slide_data)
            else:
                self._add_content_slide(prs, slide_data)

        buffer = io.BytesIO()
        prs.save(buffer)
        buffer.seek(0)
        result = buffer.read()

        logger.info(f"[PPTX] Tayyor: {len(result)} bytes")
        return result

    # ══════════════════════════════════════════════════════
    # SARLAVHA SLAYD
    # ══════════════════════════════════════════════════════
    def _add_title_slide(
        self,
        prs: Presentation,
        data: dict,
        ctx: GenerationContext,
    ):
        slide_layout = prs.slide_layouts[6]  # Blank
        slide = prs.slides.add_slide(slide_layout)

        # Fon rangi
        self._set_slide_background(slide, Theme.PRIMARY)

        W = prs.slide_width
        H = prs.slide_height

        # Yuqori chiziq (accent)
        self._add_rectangle(
            slide,
            left=0, top=0,
            width=W, height=Emu(180_000),
            color=Theme.SECONDARY,
        )

        # Pastki chiziq
        self._add_rectangle(
            slide,
            left=0, top=H - Emu(200_000),
            width=W, height=Emu(200_000),
            color=Theme.SECONDARY,
        )

        # Asosiy mavzu sarlavhasi
        self._add_textbox(
            slide,
            text=data.get("title", ctx.topic),
            left=Inches(0.8), top=Inches(1.2),
            width=Inches(11.4), height=Inches(1.8),
            font_size=Pt(32),
            bold=True,
            color=Theme.WHITE,
            align=PP_ALIGN.CENTER,
        )

        # Talaba ma'lumotlari
        info_parts = []
        if data.get("author"):
            info_parts.append(data["author"])
        if data.get("group"):
            info_parts.append(data["group"])
        if data.get("subject"):
            info_parts.append(data["subject"])

        if info_parts:
            self._add_textbox(
                slide,
                text=" | ".join(info_parts),
                left=Inches(0.8), top=Inches(3.2),
                width=Inches(11.4), height=Inches(0.6),
                font_size=Pt(18),
                bold=False,
                color=Theme.SECONDARY,
                align=PP_ALIGN.CENTER,
            )

        # Universitet
        if data.get("university"):
            self._add_textbox(
                slide,
                text=data["university"],
                left=Inches(0.8), top=Inches(3.9),
                width=Inches(11.4), height=Inches(0.5),
                font_size=Pt(14),
                bold=False,
                color=Theme.WHITE,
                align=PP_ALIGN.CENTER,
            )

        # O'qituvchi
        if data.get("teacher"):
            self._add_textbox(
                slide,
                text=f"O'qituvchi: {data['teacher']}",
                left=Inches(0.8), top=Inches(4.4),
                width=Inches(11.4), height=Inches(0.4),
                font_size=Pt(13),
                bold=False,
                color=RGBColor(0xCC, 0xCC, 0xCC),
                align=PP_ALIGN.CENTER,
            )

        # Slayd raqami
        self._add_slide_number(slide, data.get("slide_num", 1), prs.slide_width, prs.slide_height)

    # ══════════════════════════════════════════════════════
    # KONTENT SLAYD
    # ══════════════════════════════════════════════════════
    def _add_content_slide(self, prs: Presentation, data: dict):
        slide_layout = prs.slide_layouts[6]  # Blank
        slide = prs.slides.add_slide(slide_layout)

        W = prs.slide_width
        H = prs.slide_height

        # Oq fon
        self._set_slide_background(slide, Theme.SLIDE_BG)

        # Yuqori chiziq (primary rang)
        self._add_rectangle(
            slide,
            left=0, top=0,
            width=W, height=Emu(420_000),
            color=Theme.PRIMARY,
        )

        # Sarlavha
        title = data.get("title", "")
        self._add_textbox(
            slide,
            text=title,
            left=Inches(0.4), top=Inches(0.05),
            width=Inches(12.2), height=Inches(0.65),
            font_size=Pt(22),
            bold=True,
            color=Theme.WHITE,
            align=PP_ALIGN.LEFT,
        )

        # Chap chiziq (accent)
        self._add_rectangle(
            slide,
            left=Inches(0.3), top=Inches(0.9),
            width=Emu(60_000), height=H - Emu(900_000),
            color=Theme.SECONDARY,
        )

        # Kontent (bullet points)
        content = data.get("content", [])
        if content:
            content_text = "\n".join(f"▸  {item}" for item in content[:6])
            self._add_textbox(
                slide,
                text=content_text,
                left=Inches(0.6), top=Inches(1.0),
                width=Inches(12.0), height=Inches(3.8),
                font_size=Pt(18),
                bold=False,
                color=Theme.DARK,
                align=PP_ALIGN.LEFT,
                line_spacing=Pt(32),
            )

        # Slayd raqami (pastki o'ng)
        self._add_slide_number(slide, data.get("slide_num", 1), W, H)

    # ══════════════════════════════════════════════════════
    # YOPISH SLAYD
    # ══════════════════════════════════════════════════════
    def _add_closing_slide(self, prs: Presentation, data: dict):
        slide_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(slide_layout)

        W = prs.slide_width
        H = prs.slide_height

        # Gradient fon (primary)
        self._set_slide_background(slide, Theme.PRIMARY)

        # Dekorativ doira
        self._add_rectangle(
            slide,
            left=W // 2 - Emu(800_000),
            top=H // 2 - Emu(800_000),
            width=Emu(1_600_000),
            height=Emu(1_600_000),
            color=Theme.SECONDARY,
            transparency=70,
        )

        # Asosiy matn
        self._add_textbox(
            slide,
            text=data.get("title", "Rahmat!"),
            left=Inches(1), top=Inches(1.5),
            width=Inches(11), height=Inches(1.5),
            font_size=Pt(40),
            bold=True,
            color=Theme.WHITE,
            align=PP_ALIGN.CENTER,
        )

        # Mavzu eslatma
        if data.get("subtitle"):
            self._add_textbox(
                slide,
                text=data["subtitle"],
                left=Inches(1), top=Inches(3.2),
                width=Inches(11), height=Inches(0.8),
                font_size=Pt(16),
                bold=False,
                color=Theme.SECONDARY,
                align=PP_ALIGN.CENTER,
            )

    # ══════════════════════════════════════════════════════
    # YORDAMCHI METODLAR
    # ══════════════════════════════════════════════════════
    @staticmethod
    def _set_slide_background(slide, color: RGBColor):
        """Slayd fon rangini o'rnatish"""
        fill = slide.background.fill
        fill.solid()
        fill.fore_color.rgb = color

    @staticmethod
    def _add_rectangle(
        slide,
        left: int,
        top: int,
        width: int,
        height: int,
        color: RGBColor,
        transparency: int = 0,
    ):
        """To'rtburchak shakl qo'shish"""
        shape = slide.shapes.add_shape(
            1,  # MSO_SHAPE_TYPE.RECTANGLE
            left, top, width, height,
        )
        fill = shape.fill
        fill.solid()
        fill.fore_color.rgb = color
        if transparency:
            fill.fore_color.theme_color = None
            shape.fill.fore_color.brightness = transparency / 100.0

        shape.line.fill.background()  # Chegarasiz

    @staticmethod
    def _add_textbox(
        slide,
        text: str,
        left: int,
        top: int,
        width: int,
        height: int,
        font_size: Pt,
        bold: bool = False,
        color: RGBColor = None,
        align: PP_ALIGN = PP_ALIGN.LEFT,
        line_spacing: Optional[Pt] = None,
    ):
        """Matn qutisi qo'shish"""
        txBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txBox.text_frame
        tf.word_wrap = True

        # Paragraflar
        if "\n" in text:
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if i == 0:
                    p = tf.paragraphs[0]
                else:
                    p = tf.add_paragraph()
                p.alignment = align
                run = p.add_run()
                run.text = line
                run.font.size = font_size
                run.font.bold = bold
                if color:
                    run.font.color.rgb = color
                if line_spacing:
                    p.line_spacing = line_spacing
        else:
            p = tf.paragraphs[0]
            p.alignment = align
            run = p.add_run()
            run.text = text
            run.font.size = font_size
            run.font.bold = bold
            if color:
                run.font.color.rgb = color

    @staticmethod
    def _add_slide_number(slide, num: int, slide_width: int, slide_height: int):
        """Pastki o'ng burchakda slayd raqami"""
        txBox = slide.shapes.add_textbox(
            slide_width - Inches(1),
            slide_height - Inches(0.4),
            Inches(0.8),
            Inches(0.35),
        )
        tf = txBox.text_frame
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.RIGHT
        run = p.add_run()
        run.text = str(num)
        run.font.size = Pt(12)
        run.font.color.rgb = RGBColor(0xAA, 0xAA, 0xAA)
