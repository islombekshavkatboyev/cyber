"""
DBManager — barcha repositorylarni bitta session ichida birlashtiradi.
Bot handlerlarida ishlatish uchun qulay fasad.

Misol:
    async with DBManager() as db:
        user, created = await db.users.get_or_create(telegram_id=123, full_name="Ali")
        order = await db.orders.create_order(...)
"""
from database.connection import get_session_factory
from database.repositories.user_repo import UserRepository
from database.repositories.order_repo import OrderRepository
from database.repositories.payment_repo import PaymentRepository


class DBManager:
    def __init__(self):
        self._session = None
        self.users: UserRepository = None
        self.orders: OrderRepository = None
        self.payments: PaymentRepository = None

    async def __aenter__(self) -> "DBManager":
        # Use the lazy factory so the engine is guaranteed to be initialised
        self._session = get_session_factory()()
        self.users = UserRepository(self._session)
        self.orders = OrderRepository(self._session)
        self.payments = PaymentRepository(self._session)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            await self._session.rollback()
        else:
            await self._session.commit()
        await self._session.close()

    async def commit(self):
        await self._session.commit()

    async def rollback(self):
        await self._session.rollback()
