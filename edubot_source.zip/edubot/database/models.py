import uuid
from datetime import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import INET, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database.connection import Base


# ─── Helpers ──────────────────────────────────────────────
def now_utc():
    return datetime.utcnow()


def new_uuid():
    return str(uuid.uuid4())


# ══════════════════════════════════════════════════════════
# USERS — Foydalanuvchilar
# ══════════════════════════════════════════════════════════
class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, nullable=False, index=True)
    username: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    full_name: Mapped[str] = mapped_column(String(256), nullable=False)
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)

    # Til sozlamasi
    language: Mapped[str] = mapped_column(String(4), default="uz", nullable=False)

    # Holat
    is_subscribed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    ban_reason: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)

    # Trial (bepul urinish)
    trial_used: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    free_attempts_left: Mapped[int] = mapped_column(Integer, default=1, nullable=False)

    # Meta
    last_ip: Mapped[Optional[str]] = mapped_column(INET, nullable=True)
    metadata_: Mapped[Optional[dict]] = mapped_column("metadata", JSONB, nullable=True, default=dict)

    # Vaqt
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_utc, nullable=False)
    last_active: Mapped[datetime] = mapped_column(DateTime, default=now_utc, onupdate=now_utc, nullable=False)

    # Relationships
    orders: Mapped[list["Order"]] = relationship("Order", back_populates="user", lazy="select")
    payments: Mapped[list["Payment"]] = relationship("Payment", back_populates="user", lazy="select")
    subscription: Mapped[Optional["Subscription"]] = relationship("Subscription", back_populates="user", uselist=False, lazy="select")

    __table_args__ = (
        Index("idx_users_telegram_id", "telegram_id"),
        Index("idx_users_is_banned", "is_banned"),
        Index("idx_users_created_at", "created_at"),
    )

    def __repr__(self):
        return f"<User telegram_id={self.telegram_id} username={self.username}>"


# ══════════════════════════════════════════════════════════
# ORDERS — Buyurtmalar
# ══════════════════════════════════════════════════════════
class Order(Base):
    __tablename__ = "orders"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    # Xizmat turi
    service_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # independent | referat | presentation | course_work | diploma

    # Holat
    status: Mapped[str] = mapped_column(
        String(32), default="pending", nullable=False
    )  # pending | paid | processing | completed | failed | cancelled

    # Fayl tili (UZ/RU/EN)
    doc_language: Mapped[str] = mapped_column(String(4), default="uz", nullable=False)

    # Buyurtma ma'lumotlari
    topic: Mapped[str] = mapped_column(String(512), nullable=False)
    pages: Mapped[int] = mapped_column(Integer, default=10, nullable=False)
    university_format: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Universitet ma'lumotlari
    university_name: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    faculty: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    subject: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    student_name: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    teacher_name: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    group_number: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    additional_instructions: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Narx
    price: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=0, nullable=False)
    is_free: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Generatsiya natijalari
    file_url_docx: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    file_url_pdf: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    file_url_pptx: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

    # Xato va qayta urinish
    retry_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Meta
    generation_metadata: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True, default=dict)

    # Vaqt
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_utc, nullable=False)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="orders")
    payments: Mapped[list["Payment"]] = relationship("Payment", back_populates="order", lazy="select")
    generation_logs: Mapped[list["GenerationLog"]] = relationship("GenerationLog", back_populates="order", lazy="select")

    __table_args__ = (
        Index("idx_orders_user_id", "user_id"),
        Index("idx_orders_status", "status"),
        Index("idx_orders_service_type", "service_type"),
        Index("idx_orders_created_at", "created_at"),
    )

    def __repr__(self):
        return f"<Order id={self.id} service={self.service_type} status={self.status}>"


# ══════════════════════════════════════════════════════════
# PAYMENTS — To'lovlar
# ══════════════════════════════════════════════════════════
class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    order_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("orders.id", ondelete="CASCADE"), nullable=False)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    # To'lov ma'lumotlari
    provider: Mapped[str] = mapped_column(String(16), nullable=False)  # click | payme | humo
    transaction_id: Mapped[Optional[str]] = mapped_column(String(256), unique=True, nullable=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(8), default="UZS", nullable=False)

    # Holat
    status: Mapped[str] = mapped_column(
        String(32), default="pending", nullable=False
    )  # pending | waiting | paid | failed | cancelled | refunded | expired

    # Provider javobi
    provider_response: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    invoice_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

    # Vaqt
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_utc, nullable=False)
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    expired_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    order: Mapped["Order"] = relationship("Order", back_populates="payments")
    user: Mapped["User"] = relationship("User", back_populates="payments")

    __table_args__ = (
        Index("idx_payments_transaction_id", "transaction_id"),
        Index("idx_payments_user_id", "user_id"),
        Index("idx_payments_status", "status"),
        Index("idx_payments_provider", "provider"),
        Index("idx_payments_order_id", "order_id"),
    )

    def __repr__(self):
        return f"<Payment id={self.id} provider={self.provider} status={self.status}>"


# ══════════════════════════════════════════════════════════
# SUBSCRIPTIONS — Kanal obunasi
# ══════════════════════════════════════════════════════════
class Subscription(Base):
    __tablename__ = "subscriptions"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True)
    channel_id: Mapped[str] = mapped_column(String(64), nullable=False)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    verified_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_check: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="subscription")

    def __repr__(self):
        return f"<Subscription user_id={self.user_id} verified={self.is_verified}>"


# ══════════════════════════════════════════════════════════
# PRICING — Narxlar (dinamik)
# ══════════════════════════════════════════════════════════
class Pricing(Base):
    __tablename__ = "pricing"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    service_type: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    base_price: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    price_with_format: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    min_pages: Mapped[int] = mapped_column(Integer, nullable=False)
    max_pages: Mapped[int] = mapped_column(Integer, nullable=False)
    price_per_page: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=0, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=now_utc, onupdate=now_utc, nullable=False)

    def __repr__(self):
        return f"<Pricing service={self.service_type} base={self.base_price}>"


# ══════════════════════════════════════════════════════════
# GENERATION LOGS — Generatsiya loglari
# ══════════════════════════════════════════════════════════
class GenerationLog(Base):
    __tablename__ = "generation_logs"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    order_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, index=True)

    # Generatsiya bosqichi
    stage: Mapped[str] = mapped_column(String(64), nullable=False)  # outline | intro | chapter_1 | conclusion | qc...
    model_used: Mapped[str] = mapped_column(String(64), nullable=False)
    tokens_used: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    cost_usd: Mapped[Decimal] = mapped_column(Numeric(10, 6), default=0, nullable=False)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    prompt_hash: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    success: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_utc, nullable=False)

    # Relationships
    order: Mapped["Order"] = relationship("Order", back_populates="generation_logs")

    __table_args__ = (
        Index("idx_gen_logs_order_id", "order_id"),
        Index("idx_gen_logs_created_at", "created_at"),
    )


# ══════════════════════════════════════════════════════════
# PROMPTS — AI prompt shablonlari (DB boshqarish)
# ══════════════════════════════════════════════════════════
class Prompt(Base):
    __tablename__ = "prompts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    service_type: Mapped[str] = mapped_column(String(32), nullable=False)
    language: Mapped[str] = mapped_column(String(4), nullable=False)   # uz | ru | en
    stage: Mapped[str] = mapped_column(String(64), nullable=False)      # outline | chapter | intro | conclusion...
    system_prompt: Mapped[str] = mapped_column(Text, nullable=False)
    user_prompt_template: Mapped[str] = mapped_column(Text, nullable=False)
    model: Mapped[str] = mapped_column(String(64), default="gpt-4o", nullable=False)
    temperature: Mapped[float] = mapped_column(Numeric(3, 2), default=0.7, nullable=False)
    max_tokens: Mapped[int] = mapped_column(Integer, default=4000, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=now_utc, onupdate=now_utc, nullable=False)

    __table_args__ = (
        UniqueConstraint("service_type", "language", "stage", "version", name="uq_prompt_version"),
        Index("idx_prompts_service_lang", "service_type", "language"),
    )

    def __repr__(self):
        return f"<Prompt service={self.service_type} lang={self.language} stage={self.stage}>"


# ══════════════════════════════════════════════════════════
# ADMIN LOGS — Admin harakatlari
# ══════════════════════════════════════════════════════════
class AdminLog(Base):
    __tablename__ = "admin_logs"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    admin_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    action: Mapped[str] = mapped_column(String(128), nullable=False)
    target: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_utc, nullable=False)

    __table_args__ = (
        Index("idx_admin_logs_admin_id", "admin_id"),
        Index("idx_admin_logs_created_at", "created_at"),
    )

    def __repr__(self):
        return f"<AdminLog admin={self.admin_id} action={self.action}>"
