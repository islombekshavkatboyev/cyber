"""
database/connection.py

FIX #6 / #20: Previously the SQLAlchemy engine was created at module import
time using `settings.database_url`.  When Celery workers import this module
before the .env file is loaded (or before DATABASE_URL is set in the
environment), the engine is built with an empty/wrong URL and every DB call
fails silently or raises a connection error.

Fix: defer engine creation to the first actual call using a module-level
`_engine` sentinel and a `get_engine()` factory. The engine is created lazily
on first use, guaranteeing that the environment is fully initialised first.
"""

from __future__ import annotations

from typing import AsyncGenerator, Optional

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

# Deferred — populated on first call to get_engine()
_engine: Optional[AsyncEngine] = None
_session_factory: Optional[async_sessionmaker] = None


class Base(DeclarativeBase):
    pass


def get_engine() -> AsyncEngine:
    """Return the shared async engine, creating it on first call."""
    global _engine
    if _engine is None:
        from bot.config import settings  # imported lazily — .env is loaded by now
        _engine = create_async_engine(
            settings.database_url,
            pool_size=settings.db_pool_size,
            max_overflow=settings.db_max_overflow,
            echo=settings.db_echo,
            pool_pre_ping=True,
            pool_recycle=3600,
        )
    return _engine


def get_session_factory() -> async_sessionmaker:
    """Return the shared session factory, creating it on first call."""
    global _session_factory
    if _session_factory is None:
        _session_factory = async_sessionmaker(
            get_engine(),
            class_=AsyncSession,
            expire_on_commit=False,
            autocommit=False,
            autoflush=False,
        )
    return _session_factory


# Convenience alias used by DBManager
def AsyncSessionFactory() -> AsyncSession:  # type: ignore[return-value]
    return get_session_factory()()


# ─── FastAPI dependency ───────────────────────────────────
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with get_session_factory()() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db():
    """
    Create all tables (development / first-run helper).

    CRASH #9 FIX: database/models.py registers all ORM classes onto Base.metadata,
    but it is never imported in the startup chain. Without this import,
    Base.metadata.tables is empty and create_all() creates ZERO tables.
    Every subsequent INSERT then raises:
        asyncpg.exceptions.UndefinedTableError: relation "users" does not exist

    IMPORTANT: In production, prefer running `alembic upgrade head` instead of
    create_all (see CRASH #13). This function is kept for development/testing only.
    """
    import database.models  # noqa: F401 — side-effect: registers all models onto Base.metadata
    async with get_engine().begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db():
    """Dispose the engine (call on app shutdown)."""
    global _engine, _session_factory
    if _engine is not None:
        await _engine.dispose()
        _engine = None
        _session_factory = None
