"""Initial schema

Revision ID: 001
Revises:
Create Date: 2025-01-01 00:00:00.000000

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ── users ──────────────────────────────────────────────
    op.create_table(
        "users",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("telegram_id", sa.BigInteger(), nullable=False),
        sa.Column("username", sa.String(64), nullable=True),
        sa.Column("full_name", sa.String(256), nullable=False),
        sa.Column("phone", sa.String(20), nullable=True),
        sa.Column("language", sa.String(4), nullable=False, server_default="uz"),
        sa.Column("is_subscribed", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("is_banned", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("ban_reason", sa.String(256), nullable=True),
        sa.Column("trial_used", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("free_attempts_left", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("last_ip", postgresql.INET(), nullable=True),
        sa.Column("metadata", postgresql.JSONB(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("last_active", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("telegram_id"),
    )
    op.create_index("idx_users_telegram_id", "users", ["telegram_id"])
    op.create_index("idx_users_is_banned", "users", ["is_banned"])
    op.create_index("idx_users_created_at", "users", ["created_at"])

    # ── orders ─────────────────────────────────────────────
    op.create_table(
        "orders",
        sa.Column("id", postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column("user_id", sa.BigInteger(), nullable=False),
        sa.Column("service_type", sa.String(32), nullable=False),
        sa.Column("status", sa.String(32), nullable=False, server_default="pending"),
        sa.Column("doc_language", sa.String(4), nullable=False, server_default="uz"),
        sa.Column("topic", sa.String(512), nullable=False),
        sa.Column("pages", sa.Integer(), nullable=False, server_default="10"),
        sa.Column("university_format", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("university_name", sa.String(256), nullable=True),
        sa.Column("faculty", sa.String(256), nullable=True),
        sa.Column("subject", sa.String(256), nullable=True),
        sa.Column("student_name", sa.String(256), nullable=True),
        sa.Column("teacher_name", sa.String(256), nullable=True),
        sa.Column("group_number", sa.String(64), nullable=True),
        sa.Column("additional_instructions", sa.Text(), nullable=True),
        sa.Column("price", sa.Numeric(12, 2), nullable=False, server_default="0"),
        sa.Column("is_free", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("file_url_docx", sa.String(512), nullable=True),
        sa.Column("file_url_pdf", sa.String(512), nullable=True),
        sa.Column("file_url_pptx", sa.String(512), nullable=True),
        sa.Column("retry_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("generation_metadata", postgresql.JSONB(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("completed_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("idx_orders_user_id", "orders", ["user_id"])
    op.create_index("idx_orders_status", "orders", ["status"])
    op.create_index("idx_orders_service_type", "orders", ["service_type"])
    op.create_index("idx_orders_created_at", "orders", ["created_at"])

    # ── payments ───────────────────────────────────────────
    op.create_table(
        "payments",
        sa.Column("id", postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column("order_id", postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column("user_id", sa.BigInteger(), nullable=False),
        sa.Column("provider", sa.String(16), nullable=False),
        sa.Column("transaction_id", sa.String(256), nullable=True),
        sa.Column("amount", sa.Numeric(12, 2), nullable=False),
        sa.Column("currency", sa.String(8), nullable=False, server_default="UZS"),
        sa.Column("status", sa.String(32), nullable=False, server_default="pending"),
        sa.Column("provider_response", postgresql.JSONB(), nullable=True),
        sa.Column("invoice_url", sa.String(512), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("paid_at", sa.DateTime(), nullable=True),
        sa.Column("expired_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["order_id"], ["orders.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("transaction_id"),
    )
    op.create_index("idx_payments_transaction_id", "payments", ["transaction_id"])
    op.create_index("idx_payments_user_id", "payments", ["user_id"])
    op.create_index("idx_payments_status", "payments", ["status"])
    op.create_index("idx_payments_provider", "payments", ["provider"])
    op.create_index("idx_payments_order_id", "payments", ["order_id"])

    # ── subscriptions ──────────────────────────────────────
    op.create_table(
        "subscriptions",
        sa.Column("id", postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column("user_id", sa.BigInteger(), nullable=False),
        sa.Column("channel_id", sa.String(64), nullable=False),
        sa.Column("is_verified", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("verified_at", sa.DateTime(), nullable=True),
        sa.Column("last_check", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("user_id"),
    )

    # ── pricing ────────────────────────────────────────────
    op.create_table(
        "pricing",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("service_type", sa.String(32), nullable=False),
        sa.Column("base_price", sa.Numeric(12, 2), nullable=False),
        sa.Column("price_with_format", sa.Numeric(12, 2), nullable=False),
        sa.Column("min_pages", sa.Integer(), nullable=False),
        sa.Column("max_pages", sa.Integer(), nullable=False),
        sa.Column("price_per_page", sa.Numeric(10, 2), nullable=False, server_default="0"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="true"),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("service_type"),
    )

    # ── generation_logs ────────────────────────────────────
    op.create_table(
        "generation_logs",
        sa.Column("id", postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column("order_id", postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column("stage", sa.String(64), nullable=False),
        sa.Column("model_used", sa.String(64), nullable=False),
        sa.Column("tokens_used", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("cost_usd", sa.Numeric(10, 6), nullable=False, server_default="0"),
        sa.Column("duration_ms", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("prompt_hash", sa.String(64), nullable=True),
        sa.Column("success", sa.Boolean(), nullable=False, server_default="true"),
        sa.Column("error", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["order_id"], ["orders.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("idx_gen_logs_order_id", "generation_logs", ["order_id"])
    op.create_index("idx_gen_logs_created_at", "generation_logs", ["created_at"])

    # ── prompts ────────────────────────────────────────────
    op.create_table(
        "prompts",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("service_type", sa.String(32), nullable=False),
        sa.Column("language", sa.String(4), nullable=False),
        sa.Column("stage", sa.String(64), nullable=False),
        sa.Column("system_prompt", sa.Text(), nullable=False),
        sa.Column("user_prompt_template", sa.Text(), nullable=False),
        sa.Column("model", sa.String(64), nullable=False, server_default="gpt-4o"),
        sa.Column("temperature", sa.Numeric(3, 2), nullable=False, server_default="0.7"),
        sa.Column("max_tokens", sa.Integer(), nullable=False, server_default="4000"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="true"),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("service_type", "language", "stage", "version", name="uq_prompt_version"),
    )

    # ── admin_logs ─────────────────────────────────────────
    op.create_table(
        "admin_logs",
        sa.Column("id", postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column("admin_id", sa.BigInteger(), nullable=False),
        sa.Column("action", sa.String(128), nullable=False),
        sa.Column("target", postgresql.JSONB(), nullable=True),
        sa.Column("note", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("idx_admin_logs_admin_id", "admin_logs", ["admin_id"])
    op.create_index("idx_admin_logs_created_at", "admin_logs", ["created_at"])

    # ── Default pricing data ───────────────────────────────
    op.execute("""
        INSERT INTO pricing (service_type, base_price, price_with_format, min_pages, max_pages, price_per_page, updated_at)
        VALUES
            ('independent',  15000, 20000,  5,  30, 2000, NOW()),
            ('referat',      20000, 25000, 10,  40, 2500, NOW()),
            ('presentation', 25000, 25000, 10,  40, 3000, NOW()),
            ('course_work',  80000, 90000, 25,  60, 3000, NOW()),
            ('diploma',     250000,270000, 60, 100, 4000, NOW())
    """)


def downgrade() -> None:
    op.drop_table("admin_logs")
    op.drop_table("prompts")
    op.drop_table("generation_logs")
    op.drop_table("pricing")
    op.drop_table("subscriptions")
    op.drop_table("payments")
    op.drop_table("orders")
    op.drop_table("users")
