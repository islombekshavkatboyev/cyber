from datetime import datetime
from typing import Optional, List

from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import User
from database.repositories.base_repo import BaseRepository


class UserRepository(BaseRepository[User]):

    def __init__(self, session: AsyncSession):
        super().__init__(User, session)

    # ─── Topish ───────────────────────────────────────────
    async def get_by_telegram_id(self, telegram_id: int) -> Optional[User]:
        result = await self.session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    async def get_or_create(
        self,
        telegram_id: int,
        full_name: str,
        username: Optional[str] = None,
        language: str = "uz",
    ) -> tuple[User, bool]:
        """
        Foydalanuvchini topadi yoki yangi yaratadi.
        Returns: (user, created: bool)
        """
        user = await self.get_by_telegram_id(telegram_id)
        if user:
            # Oxirgi faollik vaqtini yangilash
            await self.session.execute(
                update(User)
                .where(User.telegram_id == telegram_id)
                .values(
                    last_active=datetime.utcnow(),
                    full_name=full_name,
                    username=username,
                )
            )
            await self.session.flush()
            await self.session.refresh(user)
            return user, False

        # Yangi foydalanuvchi yaratish
        user = User(
            telegram_id=telegram_id,
            full_name=full_name,
            username=username,
            language=language,
            created_at=datetime.utcnow(),
            last_active=datetime.utcnow(),
        )
        return await self.save(user), True

    # ─── Yangilash ────────────────────────────────────────
    async def update_language(self, telegram_id: int, language: str) -> None:
        await self.session.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(language=language)
        )
        await self.session.flush()

    async def mark_trial_used(self, telegram_id: int) -> None:
        await self.session.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(trial_used=True, free_attempts_left=0)
        )
        await self.session.flush()

    async def mark_subscribed(self, telegram_id: int, subscribed: bool) -> None:
        await self.session.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(is_subscribed=subscribed)
        )
        await self.session.flush()

    async def ban_user(self, telegram_id: int, reason: str) -> None:
        await self.session.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(is_banned=True, ban_reason=reason)
        )
        await self.session.flush()

    async def unban_user(self, telegram_id: int) -> None:
        await self.session.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(is_banned=False, ban_reason=None)
        )
        await self.session.flush()

    # ─── Statistika ───────────────────────────────────────
    async def count_total(self) -> int:
        result = await self.session.execute(
            select(func.count(User.id))
        )
        return result.scalar_one()

    async def count_today(self) -> int:
        today = datetime.utcnow().date()
        result = await self.session.execute(
            select(func.count(User.id)).where(
                func.date(User.created_at) == today
            )
        )
        return result.scalar_one()

    async def count_active_today(self) -> int:
        today = datetime.utcnow().date()
        result = await self.session.execute(
            select(func.count(User.id)).where(
                func.date(User.last_active) == today
            )
        )
        return result.scalar_one()

    async def get_all_active(self, limit: int = 1000) -> List[User]:
        """Barcha aktiv (ban qilinmagan) foydalanuvchilar"""
        result = await self.session.execute(
            select(User)
            .where(User.is_banned == False)
            .order_by(User.last_active.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def can_use_free_trial(self, telegram_id: int) -> bool:
        """Bepul urinish ishlatish mumkinmi?"""
        user = await self.get_by_telegram_id(telegram_id)
        if not user:
            return False
        return not user.trial_used and user.free_attempts_left > 0
