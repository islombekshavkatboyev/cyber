from datetime import datetime
from decimal import Decimal
from typing import Optional, List

from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from database.models import Order
from database.repositories.base_repo import BaseRepository


class OrderRepository(BaseRepository[Order]):

    def __init__(self, session: AsyncSession):
        super().__init__(Order, session)

    # ─── Yaratish ─────────────────────────────────────────
    async def create_order(
        self,
        user_id: int,
        service_type: str,
        topic: str,
        doc_language: str,
        pages: int,
        price: Decimal,
        is_free: bool = False,
        university_format: bool = False,
        university_name: Optional[str] = None,
        faculty: Optional[str] = None,
        subject: Optional[str] = None,
        student_name: Optional[str] = None,
        teacher_name: Optional[str] = None,
        group_number: Optional[str] = None,
        additional_instructions: Optional[str] = None,
    ) -> Order:
        order = Order(
            user_id=user_id,
            service_type=service_type,
            topic=topic,
            doc_language=doc_language,
            pages=pages,
            price=price,
            is_free=is_free,
            status="pending",
            university_format=university_format,
            university_name=university_name,
            faculty=faculty,
            subject=subject,
            student_name=student_name,
            teacher_name=teacher_name,
            group_number=group_number,
            additional_instructions=additional_instructions,
            created_at=datetime.utcnow(),
        )
        return await self.save(order)

    # ─── Topish ───────────────────────────────────────────
    async def get_by_id_with_user(self, order_id: str) -> Optional[Order]:
        result = await self.session.execute(
            select(Order)
            .options(selectinload(Order.user))
            .where(Order.id == order_id)
        )
        return result.scalar_one_or_none()

    async def get_user_orders(
        self,
        user_id: int,
        limit: int = 10,
        offset: int = 0,
    ) -> List[Order]:
        result = await self.session.execute(
            select(Order)
            .where(Order.user_id == user_id)
            .order_by(Order.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        return list(result.scalars().all())

    async def get_pending_orders(self, limit: int = 50) -> List[Order]:
        result = await self.session.execute(
            select(Order)
            .where(Order.status == "pending")
            .order_by(Order.created_at.asc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def get_failed_orders(self, limit: int = 50) -> List[Order]:
        result = await self.session.execute(
            select(Order)
            .where(Order.status == "failed")
            .order_by(Order.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    # ─── Holat yangilash ──────────────────────────────────
    async def update_status(self, order_id: str, status: str) -> None:
        values = {"status": status}
        if status == "completed":
            values["completed_at"] = datetime.utcnow()
        await self.session.execute(
            update(Order).where(Order.id == order_id).values(**values)
        )
        await self.session.flush()

    async def update_files(
        self,
        order_id: str,
        file_url_docx: Optional[str] = None,
        file_url_pdf: Optional[str] = None,
        file_url_pptx: Optional[str] = None,
    ) -> None:
        values = {}
        if file_url_docx:
            values["file_url_docx"] = file_url_docx
        if file_url_pdf:
            values["file_url_pdf"] = file_url_pdf
        if file_url_pptx:
            values["file_url_pptx"] = file_url_pptx
        if values:
            await self.session.execute(
                update(Order).where(Order.id == order_id).values(**values)
            )
            await self.session.flush()

    async def mark_failed(self, order_id: str, error: str) -> None:
        await self.session.execute(
            update(Order)
            .where(Order.id == order_id)
            .values(
                status="failed",
                error_message=error,
                retry_count=Order.retry_count + 1,
            )
        )
        await self.session.flush()

    async def increment_retry(self, order_id: str) -> int:
        """Retry sonini oshiradi va yangi qiymatni qaytaradi"""
        order = await self.get_by_id(order_id)
        if not order:
            return 0
        new_count = order.retry_count + 1
        await self.session.execute(
            update(Order)
            .where(Order.id == order_id)
            .values(retry_count=new_count, status="processing")
        )
        await self.session.flush()
        return new_count

    # ─── Statistika ───────────────────────────────────────
    async def count_today(self) -> int:
        today = datetime.utcnow().date()
        result = await self.session.execute(
            select(func.count(Order.id)).where(
                func.date(Order.created_at) == today
            )
        )
        return result.scalar_one()

    async def count_by_status(self, status: str) -> int:
        result = await self.session.execute(
            select(func.count(Order.id)).where(Order.status == status)
        )
        return result.scalar_one()

    async def count_by_service_today(self) -> dict:
        """Bugungi xizmat turlari bo'yicha statistika"""
        today = datetime.utcnow().date()
        result = await self.session.execute(
            select(Order.service_type, func.count(Order.id))
            .where(func.date(Order.created_at) == today)
            .group_by(Order.service_type)
        )
        return {row[0]: row[1] for row in result.fetchall()}

    async def get_recent_for_admin(
        self, limit: int = 20, offset: int = 0
    ) -> List[Order]:
        result = await self.session.execute(
            select(Order)
            .options(selectinload(Order.user))
            .order_by(Order.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        return list(result.scalars().all())
