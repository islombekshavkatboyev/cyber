from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional, List

from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from database.models import Payment
from database.repositories.base_repo import BaseRepository


class PaymentRepository(BaseRepository[Payment]):

    def __init__(self, session: AsyncSession):
        super().__init__(Payment, session)

    # ─── Yaratish ─────────────────────────────────────────
    async def create_payment(
        self,
        order_id: str,
        user_id: int,
        provider: str,
        amount: Decimal,
        invoice_url: Optional[str] = None,
        transaction_id: Optional[str] = None,
        expire_minutes: int = 30,
    ) -> Payment:
        payment = Payment(
            order_id=order_id,
            user_id=user_id,
            provider=provider,
            amount=amount,
            currency="UZS",
            status="pending",
            invoice_url=invoice_url,
            transaction_id=transaction_id,
            created_at=datetime.utcnow(),
            expired_at=datetime.utcnow() + timedelta(minutes=expire_minutes),
        )
        return await self.save(payment)

    # ─── Topish ───────────────────────────────────────────
    async def get_by_transaction_id(self, transaction_id: str) -> Optional[Payment]:
        result = await self.session.execute(
            select(Payment).where(Payment.transaction_id == transaction_id)
        )
        return result.scalar_one_or_none()

    async def get_by_order_id(self, order_id: str) -> Optional[Payment]:
        """Buyurtmaning eng so'nggi to'lovi"""
        result = await self.session.execute(
            select(Payment)
            .where(Payment.order_id == order_id)
            .order_by(Payment.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_pending_by_user(self, user_id: int) -> Optional[Payment]:
        """Foydalanuvchining kutilayotgan to'lovi"""
        result = await self.session.execute(
            select(Payment)
            .where(
                Payment.user_id == user_id,
                Payment.status.in_(["pending", "waiting"]),
            )
            .order_by(Payment.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_user_payments(
        self, user_id: int, limit: int = 10
    ) -> List[Payment]:
        result = await self.session.execute(
            select(Payment)
            .where(Payment.user_id == user_id)
            .order_by(Payment.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    # ─── Holat yangilash ──────────────────────────────────
    async def mark_paid(
        self,
        payment_id: str,
        transaction_id: str,
        provider_response: Optional[dict] = None,
    ) -> None:
        await self.session.execute(
            update(Payment)
            .where(Payment.id == payment_id)
            .values(
                status="paid",
                transaction_id=transaction_id,
                paid_at=datetime.utcnow(),
                provider_response=provider_response or {},
            )
        )
        await self.session.flush()

    async def mark_failed(
        self,
        payment_id: str,
        provider_response: Optional[dict] = None,
    ) -> None:
        await self.session.execute(
            update(Payment)
            .where(Payment.id == payment_id)
            .values(
                status="failed",
                provider_response=provider_response or {},
            )
        )
        await self.session.flush()

    async def mark_expired(self, payment_id: str) -> None:
        await self.session.execute(
            update(Payment)
            .where(Payment.id == payment_id)
            .values(status="expired")
        )
        await self.session.flush()

    async def mark_waiting(
        self,
        payment_id: str,
        transaction_id: str,
        invoice_url: Optional[str] = None,
    ) -> None:
        values = {"status": "waiting", "transaction_id": transaction_id}
        if invoice_url:
            values["invoice_url"] = invoice_url
        await self.session.execute(
            update(Payment).where(Payment.id == payment_id).values(**values)
        )
        await self.session.flush()

    # ─── Muddati o'tgan to'lovlarni tekshirish ────────────
    async def get_expired_pending(self) -> List[Payment]:
        """Muddati o'tib ketgan pending to'lovlar"""
        result = await self.session.execute(
            select(Payment)
            .where(
                Payment.status.in_(["pending", "waiting"]),
                Payment.expired_at < datetime.utcnow(),
            )
        )
        return list(result.scalars().all())

    # ─── Statistika ───────────────────────────────────────
    async def sum_revenue_today(self) -> Decimal:
        today = datetime.utcnow().date()
        result = await self.session.execute(
            select(func.coalesce(func.sum(Payment.amount), 0)).where(
                Payment.status == "paid",
                func.date(Payment.paid_at) == today,
            )
        )
        return result.scalar_one() or Decimal("0")

    async def sum_revenue_total(self) -> Decimal:
        result = await self.session.execute(
            select(func.coalesce(func.sum(Payment.amount), 0)).where(
                Payment.status == "paid"
            )
        )
        return result.scalar_one() or Decimal("0")

    async def count_by_provider_today(self) -> dict:
        today = datetime.utcnow().date()
        result = await self.session.execute(
            select(Payment.provider, func.count(Payment.id))
            .where(
                Payment.status == "paid",
                func.date(Payment.paid_at) == today,
            )
            .group_by(Payment.provider)
        )
        return {row[0]: row[1] for row in result.fetchall()}

    async def count_active_payments(self) -> int:
        result = await self.session.execute(
            select(func.count(Payment.id)).where(
                Payment.status.in_(["pending", "waiting"])
            )
        )
        return result.scalar_one()

    async def get_recent_for_admin(
        self, limit: int = 20, offset: int = 0
    ) -> List[Payment]:
        result = await self.session.execute(
            select(Payment)
            .options(selectinload(Payment.user), selectinload(Payment.order))
            .order_by(Payment.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        return list(result.scalars().all())
