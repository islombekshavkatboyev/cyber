from aiogram.fsm.state import State, StatesGroup


class PaymentStates(StatesGroup):
    """
    To'lov jarayoni FSM holatlari.
    """

    # To'lov usulini tanlash
    choose_provider = State()

    # Invoice yaratildi, foydalanuvchi to'lashni kutmoqda
    waiting_payment = State()

    # To'lov tekshirilmoqda
    checking = State()
