from aiogram.fsm.state import State, StatesGroup


class AdminStates(StatesGroup):
    """
    Admin panel FSM holatlari.
    """

    # Broadcast
    broadcast_message = State()
    broadcast_confirm = State()

    # Ban
    ban_user_id = State()
    ban_reason = State()

    # Unban
    unban_user_id = State()

    # Fayl qayta yuborish
    resend_order_id = State()
