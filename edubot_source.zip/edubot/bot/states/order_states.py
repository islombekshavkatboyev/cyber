from aiogram.fsm.state import State, StatesGroup


class OrderStates(StatesGroup):
    """
    Buyurtma berish jarayoni FSM holatlari.

    Oqim:
    topic → doc_language → pages → university_format →
    [university_name → faculty → subject → student_name → teacher_name → group → additional] →
    confirm → [payment] → processing
    """

    # 1. Mavzu
    topic = State()

    # 2. Hujjat tili (UZ / RU / EN)
    doc_language = State()

    # 3. Sahifalar soni
    pages = State()

    # 4. Universitet formati (Ha/Yo'q)
    university_format = State()

    # 5. Universitet ma'lumotlari (faqat format=Ha bo'lsa)
    university_name = State()
    faculty = State()
    subject = State()
    student_name = State()
    teacher_name = State()
    group_number = State()
    additional_instructions = State()

    # 6. Tasdiqlash
    confirm = State()

    # 7. To'lov kutish
    waiting_payment = State()
