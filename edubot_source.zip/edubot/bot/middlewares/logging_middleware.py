import time
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject, Update
from loguru import logger


class LoggingMiddleware(BaseMiddleware):
    """
    Har bir so'rovni loglaydi:
    - Foydalanuvchi ID
    - So'rov turi (message/callback)
    - Matn yoki callback data
    - Ishlash vaqti (ms)
    """

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        start_time = time.monotonic()

        user_id, event_type, content = self._extract_info(event)

        if user_id:
            logger.debug(
                f"[{event_type}] user_id={user_id} | {content[:100]}"
            )

        try:
            result = await handler(event, data)
            elapsed = int((time.monotonic() - start_time) * 1000)

            if user_id:
                logger.debug(
                    f"[{event_type}] user_id={user_id} | OK | {elapsed}ms"
                )
            return result

        except Exception as e:
            elapsed = int((time.monotonic() - start_time) * 1000)
            logger.error(
                f"[{event_type}] user_id={user_id} | ERROR: {e} | {elapsed}ms"
            )
            raise

    @staticmethod
    def _extract_info(event: TelegramObject) -> tuple[int | None, str, str]:
        if isinstance(event, Message):
            return (
                event.from_user.id if event.from_user else None,
                "MSG",
                event.text or event.caption or "[media]",
            )
        if isinstance(event, CallbackQuery):
            return (
                event.from_user.id if event.from_user else None,
                "CB",
                event.data or "",
            )
        if isinstance(event, Update):
            if event.message:
                uid = event.message.from_user.id if event.message.from_user else None
                return uid, "MSG", event.message.text or "[media]"
            if event.callback_query:
                uid = event.callback_query.from_user.id if event.callback_query.from_user else None
                return uid, "CB", event.callback_query.data or ""
        return None, "UNKNOWN", ""
