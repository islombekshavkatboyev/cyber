from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject, Update

from database.db_manager import DBManager
from locales.i18n import t


class AuthMiddleware(BaseMiddleware):
    """
    Har bir so'rovda:
    1. Foydalanuvchini DB da topadi yoki yaratadi
    2. Ban holatini tekshiradi
    3. data["user"] ga foydalanuvchi ob'ektini qo'yadi
    """

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        # Foydalanuvchini aniqlash
        tg_user = self._extract_tg_user(event)
        if not tg_user:
            return await handler(event, data)

        # FIX #2: DB session must NOT be kept open across handler execution.
        # Previously data["db"] was set inside the context manager and the
        # handler was called AFTER __aexit__ — the session would already be
        # closed by the time the handler tried to use it.
        # Solution: fetch the user, close the session, then pass only the
        # plain user object. Handlers open their own DBManager sessions.
        async with DBManager() as db:
            user, created = await db.users.get_or_create(
                telegram_id=tg_user.id,
                full_name=tg_user.full_name,
                username=tg_user.username,
            )
            is_banned = user.is_banned
            ban_reason = user.ban_reason or ""
            # Detach values we need — session closes after this block
            user_id = user.id
            user_telegram_id = user.telegram_id
            user_language = user.language
            trial_used = user.trial_used
            free_attempts_left = user.free_attempts_left

        if is_banned:
            await self._send_banned(event, ban_reason)
            return

        # Pass a lightweight dict instead of an ORM object tied to a dead session
        data["user_info"] = {
            "id": user_id,
            "telegram_id": user_telegram_id,
            "language": user_language,
            "trial_used": trial_used,
            "free_attempts_left": free_attempts_left,
            "is_new": created,
        }
        data["is_new_user"] = created

        return await handler(event, data)

    @staticmethod
    def _extract_tg_user(event: TelegramObject):
        if isinstance(event, Update):
            if event.message:
                return event.message.from_user
            if event.callback_query:
                return event.callback_query.from_user
        if isinstance(event, Message):
            return event.from_user
        if isinstance(event, CallbackQuery):
            return event.from_user
        return None

    @staticmethod
    async def _send_banned(event: TelegramObject, reason: str):
        text = t("errors.banned", reason=reason or "Ko'rsatilmagan")
        if isinstance(event, Message):
            await event.answer(text, parse_mode="HTML")
        elif isinstance(event, CallbackQuery):
            await event.answer(text[:200], show_alert=True)
        elif isinstance(event, Update):
            if event.message:
                await event.message.answer(text, parse_mode="HTML")
            elif event.callback_query:
                await event.callback_query.answer(text[:200], show_alert=True)
