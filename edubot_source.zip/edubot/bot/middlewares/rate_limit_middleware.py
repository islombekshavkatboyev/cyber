"""
rate_limit_middleware.py

FIX #17: In aiogram v3 an outer middleware registered on dp.update receives
an Update wrapper object, NOT a bare Message or CallbackQuery.  The previous
code did isinstance(event, Message) / isinstance(event, CallbackQuery) checks
which NEVER matched, making the middleware a no-op.

Fix: always unwrap via event.message / event.callback_query and determine the
limit_type from the presence of those attributes.
"""
from typing import Any, Awaitable, Callable

import redis.asyncio as aioredis
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Update

from locales.i18n import t


class RateLimitMiddleware(BaseMiddleware):
    """
    Token bucket rate limiting.

    Limits:
    - messages:  30 / 60 s
    - callbacks: 60 / 60 s
    - (order / payment limits exposed as helpers for handlers)
    """

    LIMITS = {
        "message":  (30,  60),
        "callback": (60,  60),
        "order":    (5,  3600),
        "payment":  (5,  3600),
    }

    def __init__(self, redis_client: aioredis.Redis):
        self.redis = redis_client

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        # dp.update outer middleware always receives an Update
        if not isinstance(event, Update):
            return await handler(event, data)

        user_id, limit_type = self._extract(event)
        if user_id is None:
            return await handler(event, data)

        if await self._check_limit(user_id, limit_type):
            await self._send_limit_message(event)
            return

        return await handler(event, data)

    # ── public helpers (called from handlers) ─────────────
    async def check_order_limit(self, user_id: int) -> bool:
        return await self._check_limit(user_id, "order")

    async def check_payment_limit(self, user_id: int) -> bool:
        return await self._check_limit(user_id, "payment")

    # ── internals ─────────────────────────────────────────
    @staticmethod
    def _extract(update: Update) -> tuple[int | None, str]:
        """Return (user_id, limit_type) from an Update."""
        if update.message and update.message.from_user:
            return update.message.from_user.id, "message"
        if update.callback_query and update.callback_query.from_user:
            return update.callback_query.from_user.id, "callback"
        if update.inline_query and update.inline_query.from_user:
            return update.inline_query.from_user.id, "message"
        return None, "message"

    async def _check_limit(self, user_id: int, limit_type: str) -> bool:
        limit, window = self.LIMITS.get(limit_type, (30, 60))
        key = f"rl:{limit_type}:{user_id}"
        try:
            pipe = self.redis.pipeline()
            pipe.incr(key)
            pipe.expire(key, window)
            results = await pipe.execute()
            return results[0] > limit
        except Exception:
            return False  # Redis down → allow through

    @staticmethod
    async def _send_limit_message(update: Update):
        text = t("errors.rate_limit")
        if update.message:
            await update.message.answer(text)
        elif update.callback_query:
            await update.callback_query.answer(text[:200], show_alert=True)
