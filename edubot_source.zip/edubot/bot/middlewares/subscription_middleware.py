from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware, Bot
from aiogram.types import CallbackQuery, Message, TelegramObject, Update

from bot.config import settings
from bot.keyboards.subscription_kb import subscription_kb
from locales.i18n import t

# Kanalga tekshirishni o'tkazib yuborish kerak bo'lgan callbacklar
BYPASS_CALLBACKS = {
    "sub:check",   # Obunani tekshirish
    "menu:main",   # Bosh menyu
}

# O'tkazib yuborish kerak bo'lgan commandlar
BYPASS_COMMANDS = {"/start", "/help", "/admin"}


class SubscriptionMiddleware(BaseMiddleware):
    """
    Har bir so'rovda kanalga obunani tekshiradi.
    Obuna yo'q bo'lsa — obuna sahifasini ko'rsatadi.

    Anti-bypass: foydalanuvchi kanaldan chiqib ketsa ham tekshiradi.
    Cache: 5 daqiqaga Redis da saqlanadi (har safar API chaqirmaslik uchun).
    """

    CACHE_TTL = 300  # 5 daqiqa

    def __init__(self, bot: Bot, redis_client=None):
        self.bot = bot
        self.redis = redis_client

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user_id = self._get_user_id(event)
        if not user_id:
            return await handler(event, data)

        # Adminlarni o'tkazib yuborish
        if user_id in settings.admin_ids:
            return await handler(event, data)

        # Bypassga ruxsat berilgan callbacklar
        if self._is_bypass(event):
            return await handler(event, data)

        # Obunani tekshirish
        is_subscribed = await self._check_subscription(user_id)

        if not is_subscribed:
            await self._send_subscription_required(event)
            return

        return await handler(event, data)

    async def _check_subscription(self, user_id: int) -> bool:
        """Kanalga obunani tekshirish (cache bilan)"""
        cache_key = f"sub:{user_id}"

        # Avval cache dan tekshirish
        if self.redis:
            try:
                cached = await self.redis.get(cache_key)
                if cached is not None:
                    return cached == b"1"
            except Exception:
                pass

        # Telegram API dan tekshirish
        try:
            member = await self.bot.get_chat_member(
                chat_id=settings.required_channel_id,
                user_id=user_id,
            )
            is_member = member.status not in ("left", "kicked", "banned")

            # Natijani cache ga saqlash
            if self.redis:
                try:
                    await self.redis.setex(
                        cache_key,
                        self.CACHE_TTL,
                        b"1" if is_member else b"0",
                    )
                except Exception:
                    pass

            return is_member
        except Exception:
            # API xatolik — o'tkazib yuborish (xavfsiz tomon)
            return True

    async def force_recheck(self, user_id: int) -> bool:
        """Cache ni o'chirib, majburan qayta tekshirish"""
        if self.redis:
            try:
                await self.redis.delete(f"sub:{user_id}")
            except Exception:
                pass
        return await self._check_subscription(user_id)

    @staticmethod
    def _get_user_id(event: TelegramObject) -> int | None:
        if isinstance(event, Message):
            return event.from_user.id if event.from_user else None
        if isinstance(event, CallbackQuery):
            return event.from_user.id if event.from_user else None
        if isinstance(event, Update):
            if event.message and event.message.from_user:
                return event.message.from_user.id
            if event.callback_query and event.callback_query.from_user:
                return event.callback_query.from_user.id
        return None

    @staticmethod
    def _is_bypass(event: TelegramObject) -> bool:
        """Bu so'rovni tekshirishdan o'tkazib yuborish kerakmi?"""
        if isinstance(event, CallbackQuery):
            return event.data in BYPASS_CALLBACKS
        if isinstance(event, Message):
            if event.text and event.text.startswith("/"):
                cmd = event.text.split()[0].split("@")[0]
                return cmd in BYPASS_COMMANDS
        if isinstance(event, Update):
            if event.callback_query:
                return event.callback_query.data in BYPASS_CALLBACKS
            if event.message and event.message.text:
                cmd = event.message.text.split()[0].split("@")[0]
                return cmd in BYPASS_COMMANDS
        return False

    @staticmethod
    async def _send_subscription_required(event: TelegramObject):
        text = t("subscription.required")
        kb = subscription_kb()

        if isinstance(event, Message):
            await event.answer(text, reply_markup=kb, parse_mode="HTML")
        elif isinstance(event, CallbackQuery):
            await event.message.answer(text, reply_markup=kb, parse_mode="HTML")
            await event.answer()
        elif isinstance(event, Update):
            if event.message:
                await event.message.answer(text, reply_markup=kb, parse_mode="HTML")
            elif event.callback_query:
                await event.callback_query.message.answer(
                    text, reply_markup=kb, parse_mode="HTML"
                )
                await event.callback_query.answer()
