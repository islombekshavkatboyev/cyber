from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def payment_provider_kb(order_id: str) -> InlineKeyboardMarkup:
    """To'lov usulini tanlash"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="💳 Click",
            callback_data=f"pay:click:{order_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="💳 Payme",
            callback_data=f"pay:payme:{order_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="💳 Humo",
            callback_data=f"pay:humo:{order_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="❌ Bekor qilish",
            callback_data=f"pay:cancel:{order_id}"
        )
    )

    return builder.as_markup()


def payment_invoice_kb(invoice_url: str, payment_id: str) -> InlineKeyboardMarkup:
    """To'lov havolasi va tekshirish tugmasi"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="💳 To'lovni amalga oshirish",
            url=invoice_url
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="🔄 To'lovni tekshirish",
            callback_data=f"pay:check:{payment_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="❌ Bekor qilish",
            callback_data=f"pay:cancel:{payment_id}"
        )
    )

    return builder.as_markup()


def payment_retry_kb(order_id: str) -> InlineKeyboardMarkup:
    """To'lov muvaffaqiyatsiz — qayta urinish"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="🔄 Qayta to'lash",
            callback_data=f"pay:retry:{order_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="🏠 Bosh menyu",
            callback_data="menu:main"
        )
    )

    return builder.as_markup()


def payment_success_kb() -> InlineKeyboardMarkup:
    """To'lov muvaffaqiyatli — asosiy menyu"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="🏠 Bosh menyu",
            callback_data="menu:main"
        )
    )

    return builder.as_markup()
