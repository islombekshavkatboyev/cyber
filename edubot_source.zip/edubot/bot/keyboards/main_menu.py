from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="📋 Xizmatlar",
            callback_data="menu:services"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="📦 Buyurtmalarim",
            callback_data="menu:my_orders"
        ),
        InlineKeyboardButton(
            text="❓ Yordam",
            callback_data="menu:help"
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text="ℹ️ Bot haqida",
            callback_data="menu:about"
        )
    )

    return builder.as_markup()
