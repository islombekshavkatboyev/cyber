from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from bot.config import settings


def subscription_kb() -> InlineKeyboardMarkup:
    """Kanalga obuna bo'lish va tekshirish"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="📢 Kanalga o'tish",
            url=f"https://t.me/{settings.required_channel_username.lstrip('@')}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="✅ Obunani tekshirish",
            callback_data="sub:check"
        )
    )

    return builder.as_markup()
