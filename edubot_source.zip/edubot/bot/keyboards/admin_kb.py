from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def admin_menu_kb() -> InlineKeyboardMarkup:
    """Admin bosh menyusi"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(text="📊 Statistika", callback_data="admin:stats"),
        InlineKeyboardButton(text="📦 Buyurtmalar", callback_data="admin:orders"),
    )
    builder.row(
        InlineKeyboardButton(text="💰 To'lovlar", callback_data="admin:payments"),
        InlineKeyboardButton(text="👥 Foydalanuvchilar", callback_data="admin:users"),
    )
    builder.row(
        InlineKeyboardButton(text="📢 Xabar yuborish", callback_data="admin:broadcast"),
        InlineKeyboardButton(text="❌ Bloklash", callback_data="admin:ban"),
    )
    builder.row(
        InlineKeyboardButton(text="📤 Fayl qayta yuborish", callback_data="admin:resend"),
    )

    return builder.as_markup()


def broadcast_confirm_kb(count: int) -> InlineKeyboardMarkup:
    """Broadcast tasdiqlash"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text=f"✅ Ha, {count} ta ga yuborish",
            callback_data="admin:broadcast_confirm"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="❌ Bekor qilish",
            callback_data="admin:broadcast_cancel"
        )
    )

    return builder.as_markup()


def failed_orders_kb(orders: list) -> InlineKeyboardMarkup:
    """Muvaffaqiyatsiz buyurtmalar — admin uchun"""
    builder = InlineKeyboardBuilder()

    for order in orders[:10]:
        builder.row(
            InlineKeyboardButton(
                text=f"🔄 {order.id[:8]}... — {order.service_type}",
                callback_data=f"admin:retry:{order.id}"
            )
        )

    builder.row(
        InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin:menu")
    )

    return builder.as_markup()
