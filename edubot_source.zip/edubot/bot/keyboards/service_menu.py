from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def services_kb() -> InlineKeyboardMarkup:
    """Xizmatlar ro'yxati"""
    builder = InlineKeyboardBuilder()

    services = [
        ("📝 Mustaqil ish", "service:independent"),
        ("📄 Referat", "service:referat"),
        ("📊 Prezentatsiya", "service:presentation"),
        ("📚 Kurs ishi", "service:course_work"),
        ("🎓 Diplom ishi", "service:diploma"),
    ]

    for text, callback in services:
        builder.row(InlineKeyboardButton(text=text, callback_data=callback))

    builder.row(
        InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu:main")
    )

    return builder.as_markup()


def service_info_kb(service_type: str) -> InlineKeyboardMarkup:
    """Xizmat ma'lumoti sahifasidagi tugmalar"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="✅ Buyurtma berish",
            callback_data=f"order:start:{service_type}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="⬅️ Xizmatlarga qaytish",
            callback_data="menu:services"
        )
    )

    return builder.as_markup()


def doc_language_kb() -> InlineKeyboardMarkup:
    """Hujjat tilini tanlash"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(text="🇺🇿 O'zbek tili", callback_data="lang:uz"),
        InlineKeyboardButton(text="🇷🇺 Rus tili", callback_data="lang:ru"),
    )
    builder.row(
        InlineKeyboardButton(text="🇬🇧 Ingliz tili", callback_data="lang:en"),
    )
    builder.row(
        InlineKeyboardButton(text="⬅️ Orqaga", callback_data="order:back")
    )

    return builder.as_markup()


def university_format_kb() -> InlineKeyboardMarkup:
    """Universitet formati tanlash"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="✅ Ha, universitet formatida",
            callback_data="format:yes"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="❌ Yo'q, oddiy format",
            callback_data="format:no"
        )
    )
    builder.row(
        InlineKeyboardButton(text="⬅️ Orqaga", callback_data="order:back")
    )

    return builder.as_markup()


def confirm_order_kb() -> InlineKeyboardMarkup:
    """Buyurtmani tasdiqlash"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="✅ Tasdiqlash",
            callback_data="order:confirm"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="✏️ Tahrirlash",
            callback_data="order:edit"
        ),
        InlineKeyboardButton(
            text="❌ Bekor qilish",
            callback_data="order:cancel"
        ),
    )

    return builder.as_markup()


def skip_kb() -> InlineKeyboardMarkup:
    """Ixtiyoriy maydonni o'tkazib yuborish"""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="⏭️ O'tkazib yuborish",
            callback_data="order:skip"
        )
    )
    return builder.as_markup()


def rating_kb() -> InlineKeyboardMarkup:
    """Xizmatni baholash — 1 dan 5 gacha"""
    builder = InlineKeyboardBuilder()

    ratings = [
        ("😡 1", "rate:1"),
        ("😕 2", "rate:2"),
        ("😐 3", "rate:3"),
        ("😊 4", "rate:4"),
        ("🤩 5", "rate:5"),
    ]

    builder.row(*[
        InlineKeyboardButton(text=text, callback_data=cb)
        for text, cb in ratings
    ])

    return builder.as_markup()


def retry_order_kb(order_id: str) -> InlineKeyboardMarkup:
    """Muvaffaqiyatsiz buyurtmani qayta urinish"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="🔄 Qayta urinish",
            callback_data=f"order:retry:{order_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="🏠 Bosh menyu",
            callback_data="menu:main"
        )
    )

    return builder.as_markup()


def my_orders_kb(orders: list) -> InlineKeyboardMarkup:
    """Mening buyurtmalarim ro'yxati"""
    builder = InlineKeyboardBuilder()

    status_icons = {
        "pending": "⏳",
        "paid": "✅",
        "processing": "🤖",
        "completed": "📄",
        "failed": "❌",
        "cancelled": "🚫",
    }

    for order in orders[:10]:
        icon = status_icons.get(order.status, "📋")
        service_names = {
            "independent": "Mustaqil ish",
            "referat": "Referat",
            "presentation": "Prezentatsiya",
            "course_work": "Kurs ishi",
            "diploma": "Diplom ishi",
        }
        name = service_names.get(order.service_type, order.service_type)
        builder.row(
            InlineKeyboardButton(
                text=f"{icon} {name} — {order.created_at.strftime('%d.%m.%Y')}",
                callback_data=f"order:view:{order.id}"
            )
        )

    builder.row(
        InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu:main")
    )

    return builder.as_markup()
