"""
Input sanitizer — prompt injection va zararli matnlardan himoya.
"""
import html
import re

# Prompt injection patternlari
INJECTION_PATTERNS = [
    r"ignore\s+previous\s+instructions",
    r"you\s+are\s+now\s+",
    r"act\s+as\s+",
    r"pretend\s+(you\s+are|to\s+be)",
    r"system\s*:",
    r"<\|im_start\|>",
    r"<\|im_end\|>",
    r"\[INST\]",
    r"###\s*instruction",
    r"ignore\s+all",
    r"disregard\s+",
]

# Zararli kod patternlari
CODE_INJECTION_PATTERNS = [
    r"exec\s*\(",
    r"eval\s*\(",
    r"__import__",
    r"os\.system",
    r"subprocess",
    r"<script",
    r"javascript:",
]

MAX_LENGTH = 1000


def sanitize_input(text: str) -> str:
    """
    Foydalanuvchi kiritgan matnni tozalaydi.
    ValueError — xavfli matn aniqlanganda.
    """
    if not text:
        return ""

    # Uzunlikni cheklash
    text = text[:MAX_LENGTH]

    # HTML injection
    text = html.escape(text)

    text_lower = text.lower()

    # Prompt injection tekshirish
    for pattern in INJECTION_PATTERNS:
        if re.search(pattern, text_lower, re.IGNORECASE):
            raise ValueError(f"Prompt injection detected: {pattern}")

    # Kod injection tekshirish
    for pattern in CODE_INJECTION_PATTERNS:
        if re.search(pattern, text_lower, re.IGNORECASE):
            raise ValueError(f"Code injection detected: {pattern}")

    # Null bytes
    text = text.replace("\x00", "")

    # Ko'p qator bo'sh joylarni tozalash
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r" {3,}", " ", text)

    return text.strip()


def sanitize_topic(topic: str) -> str:
    """Mavzu uchun maxsus tozalash"""
    topic = sanitize_input(topic)
    # Faqat harflar, raqamlar, bo'sh joy va asosiy tinish belgilari
    topic = re.sub(r"[^\w\s\-.,!?()'\"\u0400-\u04FF\u0100-\u024F]", "", topic)
    return topic.strip()
