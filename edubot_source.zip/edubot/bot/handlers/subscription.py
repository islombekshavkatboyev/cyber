from aiogram import F, Router, Bot
from aiogram.types import CallbackQuery

from bot.config import settings
from bot.keyboards.main_menu import main_menu_kb
from bot.keyboards.subscription_kb import subscription_kb
from database.db_manager import DBManager
from locales.i18n import t

router = Router(name="subscription")


@router.callback_query(F.data == "sub:check")
async def check_subscription(callback: CallbackQuery, bot: Bot):
    """
    Kanalga obunani tekshirish tugmasi bosilganda.
    Cache ni o'chirib, Telegram API dan yangi tekshirish.
    """
    user_id = callback.from_user.id

    try:
        member = await bot.get_chat_member(
            chat_id=settings.required_channel_id,
            user_id=user_id,
        )
        is_subscribed = member.status not in ("left", "kicked", "banned")
    except Exception:
        is_subscribed = False

    if not is_subscribed:
        await callback.answer(
            t("subscription.not_subscribed"),
            show_alert=True,
        )
        return

    # DB da obuna holatini yangilash
    async with DBManager() as db:
        await db.users.mark_subscribed(user_id, True)

    await callback.message.edit_text(
        text=t("subscription.subscribed"),
        reply_markup=main_menu_kb(),
        parse_mode="HTML",
    )
    await callback.answer("✅ Obuna tasdiqlandi!", show_alert=False)
