from aiogram import F, Router
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from bot.keyboards.main_menu import main_menu_kb
from database.db_manager import DBManager
from locales.i18n import t

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    """
    /start — Botga kirish nuqtasi.
    1. Foydalanuvchini yaratadi yoki topadi
    2. Obunani tekshiradi
    3. Asosiy menyuni ko'rsatadi
    """
    await state.clear()

    async with DBManager() as db:
        user, created = await db.users.get_or_create(
            telegram_id=message.from_user.id,
            full_name=message.from_user.full_name,
            username=message.from_user.username,
        )

    await message.answer(
        text=t("start.welcome"),
        reply_markup=main_menu_kb(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "menu:main")
async def back_to_main(callback: CallbackQuery, state: FSMContext):
    """Asosiy menyuga qaytish"""
    await state.clear()

    await callback.message.edit_text(
        text=t("main_menu.title"),
        reply_markup=main_menu_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "menu:help")
async def show_help(callback: CallbackQuery):
    """Yordam sahifasi"""
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    from aiogram.utils.keyboard import InlineKeyboardBuilder

    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="📞 Qo'llab-quvvatlash",
            url="https://t.me/EduBotSupport"
        )
    )
    builder.row(
        InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu:main")
    )

    await callback.message.edit_text(
        text=t("help.title") + t("help.text"),
        reply_markup=builder.as_markup(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "menu:about")
async def show_about(callback: CallbackQuery):
    """Bot haqida"""
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    from aiogram.utils.keyboard import InlineKeyboardBuilder

    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu:main")
    )

    await callback.message.edit_text(
        text=t("about.title") + t("about.text"),
        reply_markup=builder.as_markup(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "menu:my_orders")
async def show_my_orders(callback: CallbackQuery):
    """Foydalanuvchi buyurtmalari"""
    from bot.keyboards.service_menu import my_orders_kb

    async with DBManager() as db:
        orders = await db.orders.get_user_orders(
            user_id=callback.from_user.id,
            limit=10,
        )

    if not orders:
        from aiogram.utils.keyboard import InlineKeyboardBuilder
        from aiogram.types import InlineKeyboardButton
        builder = InlineKeyboardBuilder()
        builder.row(
            InlineKeyboardButton(
                text="📋 Xizmatlar",
                callback_data="menu:services"
            )
        )
        builder.row(
            InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu:main")
        )
        await callback.message.edit_text(
            text=t("orders.no_orders"),
            reply_markup=builder.as_markup(),
            parse_mode="HTML",
        )
        await callback.answer()
        return

    await callback.message.edit_text(
        text=t("orders.my_orders_title"),
        reply_markup=my_orders_kb(orders),
        parse_mode="HTML",
    )
    await callback.answer()
