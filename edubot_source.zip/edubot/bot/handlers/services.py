from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery

from bot.keyboards.service_menu import services_kb, service_info_kb
from locales.i18n import t

router = Router(name="services")

SERVICE_TYPES = {
    "independent", "referat", "presentation", "course_work", "diploma"
}

SERVICE_INFO_KEYS = {
    "independent": "services.independent_info",
    "referat": "services.referat_info",
    "presentation": "services.presentation_info",
    "course_work": "services.course_work_info",
    "diploma": "services.diploma_info",
}


@router.callback_query(F.data == "menu:services")
async def show_services(callback: CallbackQuery, state: FSMContext):
    """Xizmatlar ro'yxatini ko'rsatish"""
    await state.clear()
    await callback.message.edit_text(
        text=t("services.title"),
        reply_markup=services_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("service:"))
async def show_service_info(callback: CallbackQuery, state: FSMContext):
    """Tanlangan xizmat haqida ma'lumot"""
    service_type = callback.data.split(":")[1]

    if service_type not in SERVICE_TYPES:
        await callback.answer("❌ Noto'g'ri xizmat turi", show_alert=True)
        return

    # Xizmat ma'lumotini ko'rsatish
    info_key = SERVICE_INFO_KEYS[service_type]
    text = t(info_key)

    await callback.message.edit_text(
        text=text,
        reply_markup=service_info_kb(service_type),
        parse_mode="HTML",
    )
    await callback.answer()
