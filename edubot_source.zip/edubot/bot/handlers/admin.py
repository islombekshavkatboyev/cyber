from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from bot.filters.admin_filter import AdminFilter
from bot.keyboards.admin_kb import admin_menu_kb, broadcast_confirm_kb, failed_orders_kb
from bot.states.admin_states import AdminStates
from database.db_manager import DBManager
from locales.i18n import t, format_price

router = Router(name="admin")


# ══════════════════════════════════════════════════════════
# ADMIN MENYUSI
# ══════════════════════════════════════════════════════════
@router.message(Command("admin"), AdminFilter())
async def cmd_admin(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        text="⚙️ <b>Admin panel</b>",
        reply_markup=admin_menu_kb(),
        parse_mode="HTML",
    )


@router.message(Command("admin"))
async def cmd_admin_denied(message: Message):
    await message.answer(t("admin.not_admin"))


# ══════════════════════════════════════════════════════════
# STATISTIKA
# ══════════════════════════════════════════════════════════
@router.callback_query(F.data == "admin:stats", AdminFilter())
async def show_stats(callback: CallbackQuery):
    async with DBManager() as db:
        users_total = await db.users.count_total()
        users_today = await db.users.count_today()
        active_today = await db.users.count_active_today()
        orders_today = await db.orders.count_today()
        pending = await db.orders.count_by_status("pending")
        failed = await db.orders.count_by_status("failed")
        revenue_today = await db.payments.sum_revenue_today()
        revenue_total = await db.payments.sum_revenue_total()

    text = (
        t("admin.stats_title")
        + t("admin.stats_users_total", count=users_total)
        + t("admin.stats_users_today", count=users_today)
        + t("admin.stats_active_today", count=active_today)
        + t("admin.stats_orders_today", count=orders_today)
        + t("admin.stats_revenue_today", amount=format_price(revenue_today))
        + t("admin.stats_revenue_total", amount=format_price(revenue_total))
        + t("admin.stats_pending", count=pending)
        + t("admin.stats_failed", count=failed)
    )

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🔄 Yangilash", callback_data="admin:stats"),
        InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin:menu"),
    )

    await callback.message.edit_text(
        text=text,
        reply_markup=builder.as_markup(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "admin:menu", AdminFilter())
async def admin_menu(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        text="⚙️ <b>Admin panel</b>",
        reply_markup=admin_menu_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


# ══════════════════════════════════════════════════════════
# BROADCAST
# ══════════════════════════════════════════════════════════
@router.callback_query(F.data == "admin:broadcast", AdminFilter())
async def start_broadcast(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.broadcast_message)
    await callback.message.edit_text(
        text=t("admin.broadcast_prompt"),
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(AdminStates.broadcast_message, AdminFilter())
async def get_broadcast_message(message: Message, state: FSMContext):
    await state.update_data(broadcast_text=message.text or message.caption or "")
    await state.set_state(AdminStates.broadcast_confirm)

    async with DBManager() as db:
        count = await db.users.count_total()

    await message.answer(
        text=t("admin.broadcast_confirm", count=count),
        reply_markup=broadcast_confirm_kb(count),
        parse_mode="HTML",
    )


@router.callback_query(AdminStates.broadcast_confirm, F.data == "admin:broadcast_confirm", AdminFilter())
async def confirm_broadcast(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    text = data.get("broadcast_text", "")
    await state.clear()

    # Celery orqali yuborish
    from workers.tasks.notification import broadcast_message
    broadcast_message.delay(text)

    await callback.message.edit_text(
        text="📢 Xabar yuborish navbatga qo'yildi...",
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(AdminStates.broadcast_confirm, F.data == "admin:broadcast_cancel", AdminFilter())
async def cancel_broadcast(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        text="❌ Broadcast bekor qilindi.",
        reply_markup=admin_menu_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


# ══════════════════════════════════════════════════════════
# BAN / UNBAN
# ══════════════════════════════════════════════════════════
@router.callback_query(F.data == "admin:ban", AdminFilter())
async def start_ban(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.ban_user_id)
    await callback.message.edit_text(
        text=t("admin.ban_prompt"),
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(AdminStates.ban_user_id, AdminFilter())
async def get_ban_user_id(message: Message, state: FSMContext):
    if not message.text or not message.text.strip().isdigit():
        await message.answer("❌ Faqat raqam (Telegram ID) kiriting:")
        return

    await state.update_data(ban_telegram_id=int(message.text.strip()))
    await state.set_state(AdminStates.ban_reason)
    await message.answer(t("admin.ban_reason_prompt"), parse_mode="HTML")


@router.message(AdminStates.ban_reason, AdminFilter())
async def get_ban_reason(message: Message, state: FSMContext):
    data = await state.get_data()
    telegram_id = data.get("ban_telegram_id")
    reason = message.text.strip() if message.text else "Ko'rsatilmagan"

    async with DBManager() as db:
        user = await db.users.get_by_telegram_id(telegram_id)
        if not user:
            await message.answer(t("admin.user_not_found"))
            await state.clear()
            return
        await db.users.ban_user(telegram_id, reason)

    await state.clear()
    await message.answer(
        text=t("admin.ban_success"),
        reply_markup=admin_menu_kb(),
        parse_mode="HTML",
    )


# ══════════════════════════════════════════════════════════
# MUVAFFAQIYATSIZ BUYURTMALAR
# ══════════════════════════════════════════════════════════
@router.callback_query(F.data == "admin:orders", AdminFilter())
async def show_failed_orders(callback: CallbackQuery):
    async with DBManager() as db:
        failed = await db.orders.get_failed_orders(limit=10)

    if not failed:
        await callback.answer("✅ Muvaffaqiyatsiz buyurtmalar yo'q", show_alert=True)
        return

    text = f"❌ <b>Muvaffaqiyatsiz buyurtmalar:</b> {len(failed)} ta\n\n"
    for o in failed[:5]:
        text += f"• <code>{o.id[:8]}</code> — {o.service_type} — {o.topic[:30]}...\n"

    await callback.message.edit_text(
        text=text,
        reply_markup=failed_orders_kb(failed),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin:retry:"), AdminFilter())
async def admin_retry_order(callback: CallbackQuery):
    order_id = callback.data.split(":")[2]

    from workers.tasks.generation import generate_document
    generate_document.delay(order_id)

    await callback.answer(f"✅ {order_id[:8]}... qayta navbatga qo'yildi", show_alert=True)


# ══════════════════════════════════════════════════════════
# FAYL QAYTA YUBORISH
# ══════════════════════════════════════════════════════════
@router.callback_query(F.data == "admin:resend", AdminFilter())
async def start_resend(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.resend_order_id)
    await callback.message.edit_text(
        text=t("admin.resend_prompt"),
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(AdminStates.resend_order_id, AdminFilter())
async def resend_file(message: Message, state: FSMContext):
    order_id = message.text.strip() if message.text else ""
    await state.clear()

    async with DBManager() as db:
        order = await db.orders.get_by_id_with_user(order_id)

    if not order:
        await message.answer(t("admin.order_not_found"))
        return

    if not any([order.file_url_docx, order.file_url_pdf, order.file_url_pptx]):
        await message.answer(t("admin.resend_failed"))
        return

    # Fayllarni yuborish
    # FIX #16a: create Bot with DefaultBotProperties so parse_mode is set.
    # FIX #16b: file_url_docx/pdf/pptx are S3 *object keys*, not public URLs
    #           and not telegram file_ids. We must download bytes from S3 and
    #           send them via BufferedInputFile — raw keys sent to Telegram
    #           raise a Bad Request error.
    from aiogram import Bot
    from aiogram.client.default import DefaultBotProperties
    from aiogram.enums import ParseMode
    from aiogram.types import BufferedInputFile
    from bot.config import settings as cfg
    from storage.s3_client import get_s3_client

    bot = Bot(
        token=cfg.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    s3 = get_s3_client()

    try:
        if order.file_url_docx:
            data_bytes = s3.download_bytes(order.file_url_docx)
            await bot.send_document(
                chat_id=order.user.telegram_id,
                document=BufferedInputFile(
                    data_bytes,
                    filename=f"{order.service_type}_{order.id[:8]}.docx",
                ),
                caption="📄 DOCX fayl (Admin tomonidan qayta yuborildi)",
            )
        if order.file_url_pdf:
            data_bytes = s3.download_bytes(order.file_url_pdf)
            await bot.send_document(
                chat_id=order.user.telegram_id,
                document=BufferedInputFile(
                    data_bytes,
                    filename=f"{order.service_type}_{order.id[:8]}.pdf",
                ),
                caption="📋 PDF fayl",
            )
        if order.file_url_pptx:
            data_bytes = s3.download_bytes(order.file_url_pptx)
            await bot.send_document(
                chat_id=order.user.telegram_id,
                document=BufferedInputFile(
                    data_bytes,
                    filename=f"{order.service_type}_{order.id[:8]}.pptx",
                ),
                caption="📊 PPTX fayl",
            )
        await message.answer(
            text=t("admin.resend_success"),
            reply_markup=admin_menu_kb(),
        )
    except Exception as e:
        await message.answer(f"❌ Xatolik: {e}")
    finally:
        await bot.session.close()
