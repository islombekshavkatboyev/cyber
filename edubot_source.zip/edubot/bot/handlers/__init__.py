from aiogram import Router

from .start import router as start_router
from .subscription import router as subscription_router
from .services import router as services_router
from .order_flow import router as order_router
from .payment import router as payment_router
from .admin import router as admin_router


def get_main_router() -> Router:
    main_router = Router()
    main_router.include_router(start_router)
    main_router.include_router(subscription_router)
    main_router.include_router(services_router)
    main_router.include_router(order_router)
    main_router.include_router(payment_router)
    main_router.include_router(admin_router)
    return main_router
