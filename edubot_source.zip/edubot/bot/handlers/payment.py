from aiogram import F, Router
from aiogram.types import CallbackQuery

from bot.keyboards.payment_menu import (
    payment_invoice_kb,
    payment_retry_kb,
    payment_success_kb,
)
from database.db_manager import DBManager
from locales.i18n import t, format_price

router = Router(name="payment")


@router.callback_query(F.data.startswith("pay:"))
async def handle_payment(callback: CallbackQuery):
    parts = callback.data.split(":")
    action = parts[1]

    if action in ("click", "payme", "humo"):
        await _create_payment(callback, provider=action, order_id=parts[2])
    elif action == "check":
        await _check_payment(callback, payment_id=parts[2])
    elif action == "cancel":
        await _cancel_payment(callback, payment_id=parts[2])
    elif action == "retry":
        await _retry_payment(callback, order_id=parts[2])


async def _create_payment(callback: CallbackQuery, provider: str, order_id: str):
    """To'lov yaratish"""
    from payment.service import PaymentService

    async with DBManager() as db:
        order = await db.orders.get_by_id(order_id)
        if not order:
            await callback.answer(t("admin.order_not_found"), show_alert=True)
            return

        if order.status == "paid":
            await callback.answer(t("payment.already_paid"), show_alert=True)
            return

        # Invoice yaratish
        try:
            payment_service = PaymentService()
            invoice_data = await payment_service.create_invoice(
                provider=provider,
                order_id=order_id,
                amount=order.price,
                user_id=callback.from_user.id,
            )

            # Payment DB ga saqlash
            payment = await db.payments.create_payment(
                order_id=order_id,
                user_id=order.user_id,
                provider=provider,
                amount=order.price,
                invoice_url=invoice_data.get("invoice_url"),
                transaction_id=invoice_data.get("transaction_id"),
            )

        except Exception as e:
            await callback.message.edit_text(
                text=t("errors.payment_error"),
                reply_markup=payment_retry_kb(order_id),
                parse_mode="HTML",
            )
            await callback.answer()
            return

    provider_names = {"click": "Click", "payme": "Payme", "humo": "Humo"}
    await callback.message.edit_text(
        text=t(
            "payment.invoice_created",
            amount=format_price(order.price),
            provider=provider_names.get(provider, provider),
        ),
        reply_markup=payment_invoice_kb(
            invoice_url=invoice_data.get("invoice_url", "#"),
            payment_id=payment.id,
        ),
        parse_mode="HTML",
    )
    await callback.answer()


async def _check_payment(callback: CallbackQuery, payment_id: str):
    """To'lov holatini tekshirish"""
    await callback.answer(t("payment.pending"), show_alert=False)

    async with DBManager() as db:
        payment = await db.payments.get_by_id(payment_id)
        if not payment:
            await callback.answer("❌ To'lov topilmadi", show_alert=True)
            return

        if payment.status == "paid":
            # To'lov amalga oshgan — generatsiya boshlash
            await callback.message.edit_text(
                text=t("payment.success", amount=format_price(payment.amount)),
                reply_markup=payment_success_kb(),
                parse_mode="HTML",
            )
            from workers.tasks.generation import generate_document
            generate_document.delay(payment.order_id)
            return

        # Provider dan tekshirish
        from payment.service import PaymentService
        try:
            payment_service = PaymentService()
            status = await payment_service.check_status(
                provider=payment.provider,
                transaction_id=payment.transaction_id,
            )

            if status == "paid":
                await db.payments.mark_paid(
                    payment_id=payment.id,
                    transaction_id=payment.transaction_id,
                )
                await db.orders.update_status(payment.order_id, "paid")

                await callback.message.edit_text(
                    text=t("payment.success", amount=format_price(payment.amount)),
                    reply_markup=payment_success_kb(),
                    parse_mode="HTML",
                )
                from workers.tasks.generation import generate_document
                generate_document.delay(payment.order_id)

            elif status == "expired":
                await db.payments.mark_expired(payment.id)
                await callback.message.edit_text(
                    text=t("payment.expired"),
                    reply_markup=payment_retry_kb(payment.order_id),
                    parse_mode="HTML",
                )
            else:
                await callback.answer(
                    "⏳ To'lov hali amalga oshmagan. Biroz kuting.",
                    show_alert=True,
                )
        except Exception:
            await callback.answer(t("errors.payment_error"), show_alert=True)


async def _cancel_payment(callback: CallbackQuery, payment_id: str):
    """To'lovni bekor qilish"""
    async with DBManager() as db:
        payment = await db.payments.get_by_id(payment_id)
        if payment and payment.status in ("pending", "waiting"):
            await db.payments.mark_failed(payment.id)
            order_id = payment.order_id
        else:
            order_id = payment_id  # fallback

    await callback.message.edit_text(
        text=t("order.cancelled"),
        parse_mode="HTML",
    )
    await callback.answer()


async def _retry_payment(callback: CallbackQuery, order_id: str):
    """Qayta to'lash"""
    from bot.keyboards.payment_menu import payment_provider_kb

    async with DBManager() as db:
        order = await db.orders.get_by_id(order_id)
        if not order:
            await callback.answer(t("admin.order_not_found"), show_alert=True)
            return

    await callback.message.edit_text(
        text=t("payment.title", amount=format_price(order.price)),
        reply_markup=payment_provider_kb(order_id),
        parse_mode="HTML",
    )
    await callback.answer()
