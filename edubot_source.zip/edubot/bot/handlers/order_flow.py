from decimal import Decimal

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from bot.config import settings
from bot.keyboards.main_menu import main_menu_kb
from bot.keyboards.payment_menu import payment_provider_kb
from bot.keyboards.service_menu import (
    confirm_order_kb,
    doc_language_kb,
    skip_kb,
    university_format_kb,
)
from bot.states.order_states import OrderStates
from database.db_manager import DBManager
from locales.i18n import t, format_price, get_service_name, get_doc_language_name, get_format_name
from payment.pricing import calculate_price

router = Router(name="order_flow")

# Sahifalar cheklovi
PAGE_LIMITS = {
    "independent":  (5, 30),
    "referat":      (10, 40),
    "presentation": (10, 40),
    "course_work":  (25, 60),
    "diploma":      (60, 100),
}


# ══════════════════════════════════════════════════════════
# 1. BUYURTMA BOSHLASH
# ══════════════════════════════════════════════════════════
@router.callback_query(F.data.startswith("order:start:"))
async def start_order(callback: CallbackQuery, state: FSMContext):
    service_type = callback.data.split(":")[2]
    await state.set_data({"service_type": service_type})
    await state.set_state(OrderStates.topic)

    await callback.message.edit_text(
        text=t("order.enter_topic"),
        parse_mode="HTML",
    )
    await callback.answer()


# ══════════════════════════════════════════════════════════
# 2. MAVZU
# ══════════════════════════════════════════════════════════
@router.message(OrderStates.topic)
async def process_topic(message: Message, state: FSMContext):
    topic = message.text.strip() if message.text else ""

    if len(topic) < 5:
        await message.answer(t("order.topic_too_short"), parse_mode="HTML")
        return
    if len(topic) > 500:
        await message.answer(t("order.topic_too_long"), parse_mode="HTML")
        return

    # Prompt injection himoyasi
    from bot.utils.sanitizer import sanitize_input
    try:
        topic = sanitize_input(topic)
    except ValueError:
        await message.answer(t("errors.invalid_input"), parse_mode="HTML")
        return

    await state.update_data(topic=topic)
    await state.set_state(OrderStates.doc_language)

    await message.answer(
        text=t("order.choose_doc_language"),
        reply_markup=doc_language_kb(),
        parse_mode="HTML",
    )


# ══════════════════════════════════════════════════════════
# 3. HUJJAT TILI
# ══════════════════════════════════════════════════════════
@router.callback_query(OrderStates.doc_language, F.data.startswith("lang:"))
async def process_doc_language(callback: CallbackQuery, state: FSMContext):
    lang = callback.data.split(":")[1]
    if lang not in ("uz", "ru", "en"):
        await callback.answer("❌ Noto'g'ri til", show_alert=True)
        return

    await state.update_data(doc_language=lang)
    await state.set_state(OrderStates.pages)

    data = await state.get_data()
    service_type = data.get("service_type", "referat")
    min_p, max_p = PAGE_LIMITS.get(service_type, (5, 40))

    label = "sahifa" if service_type != "presentation" else "slayd"
    await callback.message.edit_text(
        text=t("order.enter_pages", min=min_p, max=max_p).replace(
            "Sahifalar", "Slaydlar" if service_type == "presentation" else "Sahifalar"
        ),
        parse_mode="HTML",
    )
    await callback.answer()


# ══════════════════════════════════════════════════════════
# 4. SAHIFALAR SONI
# ══════════════════════════════════════════════════════════
@router.message(OrderStates.pages)
async def process_pages(message: Message, state: FSMContext):
    text = message.text.strip() if message.text else ""

    if not text.isdigit():
        await message.answer(t("order.pages_not_number"), parse_mode="HTML")
        return

    pages = int(text)
    data = await state.get_data()
    service_type = data.get("service_type", "referat")
    min_p, max_p = PAGE_LIMITS.get(service_type, (5, 40))

    if pages < min_p or pages > max_p:
        await message.answer(
            t("order.pages_invalid", min=min_p, max=max_p),
            parse_mode="HTML",
        )
        return

    await state.update_data(pages=pages)
    await state.set_state(OrderStates.university_format)

    await message.answer(
        text=t("order.university_format"),
        reply_markup=university_format_kb(),
        parse_mode="HTML",
    )


# ══════════════════════════════════════════════════════════
# 5. UNIVERSITET FORMATI
# ══════════════════════════════════════════════════════════
@router.callback_query(OrderStates.university_format, F.data.startswith("format:"))
async def process_university_format(callback: CallbackQuery, state: FSMContext):
    choice = callback.data.split(":")[1]
    university_format = choice == "yes"

    await state.update_data(university_format=university_format)

    if university_format:
        await state.set_state(OrderStates.university_name)
        await callback.message.edit_text(
            text=t("order.enter_university"),
            parse_mode="HTML",
        )
    else:
        await state.update_data(
            university_name=None,
            faculty=None,
            subject=None,
            student_name=None,
            teacher_name=None,
            group_number=None,
            additional_instructions=None,
        )
        await state.set_state(OrderStates.confirm)
        await _show_confirm(callback.message, state, callback.from_user.id)

    await callback.answer()


# ══════════════════════════════════════════════════════════
# 6. UNIVERSITET MA'LUMOTLARI
# ══════════════════════════════════════════════════════════
@router.message(OrderStates.university_name)
async def process_university_name(message: Message, state: FSMContext):
    await state.update_data(university_name=message.text.strip())
    await state.set_state(OrderStates.faculty)
    await message.answer(t("order.enter_faculty"), parse_mode="HTML")


@router.message(OrderStates.faculty)
async def process_faculty(message: Message, state: FSMContext):
    await state.update_data(faculty=message.text.strip())
    await state.set_state(OrderStates.subject)
    await message.answer(t("order.enter_subject"), parse_mode="HTML")


@router.message(OrderStates.subject)
async def process_subject(message: Message, state: FSMContext):
    await state.update_data(subject=message.text.strip())
    await state.set_state(OrderStates.student_name)
    await message.answer(t("order.enter_student_name"), parse_mode="HTML")


@router.message(OrderStates.student_name)
async def process_student_name(message: Message, state: FSMContext):
    await state.update_data(student_name=message.text.strip())
    await state.set_state(OrderStates.teacher_name)
    await message.answer(t("order.enter_teacher"), parse_mode="HTML")


@router.message(OrderStates.teacher_name)
async def process_teacher_name(message: Message, state: FSMContext):
    await state.update_data(teacher_name=message.text.strip())
    await state.set_state(OrderStates.group_number)
    await message.answer(t("order.enter_group"), parse_mode="HTML")


@router.message(OrderStates.group_number)
async def process_group(message: Message, state: FSMContext):
    await state.update_data(group_number=message.text.strip())
    await state.set_state(OrderStates.additional_instructions)
    await message.answer(
        text=t("order.enter_additional"),
        reply_markup=skip_kb(),
        parse_mode="HTML",
    )


@router.message(OrderStates.additional_instructions)
async def process_additional(message: Message, state: FSMContext):
    await state.update_data(additional_instructions=message.text.strip())
    await state.set_state(OrderStates.confirm)
    await _show_confirm(message, state, message.from_user.id)


@router.callback_query(OrderStates.additional_instructions, F.data == "order:skip")
async def skip_additional(callback: CallbackQuery, state: FSMContext):
    await state.update_data(additional_instructions=None)
    await state.set_state(OrderStates.confirm)
    await callback.message.edit_text(t("common.loading"), parse_mode="HTML")
    await _show_confirm(callback.message, state, callback.from_user.id)
    await callback.answer()


# ══════════════════════════════════════════════════════════
# TASDIQLASH SAHIFASI
# ══════════════════════════════════════════════════════════
async def _show_confirm(message: Message, state: FSMContext, user_telegram_id: int):
    """
    Buyurtma ma'lumotlarini ko'rsatish va tasdiqlashni so'rash.

    FIX #7: Previously used `message.chat.id` to look up the user, which is
    unreliable when the Message object is taken from a CallbackQuery
    (callback.message) — that chat.id is the bot's message chat, not
    necessarily the user's Telegram ID (they differ in group chats and when
    the message was forwarded). The caller must always pass the authoritative
    telegram_id from `callback.from_user.id` or `message.from_user.id`.
    """
    data = await state.get_data()

    service_type = data.get("service_type", "")
    topic = data.get("topic", "")
    doc_language = data.get("doc_language", "uz")
    pages = data.get("pages", 10)
    university_format = data.get("university_format", False)

    price = calculate_price(service_type, pages, university_format)

    text = t("order.confirm_title")
    text += t("order.confirm_service", service=get_service_name(service_type))
    text += t("order.confirm_topic", topic=topic)
    text += t("order.confirm_language", language=get_doc_language_name(doc_language))
    text += t("order.confirm_pages", pages=pages)
    text += t("order.confirm_format", format=get_format_name(university_format))

    if university_format:
        if data.get("university_name"):
            text += t("order.confirm_university", university=data["university_name"])
        if data.get("faculty"):
            text += t("order.confirm_faculty", faculty=data["faculty"])
        if data.get("subject"):
            text += t("order.confirm_subject", subject=data["subject"])
        if data.get("student_name"):
            text += t("order.confirm_student", student=data["student_name"])
        if data.get("teacher_name"):
            text += t("order.confirm_teacher", teacher=data["teacher_name"])
        if data.get("group_number"):
            text += t("order.confirm_group", group=data["group_number"])

    async with DBManager() as db:
        user = await db.users.get_by_telegram_id(user_telegram_id)
        can_trial = user and not user.trial_used and user.free_attempts_left > 0

    if can_trial:
        text += t("order.confirm_free")
    else:
        text += t("order.confirm_price", price=format_price(price))

    await state.update_data(price=str(price), is_free=can_trial)

    await message.answer(
        text=text,
        reply_markup=confirm_order_kb(),
        parse_mode="HTML",
    )


# ══════════════════════════════════════════════════════════
# 7. TASDIQLASH / BEKOR QILISH
# ══════════════════════════════════════════════════════════
@router.callback_query(OrderStates.confirm, F.data == "order:confirm")
async def confirm_order(callback: CallbackQuery, state: FSMContext):
    """Buyurtmani DB ga saqlash va to'lov/generatsiyaga o'tish"""
    data = await state.get_data()
    user_id = callback.from_user.id

    service_type = data.get("service_type")
    price = Decimal(data.get("price", "0"))
    is_free = data.get("is_free", False)

    async with DBManager() as db:
        user = await db.users.get_by_telegram_id(user_id)
        if not user:
            await callback.answer("❌ Foydalanuvchi topilmadi", show_alert=True)
            return

        # Buyurtma yaratish
        order = await db.orders.create_order(
            user_id=user.id,
            service_type=service_type,
            topic=data.get("topic", ""),
            doc_language=data.get("doc_language", "uz"),
            pages=data.get("pages", 10),
            price=price,
            is_free=is_free,
            university_format=data.get("university_format", False),
            university_name=data.get("university_name"),
            faculty=data.get("faculty"),
            subject=data.get("subject"),
            student_name=data.get("student_name"),
            teacher_name=data.get("teacher_name"),
            group_number=data.get("group_number"),
            additional_instructions=data.get("additional_instructions"),
        )

        # Trial ishlatildi
        if is_free:
            await db.users.mark_trial_used(user_id)

    await state.clear()

    if is_free:
        # Bepul — to'g'ri generatsiyaga
        await callback.message.edit_text(
            text=t("order.processing"),
            parse_mode="HTML",
        )
        # Celery task yuborish
        from workers.tasks.generation import generate_document
        generate_document.delay(order.id)
    else:
        # To'lov kerak
        await callback.message.edit_text(
            text=t("payment.title", amount=format_price(price)),
            reply_markup=payment_provider_kb(order.id),
            parse_mode="HTML",
        )

    await callback.answer()


@router.callback_query(OrderStates.confirm, F.data == "order:cancel")
async def cancel_order(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        text=t("order.cancelled"),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(OrderStates.confirm, F.data == "order:edit")
async def edit_order(callback: CallbackQuery, state: FSMContext):
    """Buyurtmani qayta boshlash"""
    data = await state.get_data()
    service_type = data.get("service_type", "referat")

    await state.set_state(OrderStates.topic)
    await callback.message.edit_text(
        text=t("order.enter_topic"),
        parse_mode="HTML",
    )
    await callback.answer()


# ══════════════════════════════════════════════════════════
# ORQAGA TUGMASI
# ══════════════════════════════════════════════════════════
@router.callback_query(F.data == "order:back")
async def order_back(callback: CallbackQuery, state: FSMContext):
    """Oldingi bosqichga qaytish"""
    current_state = await state.get_state()

    state_flow = [
        OrderStates.topic,
        OrderStates.doc_language,
        OrderStates.pages,
        OrderStates.university_format,
        OrderStates.university_name,
        OrderStates.faculty,
        OrderStates.subject,
        OrderStates.student_name,
        OrderStates.teacher_name,
        OrderStates.group_number,
        OrderStates.additional_instructions,
        OrderStates.confirm,
    ]

    state_names = [s.state for s in state_flow]

    if current_state in state_names:
        idx = state_names.index(current_state)
        if idx > 0:
            await state.set_state(state_flow[idx - 1])

    await callback.answer()


# ══════════════════════════════════════════════════════════
# BUYURTMA KO'RISH
# ══════════════════════════════════════════════════════════
@router.callback_query(F.data.startswith("order:view:"))
async def view_order(callback: CallbackQuery):
    order_id = callback.data.split(":")[2]

    async with DBManager() as db:
        order = await db.orders.get_by_id_with_user(order_id)

    if not order:
        await callback.answer(t("admin.order_not_found"), show_alert=True)
        return

    from locales.i18n import get_status_name
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton

    status = get_status_name(order.status)
    text = (
        f"📋 <b>Buyurtma #{order.id[:8]}...</b>\n\n"
        f"🔹 Xizmat: <b>{get_service_name(order.service_type)}</b>\n"
        f"🔹 Mavzu: <b>{order.topic}</b>\n"
        f"🔹 Holat: <b>{status}</b>\n"
        f"🔹 Narx: <b>{format_price(order.price)} so'm</b>\n"
        f"📅 Sana: <b>{order.created_at.strftime('%d.%m.%Y %H:%M')}</b>\n"
    )

    builder = InlineKeyboardBuilder()

    # Agar fayl tayyor bo'lsa
    if order.file_url_docx or order.file_url_pdf or order.file_url_pptx:
        builder.row(
            InlineKeyboardButton(
                text="📥 Fayllarni ko'rish",
                callback_data=f"order:files:{order.id}"
            )
        )

    builder.row(
        InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu:my_orders")
    )

    await callback.message.edit_text(
        text=text,
        reply_markup=builder.as_markup(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("order:retry:"))
async def retry_order(callback: CallbackQuery):
    """Muvaffaqiyatsiz buyurtmani qayta urinish"""
    order_id = callback.data.split(":")[2]

    async with DBManager() as db:
        order = await db.orders.get_by_id(order_id)
        if not order or order.status not in ("failed",):
            await callback.answer("❌ Qayta urinib bo'lmaydi", show_alert=True)
            return

        retry_count = await db.orders.increment_retry(order_id)

    if retry_count > 3:
        await callback.answer(
            "❌ Maksimal urinishlar soni oshib ketdi. Admin bilan bog'laning.",
            show_alert=True,
        )
        return

    from workers.tasks.generation import generate_document
    generate_document.delay(order_id)

    await callback.message.edit_text(
        text=t("order.processing"),
        parse_mode="HTML",
    )
    await callback.answer("🔄 Qayta generatsiya boshlandi")
