from functools import lru_cache
from typing import List
from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ─── BOT ──────────────────────────────────────────────
    bot_token: str
    bot_username: str = "EduBotUz_bot"

    # ─── ADMIN ────────────────────────────────────────────
    admin_ids: List[int] = []
    admin_channel_id: int = 0

    @field_validator("admin_ids", mode="before")
    @classmethod
    def parse_admin_ids(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(",") if x.strip()]
        return v

    # ─── KANAL (MAJBURIY OBUNA) ───────────────────────────
    required_channel_id: int
    required_channel_username: str = "@EduBotUz"

    # ─── DATABASE ─────────────────────────────────────────
    database_url: str
    db_pool_size: int = 10
    db_max_overflow: int = 20
    db_echo: bool = False

    # ─── REDIS ────────────────────────────────────────────
    redis_url: str
    redis_password: str = ""

    # ─── CELERY ───────────────────────────────────────────
    celery_broker_url: str
    celery_result_backend: str

    # ─── AI ───────────────────────────────────────────────
    openai_api_key: str
    openai_model: str = "gpt-4o"
    anthropic_api_key: str = ""
    ai_fallback_enabled: bool = True
    ai_max_retries: int = 3
    ai_timeout: int = 120

    # ─── STORAGE ──────────────────────────────────────────
    minio_endpoint: str = "minio:9000"
    minio_access_key: str = "minioadmin"
    minio_secret_key: str = "minioadmin123"
    minio_bucket: str = "edubot-files"
    minio_secure: bool = False

    # ─── TO'LOV: CLICK ────────────────────────────────────
    click_service_id: str = ""
    click_merchant_id: str = ""
    click_secret_key: str = ""
    click_merchant_user_id: str = ""

    # ─── TO'LOV: PAYME ────────────────────────────────────
    payme_merchant_id: str = ""
    payme_key: str = ""
    payme_test_key: str = ""
    payme_test_mode: bool = True

    # ─── TO'LOV: HUMO ─────────────────────────────────────
    humo_merchant_id: str = ""
    humo_secret_key: str = ""
    humo_api_url: str = "https://api.humo.uz"

    # ─── WEBHOOK ──────────────────────────────────────────
    webhook_host: str = ""
    webhook_path: str = "/webhook/bot"
    payment_webhook_path: str = "/webhook/payment"
    webhook_secret: str = ""

    # ─── API ──────────────────────────────────────────────
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    api_secret_key: str = "change_me_in_production"

    # ─── MONITORING ───────────────────────────────────────
    sentry_dsn: str = ""
    log_level: str = "INFO"

    # ─── FAYLLAR ──────────────────────────────────────────
    file_expiry_days: int = 7
    max_file_size_mb: int = 50
    temp_dir: str = "/tmp/edubot"

    # ─── NARXLAR (UZS tiyin) ──────────────────────────────
    price_independent: int = 15000
    price_referat: int = 20000
    price_presentation: int = 25000
    price_course_work: int = 80000
    price_diploma: int = 250000

    # ─── QULAY XUSUSIYATLAR ───────────────────────────────
    @property
    def webhook_url(self) -> str:
        return f"{self.webhook_host}{self.webhook_path}"

    @property
    def is_webhook_mode(self) -> bool:
        return bool(self.webhook_host)

    @property
    def prices(self) -> dict:
        return {
            "independent": self.price_independent,
            "referat": self.price_referat,
            "presentation": self.price_presentation,
            "course_work": self.price_course_work,
            "diploma": self.price_diploma,
        }


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
