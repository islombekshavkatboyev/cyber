from aiogram.filters import BaseFilter
from aiogram.types import Message, CallbackQuery

from bot.config import settings


class AdminFilter(BaseFilter):
    """Faqat adminlarga ruxsat beruvchi filter"""

    async def __call__(self, event: Message | CallbackQuery) -> bool:
        if isinstance(event, Message):
            user_id = event.from_user.id if event.from_user else None
        elif isinstance(event, CallbackQuery):
            user_id = event.from_user.id if event.from_user else None
        else:
            return False

        return user_id in settings.admin_ids
