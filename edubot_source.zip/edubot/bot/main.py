"""
EduBot — Asosiy kirish nuqtasi.

Ishga tushirish:
    python -m bot.main

Rejimlar:
    - Webhook (production): WEBHOOK_HOST .env da to'ldirilgan bo'lsa
    - Polling (development): WEBHOOK_HOST bo'sh bo'lsa
"""
import asyncio
import sys
from pathlib import Path

import sentry_sdk
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.redis import RedisStorage
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
from aiohttp import web
from loguru import logger

from bot.config import settings
from bot.handlers import get_main_router
from bot.middlewares import (
    AuthMiddleware,
    LoggingMiddleware,
    RateLimitMiddleware,
    SubscriptionMiddleware,
)
from database.connection import init_db, close_db


# ─── Logging sozlash ──────────────────────────────────────
def setup_logging():
    # CRASH #8 FIX: create logs/ BEFORE loguru tries to open the file handle.
    # on_startup() created this directory too late — logging is configured first.
    Path("logs").mkdir(exist_ok=True)

    logger.remove()
    logger.add(
        sys.stdout,
        level=settings.log_level,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{line}</cyan> | "
            "<level>{message}</level>"
        ),
        colorize=True,
    )
    logger.add(
        "logs/edubot_{time:YYYY-MM-DD}.log",
        level="INFO",
        rotation="00:00",
        retention="30 days",
        compression="gz",
        encoding="utf-8",
    )


# ─── Sentry ───────────────────────────────────────────────
def setup_sentry():
    if settings.sentry_dsn:
        sentry_sdk.init(
            dsn=settings.sentry_dsn,
            traces_sample_rate=0.1,
            environment="production" if settings.is_webhook_mode else "development",
        )
        logger.info("Sentry ulandi")


# ─── Bot va Dispatcher ────────────────────────────────────
def create_bot() -> Bot:
    return Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )


async def create_dispatcher(bot: Bot) -> Dispatcher:
    """
    Dispatcher yaratish — storage, middlewares, handlers.

    FIX #3: SubscriptionMiddleware is registered ONLY here, not again in
    on_startup. Previously it was registered in a dead stub AND again in
    on_startup, causing every update to be checked twice.

    FIX #4: Bot is passed in so startup/shutdown closures can reference it
    properly without relying on dp["bot"] dict-access which does not work.

    FIX #9: Removed the dead line `bot = dp["bot"] if "bot" in dp else None`.
    Dispatcher does not support dict-style key lookup for the bot instance.
    """

    # FSM Storage
    if settings.redis_url:
        try:
            storage = RedisStorage.from_url(settings.redis_url)
            logger.info("Redis FSM storage ulandi")
        except Exception as e:
            logger.warning(f"Redis ulanmadi, MemoryStorage ishlatilmoqda: {e}")
            storage = MemoryStorage()
    else:
        storage = MemoryStorage()
        logger.info("MemoryStorage ishlatilmoqda (development)")

    dp = Dispatcher(storage=storage)

    # ─── Middlewares (tartib muhim!) ───────────────────────
    # 1. Logging — har bir so'rovni loglash
    dp.update.outer_middleware(LoggingMiddleware())

    # 2. Auth — foydalanuvchini topish/yaratish, ban tekshirish
    dp.update.outer_middleware(AuthMiddleware())

    # 3. Rate Limiting — spam himoyasi
    if settings.redis_url:
        import redis.asyncio as aioredis
        redis_client = aioredis.from_url(settings.redis_url)
        dp.update.outer_middleware(RateLimitMiddleware(redis_client))
        logger.info("Rate limiting yoqildi")
        sub_redis = aioredis.from_url(settings.redis_url)
    else:
        sub_redis = None

    # 4. Subscription middleware — registered ONCE here with the real bot
    #    (FIX #3: removed duplicate registration that was in on_startup)
    dp.update.outer_middleware(
        SubscriptionMiddleware(bot=bot, redis_client=sub_redis)
    )
    logger.info("Subscription middleware yoqildi")

    # ─── Handlerlar ───────────────────────────────────────
    dp.include_router(get_main_router())

    return dp


# ══════════════════════════════════════════════════════════
# STARTUP / SHUTDOWN
# ══════════════════════════════════════════════════════════
async def on_startup(bot: Bot):
    """Bot ishga tushganda"""
    logger.info("EduBot ishga tushmoqda...")

    # DB ulanish
    await init_db()
    logger.info("PostgreSQL ulandi")

    # Temp papka va logs papkasini yaratish
    # (logs/ is already created by setup_logging, but temp_dir still needs it)
    Path(settings.temp_dir).mkdir(parents=True, exist_ok=True)

    # Webhook yoki polling
    if settings.is_webhook_mode:
        await bot.set_webhook(
            url=settings.webhook_url,
            secret_token=settings.webhook_secret,
            drop_pending_updates=True,
        )
        logger.info(f"Webhook o'rnatildi: {settings.webhook_url}")
    else:
        await bot.delete_webhook(drop_pending_updates=True)
        logger.info("Polling rejimi")

    # Admin xabardor qilish
    for admin_id in settings.admin_ids:
        try:
            await bot.send_message(
                chat_id=admin_id,
                text=(
                    "🤖 <b>EduBot ishga tushdi!</b>\n\n"
                    f"Rejim: {'🌐 Webhook' if settings.is_webhook_mode else '🔄 Polling'}\n"
                    f"Log darajasi: {settings.log_level}"
                ),
                parse_mode="HTML",
            )
        except Exception:
            pass

    logger.success("✅ EduBot muvaffaqiyatli ishga tushdi!")


async def on_shutdown(bot: Bot):
    """Bot to'xtaganda"""
    logger.info("EduBot to'xtatilmoqda...")

    await close_db()

    if settings.is_webhook_mode:
        await bot.delete_webhook()

    await bot.session.close()
    logger.info("EduBot to'xtatildi.")


# ══════════════════════════════════════════════════════════
# POLLING REJIMI
# ══════════════════════════════════════════════════════════
async def run_polling():
    """Development uchun polling rejimi"""
    bot = create_bot()
    dp = await create_dispatcher(bot)

    # FIX #4: startup/shutdown handlers now receive the correct signature.
    # aiogram v3 calls registered startup handlers with no positional args,
    # so we use functools.partial / closures to inject `bot`.
    async def _startup():
        await on_startup(bot)

    async def _shutdown():
        await on_shutdown(bot)

    dp.startup.register(_startup)
    dp.shutdown.register(_shutdown)

    logger.info("Polling boshlandi...")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


# ══════════════════════════════════════════════════════════
# WEBHOOK REJIMI
# ══════════════════════════════════════════════════════════
async def run_webhook():
    """Production uchun webhook rejimi (aiohttp server)"""
    bot = create_bot()
    dp = await create_dispatcher(bot)

    await on_startup(bot)

    app = web.Application()

    # Webhook handler
    webhook_handler = SimpleRequestHandler(
        dispatcher=dp,
        bot=bot,
        secret_token=settings.webhook_secret,
    )
    webhook_handler.register(app, path=settings.webhook_path)
    setup_application(app, dp, bot=bot)

    # aiohttp server
    runner = web.AppRunner(app)
    await runner.setup()

    site = web.TCPSite(
        runner,
        host="0.0.0.0",
        port=8080,
    )
    await site.start()

    logger.info("Webhook server port 8080 da ishlamoqda")
    logger.info(f"Webhook path: {settings.webhook_path}")

    # Abadiy ishlash
    try:
        await asyncio.Event().wait()
    finally:
        await on_shutdown(bot)
        await runner.cleanup()


# ══════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════
def main():
    setup_logging()
    setup_sentry()

    logger.info(
        f"EduBot v1.0.0 | "
        f"Rejim: {'Webhook' if settings.is_webhook_mode else 'Polling'}"
    )

    if settings.is_webhook_mode:
        asyncio.run(run_webhook())
    else:
        asyncio.run(run_polling())


if __name__ == "__main__":
    main()
