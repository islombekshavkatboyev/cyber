"""
S3Client — MinIO/AWS S3 bilan fayl saqlash.
Fayllar {order_id}/{filename} formatida saqlanadi.
"""
import io
from datetime import timedelta
from pathlib import Path

from loguru import logger
from minio import Minio
from minio.error import S3Error

from bot.config import settings


class S3Client:

    def __init__(self):
        self.client = Minio(
            endpoint=settings.minio_endpoint,
            access_key=settings.minio_access_key,
            secret_key=settings.minio_secret_key,
            secure=settings.minio_secure,
        )
        self.bucket = settings.minio_bucket
        self._ensure_bucket()

    def _ensure_bucket(self):
        """
        Bucket mavjud emasligini tekshirib yaratish.

        CRASH #7 FIX: original code crashed immediately if MinIO wasn't
        ready. Now retries with exponential backoff up to 5 times.
        """
        import time
        for attempt in range(5):
            try:
                if not self.client.bucket_exists(self.bucket):
                    self.client.make_bucket(self.bucket)
                    logger.info(f"[S3] Bucket yaratildi: {self.bucket}")
                return
            except S3Error as e:
                wait = 2 ** attempt
                logger.warning(f"[S3] Bucket tekshirish {attempt+1}/5, {wait}s kutilmoqda: {e}")
                time.sleep(wait)
        logger.error(f"[S3] MinIO ga ulanib bo'lmadi — bucket yaratilmadi: {self.bucket}")

    def upload_bytes(
        self,
        data: bytes,
        object_name: str,
        content_type: str = "application/octet-stream",
    ) -> str:
        """
        Bytes ni S3 ga yuklash.
        Returns: object_name (URL emas — presigned URL kerak bo'lsa get_url ishlatiladi)
        """
        try:
            self.client.put_object(
                bucket_name=self.bucket,
                object_name=object_name,
                data=io.BytesIO(data),
                length=len(data),
                content_type=content_type,
            )
            logger.info(f"[S3] Yuklandi: {object_name} ({len(data)} bytes)")
            return object_name
        except S3Error as e:
            logger.error(f"[S3] Yuklash xatolik: {e}")
            raise

    def get_presigned_url(
        self,
        object_name: str,
        expires_hours: int = 24,
    ) -> str:
        """
        Vaqtinchalik URL yaratish (foydalanuvchiga yuborish uchun).
        Default: 24 soat amal qiladi.
        """
        try:
            url = self.client.presigned_get_object(
                bucket_name=self.bucket,
                object_name=object_name,
                expires=timedelta(hours=expires_hours),
            )
            return url
        except S3Error as e:
            logger.error(f"[S3] URL yaratish xatolik: {e}")
            raise

    def download_bytes(self, object_name: str) -> bytes:
        """S3 dan bytes yuklab olish (Telegram ga yuborish uchun)"""
        try:
            response = self.client.get_object(self.bucket, object_name)
            data = response.read()
            response.close()
            return data
        except S3Error as e:
            logger.error(f"[S3] Yuklash xatolik: {e}")
            raise

    def delete_object(self, object_name: str):
        """Faylni o'chirish"""
        try:
            self.client.remove_object(self.bucket, object_name)
            logger.info(f"[S3] O'chirildi: {object_name}")
        except S3Error as e:
            logger.warning(f"[S3] O'chirish xatolik: {e}")

    def delete_order_files(self, order_id: str):
        """Buyurtmaga tegishli barcha fayllarni o'chirish"""
        prefix = f"orders/{order_id}/"
        try:
            objects = self.client.list_objects(self.bucket, prefix=prefix)
            for obj in objects:
                self.delete_object(obj.object_name)
        except S3Error as e:
            logger.warning(f"[S3] Buyurtma fayllari o'chirish xatolik: {e}")

    @staticmethod
    def make_object_name(order_id: str, filename: str) -> str:
        """S3 da fayl yo'li: orders/{order_id}/{filename}"""
        return f"orders/{order_id}/{filename}"

    # Content type map
    CONTENT_TYPES = {
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".pdf": "application/pdf",
        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    }

    @classmethod
    def get_content_type(cls, filename: str) -> str:
        ext = Path(filename).suffix.lower()
        return cls.CONTENT_TYPES.get(ext, "application/octet-stream")


# Global instance
_s3_client: S3Client | None = None


def get_s3_client() -> S3Client:
    global _s3_client
    if _s3_client is None:
        _s3_client = S3Client()
    return _s3_client
