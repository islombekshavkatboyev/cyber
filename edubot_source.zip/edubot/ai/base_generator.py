"""
BaseGenerator — barcha generatorlar uchun asosiy klass.
OpenAI + Anthropic fallback bilan.
"""
import asyncio
import hashlib
import time
from typing import Optional

from loguru import logger
from openai import AsyncOpenAI

from ai.context_builder import GenerationContext
from bot.config import settings


class BaseGenerator:
    """
    Barcha AI generatorlar shu klassdan meros oladi.
    - OpenAI GPT-4o asosiy model
    - Anthropic Claude fallback (agar openai fail bo'lsa)
    - Avtomatik retry (3 marta)
    - Token va xarajat hisoblash
    - Generation log yozish
    """

    DEFAULT_MODEL = "gpt-4o"
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # soniya

    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.openai_api_key)
        self._use_anthropic_fallback = settings.ai_fallback_enabled

    async def _call_llm(
        self,
        system_prompt: str,
        user_prompt: str,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4000,
        stage: str = "unknown",
        ctx: Optional[GenerationContext] = None,
    ) -> tuple[str, int, float]:
        """
        LLM ga so'rov yuborish.
        Returns: (text, tokens_used, cost_usd)
        """
        model = model or self.DEFAULT_MODEL
        start_time = time.monotonic()

        for attempt in range(self.MAX_RETRIES):
            try:
                response = await asyncio.wait_for(
                    self.client.chat.completions.create(
                        model=model,
                        messages=[
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_prompt},
                        ],
                        temperature=temperature,
                        max_tokens=max_tokens,
                    ),
                    timeout=settings.ai_timeout,
                )

                content = response.choices[0].message.content or ""
                tokens = response.usage.total_tokens if response.usage else 0
                cost = self._calc_cost(model, response.usage)
                duration_ms = int((time.monotonic() - start_time) * 1000)

                # Log yozish
                await self._log_generation(
                    ctx=ctx,
                    stage=stage,
                    model=model,
                    tokens=tokens,
                    cost=cost,
                    duration_ms=duration_ms,
                    prompt_hash=self._hash_prompt(user_prompt),
                    success=True,
                )

                if ctx:
                    ctx.total_tokens_used += tokens
                    ctx.total_cost_usd += cost

                logger.debug(
                    f"LLM [{stage}] tokens={tokens} cost=${cost:.4f} {duration_ms}ms"
                )
                return content, tokens, cost

            except asyncio.TimeoutError:
                logger.warning(f"LLM timeout [{stage}] attempt {attempt + 1}")
                if attempt < self.MAX_RETRIES - 1:
                    await asyncio.sleep(self.RETRY_DELAY * (attempt + 1))

            except Exception as e:
                logger.error(f"LLM error [{stage}] attempt {attempt + 1}: {e}")

                # Anthropic fallback
                if self._use_anthropic_fallback and attempt == self.MAX_RETRIES - 1:
                    try:
                        return await self._call_anthropic(
                            system_prompt, user_prompt, max_tokens, stage, ctx
                        )
                    except Exception as fe:
                        logger.error(f"Anthropic fallback failed: {fe}")

                if attempt < self.MAX_RETRIES - 1:
                    await asyncio.sleep(self.RETRY_DELAY * (attempt + 1))

        raise RuntimeError(f"LLM {self.MAX_RETRIES} ta urinishdan keyin ham muvaffaqiyatsiz")

    async def _call_anthropic(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        stage: str,
        ctx: Optional[GenerationContext],
    ) -> tuple[str, int, float]:
        """Anthropic Claude fallback"""
        import anthropic

        client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
        response = await client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=max_tokens,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )

        content = response.content[0].text if response.content else ""
        tokens = (response.usage.input_tokens + response.usage.output_tokens
                  if response.usage else 0)
        cost = tokens * 0.000003  # taxminiy Claude narxi

        logger.info(f"Anthropic fallback muvaffaqiyatli [{stage}]")
        return content, tokens, cost

    @staticmethod
    def _calc_cost(model: str, usage) -> float:
        """GPT-4o narx hisoblash (USD)"""
        if not usage:
            return 0.0
        # GPT-4o: input $5/1M, output $15/1M tokens
        if "gpt-4o" in model:
            input_cost = (usage.prompt_tokens / 1_000_000) * 5.0
            output_cost = (usage.completion_tokens / 1_000_000) * 15.0
            return input_cost + output_cost
        # GPT-3.5: input $0.5/1M, output $1.5/1M
        elif "gpt-3.5" in model:
            input_cost = (usage.prompt_tokens / 1_000_000) * 0.5
            output_cost = (usage.completion_tokens / 1_000_000) * 1.5
            return input_cost + output_cost
        return 0.0

    @staticmethod
    def _hash_prompt(prompt: str) -> str:
        return hashlib.sha256(prompt.encode()).hexdigest()[:16]

    @staticmethod
    async def _log_generation(
        ctx: Optional[GenerationContext],
        stage: str,
        model: str,
        tokens: int,
        cost: float,
        duration_ms: int,
        prompt_hash: str,
        success: bool,
        error: Optional[str] = None,
    ):
        """GenerationLog DB ga yozish"""
        if not ctx:
            return
        try:
            from database.db_manager import DBManager
            from database.models import GenerationLog
            from datetime import datetime

            async with DBManager() as db:
                log = GenerationLog(
                    order_id=ctx.order_id,
                    stage=stage,
                    model_used=model,
                    tokens_used=tokens,
                    cost_usd=cost,
                    duration_ms=duration_ms,
                    prompt_hash=prompt_hash,
                    success=success,
                    error=error,
                    created_at=datetime.utcnow(),
                )
                db._session.add(log)
        except Exception as e:
            logger.warning(f"Generation log yozishda xato: {e}")
