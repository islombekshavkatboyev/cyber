"""
DiplomaGenerator — Diplom ishi uchun HEAVY CHUNK-BASED generator.
Katta hajm (60-100 sahifa) — kengaytirilgan chunk arxitekturasi.
"""
import asyncio
from ai.base_generator import BaseGenerator
from ai.context_builder import GenerationContext
from loguru import logger


class DiplomaGenerator(BaseGenerator):
    """
    Diplom ishi arxitekturasi:
    1. Kengaytirilgan outline (batafsil reja)
    2. Annotatsiya (abstract)
    3. Kirish (2-3 sahifa)
    4. Adabiyotlar sharhi (bob 1)
    5. Metodologiya (bob 2)
    6. Asosiy tadqiqot (bob 3, 4)
    7. Natijalar va muhokama (bob 5)
    8. Xulosa
    9. Adabiyotlar ro'yxati (20+ manba)
    """

    async def generate(self, ctx: GenerationContext) -> str:
        logger.info(f"[Diploma] Boshlandi: {ctx.topic[:50]} ({ctx.pages} sahifa)")

        # 1. Batafsil reja
        outline = await self._generate_detailed_outline(ctx)
        ctx.outline = outline
        chapters = self._parse_chapters(outline)
        logger.info(f"[Diploma] Reja: {len(chapters)} ta bob/qism")

        # 2. Annotatsiya
        abstract = await self._generate_abstract(ctx)
        ctx.add_chunk(abstract)
        await asyncio.sleep(1)

        # 3. Kirish
        intro = await self._generate_intro(ctx)
        ctx.add_chunk(intro)
        await asyncio.sleep(1.5)

        # 4. Boblar (kengaytirilgan)
        for i, chapter in enumerate(chapters, 1):
            logger.info(f"[Diploma] {i}/{len(chapters)} bob: {chapter[:40]}")
            chapter_text = await self._generate_chapter(ctx, chapter, i, len(chapters))
            ctx.add_chunk(chapter_text)
            await asyncio.sleep(2)  # API rate limit uchun

        # 5. Xulosa va tavsiyalar
        conclusion = await self._generate_conclusion(ctx)
        ctx.add_chunk(conclusion)
        await asyncio.sleep(1)

        # 6. Adabiyotlar
        references = await self._generate_references(ctx)
        ctx.add_chunk(references)

        full_text = ctx.get_full_text()
        logger.info(
            f"[Diploma] Tugadi. Jami: {ctx.total_tokens_used} token, "
            f"${ctx.total_cost_usd:.4f}, {len(full_text.split())} so'z"
        )
        return full_text

    async def _generate_detailed_outline(self, ctx: GenerationContext) -> str:
        system = self._system_prompt(ctx.doc_language)

        if ctx.doc_language == "uz":
            prompt = f"""«{ctx.topic}» mavzusidagi BITIRUV MALAKAVIY ISH uchun BATAFSIL REJA tuzing.

Ish hajmi: {ctx.pages} sahifa
Fan: {ctx.subject or 'Ko\'rsatilmagan'}
Fakultet: {ctx.faculty or 'Ko\'rsatilmagan'}

MAJBURIY TARKIB:
- Annotatsiya (O'zbek va ingliz tilida)
- Kirish
- I Bob: Nazariy-metodologik asoslar (adabiyotlar sharhi)
- II Bob: Tadqiqot metodologiyasi va usullari
- III Bob: Asosiy tadqiqot natijalari va tahlil
- [IV Bob: ixtiyoriy, katta ishlar uchun]
- Xulosa va tavsiyalar
- Foydalanilgan adabiyotlar (20+ manba)
- Ilovalar (ixtiyoriy)

Har bir bobda 2-3 ta kichik bo'lim bo'lsin.
Faqat rejani chiqar, boshqa hech narsa yozma."""

        elif ctx.doc_language == "ru":
            prompt = f"""Составьте ПОДРОБНЫЙ ПЛАН дипломной работы по теме «{ctx.topic}».

Объём: {ctx.pages} страниц
Дисциплина: {ctx.subject or 'Не указана'}

ОБЯЗАТЕЛЬНАЯ СТРУКТУРА:
- Аннотация (на двух языках)
- Введение
- Глава I: Теоретико-методологические основы
- Глава II: Методология исследования
- Глава III: Результаты исследования и анализ
- Заключение и рекомендации
- Список использованной литературы (20+ источников)
- Приложения

Каждая глава: 2-3 подраздела. Только план, без лишнего текста."""

        else:
            prompt = f"""Create a DETAILED OUTLINE for a diploma/thesis on "{ctx.topic}".

Length: {ctx.pages} pages
Subject: {ctx.subject or 'Not specified'}

REQUIRED STRUCTURE:
- Abstract (bilingual)
- Introduction
- Chapter I: Theoretical and Methodological Foundations
- Chapter II: Research Methodology
- Chapter III: Results and Analysis
- Conclusion and Recommendations
- References (20+ sources)
- Appendices

Each chapter: 2-3 subsections. Output only the outline."""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.3,
            max_tokens=1500,
            stage="outline",
            ctx=ctx,
        )
        return text

    async def _generate_abstract(self, ctx: GenerationContext) -> str:
        system = self._system_prompt(ctx.doc_language)

        if ctx.doc_language == "uz":
            prompt = f"""«{ctx.topic}» mavzusidagi bitiruv malakaviy ish uchun ANNOTATSIYA yozing.

Talaba: {ctx.student_name or 'Ko\'rsatilmagan'}
Mutaxassislik: {ctx.faculty or 'Ko\'rsatilmagan'}

Annotatsiya tarkibi (100-150 so'z):
- Mavzuning dolzarbligi
- Tadqiqot maqsadi
- Qo'llanilgan metodlar
- Asosiy natijalar
- Kalit so'zlar (5-7 ta)

O'zbek va ingliz tilida yozing.
"Annotatsiya / Abstract" sarlavhasi bilan boshlang."""

        elif ctx.doc_language == "ru":
            prompt = f"""Напишите АННОТАЦИЮ для дипломной работы «{ctx.topic}».

Студент: {ctx.student_name or 'Не указан'}
Специальность: {ctx.faculty or 'Не указана'}

Аннотация (100-150 слов): актуальность, цель, методы, результаты, ключевые слова.
На русском и английском языках.
Начните с "Аннотация / Abstract"."""

        else:
            prompt = f"""Write an ABSTRACT for a thesis on "{ctx.topic}".

Student: {ctx.student_name or 'Not specified'}
Faculty: {ctx.faculty or 'Not specified'}

Abstract (100-150 words): relevance, objective, methods, results, keywords.
In English and the document language.
Start with "Abstract"."""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.5,
            max_tokens=800,
            stage="abstract",
            ctx=ctx,
        )
        return text

    async def _generate_intro(self, ctx: GenerationContext) -> str:
        system = self._system_prompt(ctx.doc_language)
        words = ctx.words_per_page * 3  # 3 sahifa

        if ctx.doc_language == "uz":
            prompt = f"""Bitiruv malakaviy ish: «{ctx.topic}»
Reja: {ctx.outline[:800]}

KIRISH qismini yozing ({words} so'z):
1. Mavzuning dolzarbligi va zarurati
2. Muammoning o'rganilganlik darajasi
3. Tadqiqotning maqsadi
4. Tadqiqotning vazifalari (5-7 ta)
5. Tadqiqotning ob'ekti
6. Tadqiqotning predmeti
7. Tadqiqot metodlari
8. Ishning nazariy va amaliy ahamiyati
9. Ishning tuzilishi

"Kirish" sarlavhasi bilan boshlang. To'liq va batafsil yozing."""

        elif ctx.doc_language == "ru":
            prompt = f"""Дипломная работа: «{ctx.topic}»
План: {ctx.outline[:800]}

Напишите ВВЕДЕНИЕ ({words} слов):
1. Актуальность и необходимость
2. Степень изученности проблемы
3. Цель исследования
4. Задачи (5-7)
5. Объект исследования
6. Предмет исследования
7. Методы исследования
8. Теоретическая и практическая значимость
9. Структура работы

Начните с "Введение". Пишите подробно."""

        else:
            prompt = f"""Thesis: "{ctx.topic}"
Outline: {ctx.outline[:800]}

Write INTRODUCTION ({words} words):
1. Relevance and necessity
2. State of research
3. Research objective
4. Research tasks (5-7)
5. Object of research
6. Subject of research
7. Research methods
8. Theoretical and practical significance
9. Structure of the work

Start with "Introduction". Write in detail."""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.6,
            max_tokens=3000,
            stage="introduction",
            ctx=ctx,
        )
        return text

    async def _generate_chapter(
        self,
        ctx: GenerationContext,
        chapter_title: str,
        chapter_num: int,
        total_chapters: int,
    ) -> str:
        system = self._system_prompt(ctx.doc_language)

        # Diplom uchun har bob kattaroq
        body_pages = ctx.pages - 8  # annotatsiya, kirish, xulosa, adabiyotlar
        words_per_chapter = max(800, (body_pages * ctx.words_per_page) // total_chapters)

        recent = ctx.get_recent_context(last_n=2)

        if ctx.doc_language == "uz":
            prompt = f"""Bitiruv malakaviy ish: «{ctx.topic}»
Talaba: {ctx.student_name or ''}  Fan: {ctx.subject or ''}

UMUMIY REJA:
{ctx.outline}

OLDINGI MATERIAL (qisqacha):
{recent if recent else "Bu birinchi bob."}

YOZING: {chapter_num}-BOB — {chapter_title}
Hajm: {words_per_chapter} so'z (batafsil yozing!)

TALABLAR:
✓ Bob sarlavhasi va kichik bo'limlarni ({chapter_num}.1, {chapter_num}.2, {chapter_num}.3) yozing
✓ Ilmiy manbalar va iqtiboslarni ko'rsating
✓ Jadvallar, raqamlar, statistik ma'lumotlar keltiring
✓ Oldingi bob bilan mantiqiy bog'lang
✓ Akademik-ilmiy uslub
✓ O'z tahlil va mulohazalaringizni kiriting"""

        elif ctx.doc_language == "ru":
            prompt = f"""Дипломная работа: «{ctx.topic}»
Студент: {ctx.student_name or ''}  Дисциплина: {ctx.subject or ''}

ПЛАН:
{ctx.outline}

ПРЕДЫДУЩИЙ МАТЕРИАЛ:
{recent if recent else "Это первая глава."}

ПИШИТЕ: ГЛАВА {chapter_num} — {chapter_title}
Объём: {words_per_chapter} слов (подробно!)

ТРЕБОВАНИЯ:
✓ Заголовок главы и подразделы ({chapter_num}.1, {chapter_num}.2, {chapter_num}.3)
✓ Ссылки на научные источники
✓ Таблицы, цифры, статистика
✓ Логическая связь с предыдущей главой
✓ Научный стиль
✓ Собственный анализ"""

        else:
            prompt = f"""Thesis: "{ctx.topic}"
Student: {ctx.student_name or ''}  Subject: {ctx.subject or ''}

OUTLINE:
{ctx.outline}

PREVIOUS MATERIAL:
{recent if recent else "This is the first chapter."}

WRITE: CHAPTER {chapter_num} — {chapter_title}
Length: {words_per_chapter} words (write in detail!)

REQUIREMENTS:
✓ Chapter heading and subsections ({chapter_num}.1, {chapter_num}.2, {chapter_num}.3)
✓ References to scientific sources
✓ Tables, figures, statistics
✓ Logical connection with previous chapter
✓ Academic style
✓ Original analysis"""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.7,
            max_tokens=5000,
            stage=f"chapter_{chapter_num}",
            ctx=ctx,
        )
        return text

    async def _generate_conclusion(self, ctx: GenerationContext) -> str:
        system = self._system_prompt(ctx.doc_language)
        words = ctx.words_per_page * 2

        summary = ctx.get_full_text()[:3000]

        if ctx.doc_language == "uz":
            prompt = f"""Bitiruv malakaviy ish: «{ctx.topic}»

ASOSIY MATERIAL XULASASI:
{summary}...

XULOSA VA TAVSIYALAR qismini yozing ({words} so'z):
1. Har bob bo'yicha asosiy xulosalar
2. Tadqiqot maqsadiga erishilganlik darajasi
3. Ilmiy-nazariy xulosalar
4. Amaliy tavsiyalar
5. Kelajakdagi tadqiqot yo'nalishlari

"Xulosa va tavsiyalar" sarlavhasi bilan boshlang."""

        elif ctx.doc_language == "ru":
            prompt = f"""Дипломная работа: «{ctx.topic}»

РЕЗЮМЕ МАТЕРИАЛА:
{summary}...

Напишите ЗАКЛЮЧЕНИЕ И РЕКОМЕНДАЦИИ ({words} слов):
1. Выводы по каждой главе
2. Степень достижения цели
3. Научно-теоретические выводы
4. Практические рекомендации
5. Перспективы дальнейших исследований

Начните с "Заключение и рекомендации"."""

        else:
            prompt = f"""Thesis: "{ctx.topic}"

MATERIAL SUMMARY:
{summary}...

Write CONCLUSION AND RECOMMENDATIONS ({words} words):
1. Conclusions per chapter
2. Achievement of objectives
3. Scientific and theoretical conclusions
4. Practical recommendations
5. Future research directions

Start with "Conclusion and Recommendations"."""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.5,
            max_tokens=2000,
            stage="conclusion",
            ctx=ctx,
        )
        return text

    async def _generate_references(self, ctx: GenerationContext) -> str:
        system = self._system_prompt(ctx.doc_language)

        if ctx.doc_language == "uz":
            prompt = f"""«{ctx.topic}» mavzusidagi bitiruv malakaviy ish uchun ADABIYOTLAR RO'YXATINI tuzing.

Fan: {ctx.subject or 'Umumiy'}
Kamida 25 ta manba (GOST/APA formatida):
- 8-10 ta kitob (monografiyalar, darsliklar)
- 8-10 ta ilmiy maqola (jurnal maqolalari)
- 3-5 ta internet manbalar (URL bilan)
- 2-3 ta o'zbek tilidagi manba
- 2-3 ta xorijiy manba (ingliz tilida)
- Qonun va me'yoriy hujjatlar (mavzuga qarab)

"Foydalanilgan adabiyotlar ro'yxati" sarlavhasi bilan boshlang.
Raqam bilan tartib bering."""

        elif ctx.doc_language == "ru":
            prompt = f"""Составьте СПИСОК ЛИТЕРАТУРЫ для дипломной работы «{ctx.topic}».

Минимум 25 источников, ГОСТ:
- 8-10 монографий и учебников
- 8-10 научных статей
- 3-5 интернет-источников
- Иностранные источники на английском
- Нормативные документы (при необходимости)

Начните с "Список использованной литературы".
Нумерация по порядку."""

        else:
            prompt = f"""Create REFERENCES for a thesis on "{ctx.topic}".

Minimum 25 sources, APA format:
- 8-10 books (monographs, textbooks)
- 8-10 journal articles
- 3-5 online sources with URLs
- Mix of recent (last 10 years) and classic sources
- Include international sources

Start with "References". Number sequentially."""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.3,
            max_tokens=2000,
            stage="references",
            ctx=ctx,
        )
        return text

    def _parse_chapters(self, outline: str) -> list[str]:
        chapters = []
        for line in outline.split("\n"):
            line = line.strip()
            if any([
                "BOB" in line.upper() and len(line) > 5,
                "ГЛАВА" in line.upper() and len(line) > 7,
                "CHAPTER" in line.upper() and len(line) > 8,
            ]):
                # Kichik bo'limlar emas — faqat asosiy boblar
                if not ("." in line and line.count(".") > 1):
                    chapters.append(line)

        if not chapters:
            chapters = [
                "Nazariy va metodologik asoslar",
                "Tadqiqot metodologiyasi",
                "Asosiy tadqiqot natijalari va tahlil",
                "Natijalar va muhokama",
            ]
        return chapters[:5]

    @staticmethod
    def _system_prompt(lang: str) -> str:
        prompts = {
            "uz": """Siz o'zbek tilidagi bitiruv malakaviy ish (diplom ishi) yozuvchi yuqori malakali akademik mutaxassississiz.
Yozish uslubi: rasmiy-ilmiy, akademik. Har bir qismni to'liq, chuqur va sifatli yozing.
Plagiatga mutlaqo yo'l qo'ymang. Mantiqiy ketma-ketlik va uzviylikni saqlang.
Ilmiy atamalar, raqamlar, faktlar va manbalar bilan boyiting.""",

            "ru": """Вы — высококвалифицированный специалист по написанию дипломных работ (ВКР) на русском языке.
Стиль: строго академический, научный. Каждую часть пишите полно, глубоко и качественно.
Абсолютно избегайте плагиата. Сохраняйте логику и последовательность.
Насыщайте научными терминами, цифрами, фактами, ссылками.""",

            "en": """You are a highly qualified specialist in writing theses and dissertations in English.
Style: strictly academic, scholarly. Write each section completely, deeply, and with quality.
Absolutely avoid plagiarism. Maintain logical sequence and coherence.
Enrich with academic terminology, statistics, facts, and citations.""",
        }
        return prompts.get(lang, prompts["uz"])
