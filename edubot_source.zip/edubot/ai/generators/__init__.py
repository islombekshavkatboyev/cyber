from .referat import ReferatGenerator
from .independent import IndependentGenerator
from .course_work import CourseWorkGenerator
from .diploma import DiplomaGenerator
from .presentation import PresentationGenerator

__all__ = [
    "ReferatGenerator",
    "IndependentGenerator",
    "CourseWorkGenerator",
    "DiplomaGenerator",
    "PresentationGenerator",
]
