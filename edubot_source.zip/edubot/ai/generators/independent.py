"""
IndependentGenerator — Mustaqil ish uchun single-shot generator.
"""
from ai.base_generator import BaseGenerator
from ai.context_builder import GenerationContext

SYSTEM_PROMPTS = {
    "uz": """Siz o'zbek tilidagi akademik mustaqil ish yozuvchi mutaxassississiz.
Uslub: rasmiy-akademik. Kichik hajmda (5-30 sahifa) to'liq va mazmunan boy matn yozing.
Kirish, asosiy qism, xulosa, adabiyotlar bo'lishi shart.""",

    "ru": """Вы специалист по написанию самостоятельных работ на русском языке.
Стиль: официально-академический. Небольшой объём (5-30 страниц), но содержательный.
Обязательно: введение, основная часть, заключение, список литературы.""",

    "en": """You are an expert in writing academic independent assignments.
Style: formal academic. Concise (5-30 pages) but content-rich.
Required: introduction, main body, conclusion, references.""",
}


class IndependentGenerator(BaseGenerator):

    async def generate(self, ctx: GenerationContext) -> str:
        system = SYSTEM_PROMPTS.get(ctx.doc_language, SYSTEM_PROMPTS["uz"])
        user_prompt = self._build_prompt(ctx)

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=user_prompt,
            temperature=0.7,
            max_tokens=5000,
            stage="independent_full",
            ctx=ctx,
        )

        ctx.add_chunk(text, tokens, cost)
        return text

    def _build_prompt(self, ctx: GenerationContext) -> str:
        lang = ctx.doc_language
        target_words = ctx.target_words

        if lang == "uz":
            prompt = f"""Quyidagi mavzuda MUSTAQIL ISH yozing:

Mavzu: «{ctx.topic}»
Sahifalar: {ctx.pages} ({target_words} so'z)"""
            if ctx.subject:
                prompt += f"\nFan: {ctx.subject}"
            if ctx.additional_instructions:
                prompt += f"\nQo'shimcha ko'rsatmalar: {ctx.additional_instructions}"
            prompt += """

TUZILMA:
1. KIRISH — mavzuning dolzarbligi, maqsad
2. ASOSIY QISM — 2-3 bo'lim, har biri to'liq yozilsin
3. XULOSA — asosiy xulosalar
4. ADABIYOTLAR — 5-7 ta manba

Akademik uslubda, original matn yozing."""

        elif lang == "ru":
            prompt = f"""Напишите САМОСТОЯТЕЛЬНУЮ РАБОТУ:

Тема: «{ctx.topic}»
Страниц: {ctx.pages} ({target_words} слов)"""
            if ctx.subject:
                prompt += f"\nДисциплина: {ctx.subject}"
            if ctx.additional_instructions:
                prompt += f"\nДоп. указания: {ctx.additional_instructions}"
            prompt += """

СТРУКТУРА:
1. ВВЕДЕНИЕ
2. ОСНОВНАЯ ЧАСТЬ (2-3 раздела)
3. ЗАКЛЮЧЕНИЕ
4. СПИСОК ЛИТЕРАТУРЫ (5-7 источников)"""

        else:  # en
            prompt = f"""Write an INDEPENDENT ASSIGNMENT:

Topic: "{ctx.topic}"
Pages: {ctx.pages} (~{target_words} words)"""
            if ctx.subject:
                prompt += f"\nSubject: {ctx.subject}"
            if ctx.additional_instructions:
                prompt += f"\nAdditional notes: {ctx.additional_instructions}"
            prompt += """

STRUCTURE:
1. INTRODUCTION
2. MAIN BODY (2-3 sections)
3. CONCLUSION
4. REFERENCES (5-7 sources)"""

        return prompt
