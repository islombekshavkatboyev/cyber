"""
ReferatGenerator — Referat uchun single-shot generator.
Kichik hajm (10-40 sahifa), bitta so'rovda yoziladi.
"""
from ai.base_generator import BaseGenerator
from ai.context_builder import GenerationContext


SYSTEM_PROMPTS = {
    "uz": """Siz o'zbek tilida akademik referat yozuvchi mutaxasssissiz.
Yozish uslubi: rasmiy-akademik, ilmiy.
Plagiatga yo'l qo'ymang — o'z so'zlaringiz bilan yozing.
Har doim: kirish, asosiy qism (boblar bilan), xulosa, adabiyotlar ro'yxatini yozing.
Matn tuzilishi aniq va mantiqiy bo'lsin.""",

    "ru": """Вы — специалист по написанию академических рефератов на русском языке.
Стиль: официально-академический, научный.
Избегайте плагиата — пишите своими словами.
Всегда включайте: введение, основную часть (с разделами), заключение, список литературы.
Текст должен быть логичным и структурированным.""",

    "en": """You are an expert academic writer specializing in research papers and essays.
Style: formal academic, scholarly.
Avoid plagiarism — write in your own words.
Always include: introduction, main body (with sections), conclusion, references.
Text must be logical and well-structured.""",
}


class ReferatGenerator(BaseGenerator):

    async def generate(self, ctx: GenerationContext) -> str:
        """
        Referat yaratish — bitta LLM so'rovi.
        Returns: to'liq matn (markdown formatda)
        """
        system = SYSTEM_PROMPTS.get(ctx.doc_language, SYSTEM_PROMPTS["uz"])
        user_prompt = self._build_prompt(ctx)

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=user_prompt,
            temperature=0.65,
            max_tokens=6000,
            stage="referat_full",
            ctx=ctx,
        )

        ctx.add_chunk(text, tokens, cost)
        return text

    def _build_prompt(self, ctx: GenerationContext) -> str:
        lang = ctx.doc_language
        target_words = ctx.target_words

        if lang == "uz":
            prompt = f"""Quyidagi mavzuda {ctx.pages} sahifali REFERAT yozing:

Mavzu: «{ctx.topic}»
Hujjat tili: O'zbek tili
Taxminiy hajm: {target_words} so'z ({ctx.pages} sahifa)"""
            if ctx.subject:
                prompt += f"\nFan: {ctx.subject}"
            if ctx.additional_instructions:
                prompt += f"\nQo'shimcha: {ctx.additional_instructions}"

            prompt += f"""

MAJBURIY TUZILMA:
1. KIRISH (1-2 sahifa)
   - Mavzuning dolzarbligi
   - Maqsad va vazifalar
   - Foydalanilgan manbalar haqida

2. ASOSIY QISM (boblar bilan)
   2.1 [Birinchi bo'lim sarlavhasi]
   2.2 [Ikkinchi bo'lim sarlavhasi]
   2.3 [Uchinchi bo'lim sarlavhasi]

3. XULOSA (0.5-1 sahifa)
   - Asosiy xulosalar
   - Amaliy ahamiyati

4. FOYDALANILGAN ADABIYOTLAR
   - Kamida 8-10 ta manba (APA formatida)

TALABLAR:
- Akademik uslubda yozing
- Har bir bobni to'liq yoching
- Takrorlangan jumlalardan saqlaning
- O'zbek tilidagi ilmiy atamalardan foydalaning
- Raqamli ma'lumotlar va misollar keltiring"""

        elif lang == "ru":
            prompt = f"""Напишите РЕФЕРАТ на {ctx.pages} страниц по теме:

Тема: «{ctx.topic}»
Язык: Русский
Примерный объём: {target_words} слов ({ctx.pages} страниц)"""
            if ctx.subject:
                prompt += f"\nДисциплина: {ctx.subject}"
            if ctx.additional_instructions:
                prompt += f"\nДополнительно: {ctx.additional_instructions}"

            prompt += f"""

ОБЯЗАТЕЛЬНАЯ СТРУКТУРА:
1. ВВЕДЕНИЕ (1-2 страницы)
2. ОСНОВНАЯ ЧАСТЬ (разделы)
3. ЗАКЛЮЧЕНИЕ
4. СПИСОК ЛИТЕРАТУРЫ (8-10 источников, ГОСТ)

ТРЕБОВАНИЯ:
- Академический стиль
- Логичность изложения
- Конкретные примеры и данные
- Избегать плагиата"""

        else:  # en
            prompt = f"""Write a {ctx.pages}-page ESSAY/RESEARCH PAPER on the following topic:

Topic: "{ctx.topic}"
Language: English
Approximate length: {target_words} words ({ctx.pages} pages)"""
            if ctx.subject:
                prompt += f"\nSubject: {ctx.subject}"
            if ctx.additional_instructions:
                prompt += f"\nAdditional notes: {ctx.additional_instructions}"

            prompt += f"""

REQUIRED STRUCTURE:
1. INTRODUCTION (1-2 pages)
2. MAIN BODY (with sections)
3. CONCLUSION
4. REFERENCES (8-10 sources, APA format)

REQUIREMENTS:
- Formal academic style
- Logical flow
- Specific examples and data
- Original writing, no plagiarism"""

        return prompt
