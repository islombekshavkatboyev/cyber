"""
PresentationGenerator — Prezentatsiya uchun structured generator.
Natija: slaydlar ro'yxati (JSON-like), keyin PPTX generatorga uzatiladi.
"""
import json
import re
from ai.base_generator import BaseGenerator
from ai.context_builder import GenerationContext
from loguru import logger


class PresentationGenerator(BaseGenerator):
    """
    Bosqichlar:
    1. Slayd strukturasini yaratish (outline)
    2. Har bir slayd uchun kontent generatsiya
    3. Natijani list[dict] ko'rinishida qaytarish
    """

    async def generate(self, ctx: GenerationContext) -> list[dict]:
        """
        Returns: [
            {"title": "...", "content": [...], "type": "title|content|closing"},
            ...
        ]
        """
        logger.info(f"[Presentation] Boshlandi: {ctx.topic[:50]} ({ctx.pages} slayd)")

        # 1. Slayd strukturasini yaratish
        structure = await self._generate_structure(ctx)

        # 2. Har bir slayd uchun kontent
        slides = await self._generate_slide_contents(ctx, structure)

        logger.info(f"[Presentation] Tugadi: {len(slides)} ta slayd")
        return slides

    async def _generate_structure(self, ctx: GenerationContext) -> list[str]:
        """Slayd sarlavhalari ro'yxati"""
        system = self._system_prompt(ctx.doc_language)

        if ctx.doc_language == "uz":
            prompt = f"""«{ctx.topic}» mavzusidagi prezentatsiya uchun {ctx.pages} ta SLAYD SARLAVHALARINI tuzing.

Hujjat tili: O'zbek
Fan: {ctx.subject or 'Ko\'rsatilmagan'}

MAJBURIY TUZILMA:
- Slayd 1: Sarlavha slayd (mavzu, muallif)
- Slayd 2: Mundarija / Reja
- Slayd 3-{ctx.pages-2}: Asosiy kontent slaydlar
- Slayd {ctx.pages-1}: Xulosa
- Slayd {ctx.pages}: Rahmat / Savollar

Faqat raqamlangan sarlavhalar ro'yxatini chiqar:
1. ...
2. ...
..."""

        elif ctx.doc_language == "ru":
            prompt = f"""Составьте {ctx.pages} ЗАГОЛОВКОВ СЛАЙДОВ для презентации «{ctx.topic}».

Язык: Русский
Дисциплина: {ctx.subject or 'Не указана'}

СТРУКТУРА:
- Слайд 1: Титульный слайд
- Слайд 2: Содержание / План
- Слайд 3-{ctx.pages-2}: Основной контент
- Слайд {ctx.pages-1}: Заключение
- Слайд {ctx.pages}: Спасибо / Вопросы

Только пронумерованный список заголовков:
1. ...
2. ..."""

        else:
            prompt = f"""Create {ctx.pages} SLIDE TITLES for a presentation on "{ctx.topic}".

Language: English
Subject: {ctx.subject or 'Not specified'}

STRUCTURE:
- Slide 1: Title slide
- Slide 2: Table of Contents
- Slide 3-{ctx.pages-2}: Main content
- Slide {ctx.pages-1}: Conclusion
- Slide {ctx.pages}: Thank you / Questions

Output only numbered list of titles:
1. ...
2. ..."""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.4,
            max_tokens=800,
            stage="slide_structure",
            ctx=ctx,
        )

        # Sarlavhalarni parse qilish
        titles = []
        for line in text.split("\n"):
            line = line.strip()
            if line and re.match(r"^\d+[\.\)]\s*", line):
                title = re.sub(r"^\d+[\.\)]\s*", "", line).strip()
                if title:
                    titles.append(title)

        if len(titles) < 3:
            titles = self._default_titles(ctx)

        return titles[:ctx.pages]

    async def _generate_slide_contents(
        self, ctx: GenerationContext, titles: list[str]
    ) -> list[dict]:
        slides = []

        for i, title in enumerate(titles):
            slide_num = i + 1

            # Birinchi slayd — sarlavha
            if i == 0:
                slides.append({
                    "type": "title",
                    "title": ctx.topic,
                    "subtitle": title,
                    "author": ctx.student_name or "",
                    "university": ctx.university_name or "",
                    "subject": ctx.subject or "",
                    "group": ctx.group_number or "",
                    "teacher": ctx.teacher_name or "",
                    "slide_num": slide_num,
                })
                continue

            # Oxirgi slayd — yopish
            if i == len(titles) - 1:
                closing_text = {
                    "uz": "E'tiboringiz uchun rahmat!",
                    "ru": "Спасибо за внимание!",
                    "en": "Thank you for your attention!",
                }.get(ctx.doc_language, "Rahmat!")

                slides.append({
                    "type": "closing",
                    "title": closing_text,
                    "subtitle": ctx.topic,
                    "slide_num": slide_num,
                })
                continue

            # Kontent slaydlar
            content = await self._generate_single_slide(ctx, title, slide_num, len(titles))
            slides.append({
                "type": "content",
                "title": title,
                "content": content,
                "slide_num": slide_num,
            })

        return slides

    async def _generate_single_slide(
        self,
        ctx: GenerationContext,
        title: str,
        slide_num: int,
        total: int,
    ) -> list[str]:
        """Bitta slayd uchun 4-6 ta bullet point"""
        system = self._system_prompt(ctx.doc_language)

        if ctx.doc_language == "uz":
            prompt = f"""«{ctx.topic}» prezentatsiyasining {slide_num}/{total}-slaydini tayyorlang.

Slayd sarlavhasi: «{title}»

4-6 ta qisqa bullet point yozing:
- Har biri 8-15 so'z
- Aniq, informatsiyaga boy
- Slaydda ko'rsatish uchun mos

Faqat bullet pointlarni chiqar (har biri yangi qatordan, «-» bilan):"""

        elif ctx.doc_language == "ru":
            prompt = f"""Подготовьте слайд {slide_num}/{total} для презентации «{ctx.topic}».

Заголовок слайда: «{title}»

Напишите 4-6 коротких тезисов:
- Каждый 8-15 слов
- Конкретно и информативно
- Подходит для показа на слайде

Только тезисы (каждый с новой строки, начинается с «-»):"""

        else:
            prompt = f"""Prepare slide {slide_num}/{total} for a presentation on "{ctx.topic}".

Slide title: "{title}"

Write 4-6 short bullet points:
- Each 8-15 words
- Specific and informative
- Suitable for slide display

Only bullet points (each on new line, starting with "-"):"""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.65,
            max_tokens=300,
            stage=f"slide_{slide_num}",
            ctx=ctx,
        )

        # Bullet pointlarni parse qilish
        bullets = []
        for line in text.split("\n"):
            line = line.strip()
            if line.startswith("-"):
                bullet = line[1:].strip()
                if bullet:
                    bullets.append(bullet)
            elif line.startswith("•"):
                bullet = line[1:].strip()
                if bullet:
                    bullets.append(bullet)
            elif line and not line.startswith("#"):
                bullets.append(line)

        return bullets[:6] if bullets else [title]

    def _default_titles(self, ctx: GenerationContext) -> list[str]:
        if ctx.doc_language == "uz":
            return [
                ctx.topic,
                "Reja",
                "Kirish. Mavzuning dolzarbligi",
                "Asosiy tushunchalar",
                "Tahlil va tadqiqot",
                "Asosiy natijalar",
                "Amaliy ahamiyati",
                "Xulosa",
                "Foydalanilgan adabiyotlar",
                "E'tiboringiz uchun rahmat!",
            ]
        elif ctx.doc_language == "ru":
            return [
                ctx.topic, "Содержание", "Введение", "Основные понятия",
                "Анализ", "Результаты", "Практическое значение",
                "Заключение", "Литература", "Спасибо!",
            ]
        else:
            return [
                ctx.topic, "Contents", "Introduction", "Key Concepts",
                "Analysis", "Results", "Practical Significance",
                "Conclusion", "References", "Thank You!",
            ]

    @staticmethod
    def _system_prompt(lang: str) -> str:
        prompts = {
            "uz": "Siz prezentatsiya slaydlari uchun qisqa va ta'sirchan kontent yozuvchi mutaxassississiz. Matn aniq, lo'nda va ko'rsatish uchun mos bo'lsin.",
            "ru": "Вы специалист по созданию контента для презентационных слайдов. Текст должен быть чётким, лаконичным и подходящим для показа.",
            "en": "You are a specialist in creating content for presentation slides. Text should be clear, concise, and suitable for display.",
        }
        return prompts.get(lang, prompts["uz"])
