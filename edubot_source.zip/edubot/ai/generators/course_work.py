"""
CourseWorkGenerator — Kurs ishi uchun CHUNK-BASED generator.
Katta hajm (25-60 sahifa) — bosqichma-bosqich yoziladi.
"""
import asyncio
from ai.base_generator import BaseGenerator
from ai.context_builder import GenerationContext
from loguru import logger


class CourseWorkGenerator(BaseGenerator):
    """
    Chunk architecture:
    1. Outline (reja)
    2. Introduction (kirish)
    3. Chapter 1 ... N
    4. Conclusion (xulosa)
    5. References (adabiyotlar)
    """

    async def generate(self, ctx: GenerationContext) -> str:
        logger.info(f"[CourseWork] Boshlandi: {ctx.topic[:50]} ({ctx.pages} sahifa)")

        # 1. Reja
        outline = await self._generate_outline(ctx)
        ctx.outline = outline
        chapters = self._parse_chapters(outline)
        logger.info(f"[CourseWork] Reja: {len(chapters)} ta bob")

        # 2. Kirish
        intro = await self._generate_intro(ctx)
        ctx.add_chunk(intro)
        await asyncio.sleep(1)

        # 3. Boblar
        for i, chapter_title in enumerate(chapters, 1):
            logger.info(f"[CourseWork] {i}-bob yozilmoqda: {chapter_title[:40]}")
            chapter_text = await self._generate_chapter(ctx, chapter_title, i, len(chapters))
            ctx.add_chunk(chapter_text)
            await asyncio.sleep(1.5)

        # 4. Xulosa
        conclusion = await self._generate_conclusion(ctx)
        ctx.add_chunk(conclusion)
        await asyncio.sleep(1)

        # 5. Adabiyotlar
        references = await self._generate_references(ctx)
        ctx.add_chunk(references)

        full_text = ctx.get_full_text()
        logger.info(
            f"[CourseWork] Tugadi. Jami: {ctx.total_tokens_used} token, "
            f"${ctx.total_cost_usd:.4f}"
        )
        return full_text

    async def _generate_outline(self, ctx: GenerationContext) -> str:
        system = self._system_prompt(ctx.doc_language)
        prompt = self._outline_prompt(ctx)

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.3,
            max_tokens=1200,
            stage="outline",
            ctx=ctx,
        )
        return text

    async def _generate_intro(self, ctx: GenerationContext) -> str:
        system = self._system_prompt(ctx.doc_language)
        words = max(400, ctx.words_per_page * 2)

        if ctx.doc_language == "uz":
            prompt = f"""KURS ISHI: «{ctx.topic}»
REJA:
{ctx.outline}

Faqat KIRISH qismini yozing ({words} so'z):
- Mavzuning dolzarbligi
- Tadqiqot maqsadi va vazifalari
- Tadqiqot ob'ekti va predmeti
- Ishning tuzilishi haqida qisqacha

Boshlanishi: "Kirish" sarlavhasi bilan boshlang."""

        elif ctx.doc_language == "ru":
            prompt = f"""КУРСОВАЯ РАБОТА: «{ctx.topic}»
ПЛАН:
{ctx.outline}

Напишите только ВВЕДЕНИЕ ({words} слов):
- Актуальность темы
- Цель и задачи исследования
- Объект и предмет исследования
- Структура работы

Начните с заголовка "Введение"."""

        else:
            prompt = f"""COURSE WORK: "{ctx.topic}"
OUTLINE:
{ctx.outline}

Write only the INTRODUCTION ({words} words):
- Relevance of the topic
- Research objectives and goals
- Object and subject of research
- Structure of the work

Start with "Introduction" heading."""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.65,
            max_tokens=2000,
            stage="introduction",
            ctx=ctx,
        )
        return text

    async def _generate_chapter(
        self,
        ctx: GenerationContext,
        chapter_title: str,
        chapter_num: int,
        total_chapters: int,
    ) -> str:
        system = self._system_prompt(ctx.doc_language)

        # Har bob uchun taxminiy so'z soni
        body_pages = ctx.pages - 4  # kirish + xulosa + adabiyotlar uchun -4
        words_per_chapter = max(500, (body_pages * ctx.words_per_page) // total_chapters)

        recent_context = ctx.get_recent_context(last_n=1)

        if ctx.doc_language == "uz":
            prompt = f"""KURS ISHI: «{ctx.topic}»
Fan: {ctx.subject or 'Ko\'rsatilmagan'}

UMUMIY REJA:
{ctx.outline}

OLDINGI QISM XULASASI:
{recent_context if recent_context else "Bu birinchi bob."}

HOZIR YOZING: {chapter_num}-BOB — {chapter_title}
Hajm: taxminan {words_per_chapter} so'z

TALABLAR:
- Bob sarlavhasi bilan boshlang
- Kichik bo'limlarni ({chapter_num}.1, {chapter_num}.2...) yozing
- Oldingi qismlar bilan mantiqiy bog'lanishni saqlang
- Misollar, raqamlar, faktlar keltiring
- Akademik uslub"""

        elif ctx.doc_language == "ru":
            prompt = f"""КУРСОВАЯ РАБОТА: «{ctx.topic}»
Дисциплина: {ctx.subject or 'Не указана'}

ОБЩИЙ ПЛАН:
{ctx.outline}

ПРЕДЫДУЩИЙ КОНТЕКСТ:
{recent_context if recent_context else "Это первая глава."}

СЕЙЧАС ПИШИТЕ: ГЛАВА {chapter_num} — {chapter_title}
Объём: примерно {words_per_chapter} слов

ТРЕБОВАНИЯ:
- Начните с заголовка главы
- Пишите подразделы ({chapter_num}.1, {chapter_num}.2...)
- Сохраняйте логическую связь с предыдущими частями
- Приводите примеры, цифры, факты
- Академический стиль"""

        else:
            prompt = f"""COURSE WORK: "{ctx.topic}"
Subject: {ctx.subject or 'Not specified'}

OUTLINE:
{ctx.outline}

PREVIOUS CONTEXT:
{recent_context if recent_context else "This is the first chapter."}

NOW WRITE: CHAPTER {chapter_num} — {chapter_title}
Length: approximately {words_per_chapter} words

REQUIREMENTS:
- Start with chapter heading
- Include subsections ({chapter_num}.1, {chapter_num}.2...)
- Maintain logical connection with previous parts
- Include examples, statistics, facts
- Academic style"""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.7,
            max_tokens=4000,
            stage=f"chapter_{chapter_num}",
            ctx=ctx,
        )
        return text

    async def _generate_conclusion(self, ctx: GenerationContext) -> str:
        system = self._system_prompt(ctx.doc_language)
        words = max(300, ctx.words_per_page)

        # Barcha boblardan qisqa xulosa
        all_content = ctx.get_full_text()[:2000]

        if ctx.doc_language == "uz":
            prompt = f"""KURS ISHI: «{ctx.topic}»

YOZILGAN MATERIAL (qisqa):
{all_content}...

Faqat XULOSA qismini yozing ({words} so'z):
- Asosiy xulosalar (har bob bo'yicha)
- Maqsadga erishilganligi
- Amaliy ahamiyati
- Kelajakdagi tadqiqot yo'nalishlari

"Xulosa" sarlavhasi bilan boshlang."""

        elif ctx.doc_language == "ru":
            prompt = f"""КУРСОВАЯ РАБОТА: «{ctx.topic}»

НАПИСАННЫЙ МАТЕРИАЛ (кратко):
{all_content}...

Напишите только ЗАКЛЮЧЕНИЕ ({words} слов):
- Основные выводы (по каждой главе)
- Достижение цели
- Практическая значимость
- Направления дальнейших исследований

Начните с "Заключение"."""

        else:
            prompt = f"""COURSE WORK: "{ctx.topic}"

WRITTEN MATERIAL (brief):
{all_content}...

Write only CONCLUSION ({words} words):
- Main findings (per chapter)
- Achievement of objectives
- Practical significance
- Future research directions

Start with "Conclusion"."""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.5,
            max_tokens=1500,
            stage="conclusion",
            ctx=ctx,
        )
        return text

    async def _generate_references(self, ctx: GenerationContext) -> str:
        system = self._system_prompt(ctx.doc_language)

        if ctx.doc_language == "uz":
            prompt = f"""«{ctx.topic}» mavzusidagi kurs ishi uchun ADABIYOTLAR RO'YXATINI tuzing.

Fan: {ctx.subject or 'Umumiy'}
Kamida 15 ta manba.

Format (GOST yoki APA):
1. Kitoblar (mualliflar, nom, nashriyot, yil)
2. Maqolalar (jurnal maqolalari)
3. Internet manbalar (URL bilan)
4. O'zbek tilidagi manbalar ham bo'lsin

"Foydalanilgan adabiyotlar ro'yxati" sarlavhasi bilan boshlang."""

        elif ctx.doc_language == "ru":
            prompt = f"""Составьте СПИСОК ЛИТЕРАТУРЫ для курсовой работы по теме «{ctx.topic}».

Дисциплина: {ctx.subject or 'Общая'}
Минимум 15 источников, ГОСТ оформление.

Включите: монографии, научные статьи, интернет-источники.
Начните с "Список использованной литературы"."""

        else:
            prompt = f"""Create a REFERENCES LIST for a course work on "{ctx.topic}".

Subject: {ctx.subject or 'General'}
Minimum 15 sources, APA format.

Include: books, journal articles, online sources.
Start with "References"."""

        text, tokens, cost = await self._call_llm(
            system_prompt=system,
            user_prompt=prompt,
            temperature=0.3,
            max_tokens=1500,
            stage="references",
            ctx=ctx,
        )
        return text

    def _parse_chapters(self, outline: str) -> list[str]:
        """Rejadan bob sarlavhalarini ajratib olish"""
        chapters = []
        lines = outline.split("\n")
        for line in lines:
            line = line.strip()
            # BOB, ГЛАВА, CHAPTER, yoki raqam bilan boshlanuvchi
            if any([
                line.upper().startswith("BOB"),
                line.upper().startswith("ГЛАВА"),
                line.upper().startswith("CHAPTER"),
                (len(line) > 3 and line[0].isdigit() and line[1] in ".)"),
            ]):
                # Faqat asosiy boblar (kichik bo'limlar emas)
                if not any(c in line for c in ["1.", "2.", "3.", "4.", "5."] if line.count(".") > 1):
                    chapters.append(line)

        # Agar topilmasa — standart boblar
        if not chapters:
            chapters = [
                "Nazariy asoslar",
                "Tahlil va tadqiqot",
                "Amaliy qism va tavsiyalar",
            ]

        return chapters[:5]  # Maksimal 5 ta bob

    @staticmethod
    def _system_prompt(lang: str) -> str:
        prompts = {
            "uz": """Siz o'zbek tilidagi kurs ishi yozuvchi akademik mutaxassississiz.
Uslub: rasmiy-ilmiy. Har bir qismni to'liq va sifatli yozing.
Plagiatga yo'l qo'ymang. Mantiqiy ketma-ketlikni saqlang.""",

            "ru": """Вы — академический специалист по написанию курсовых работ на русском языке.
Стиль: официально-научный. Пишите каждую часть полно и качественно.
Избегайте плагиата. Сохраняйте логическую последовательность.""",

            "en": """You are an academic specialist in writing course works in English.
Style: formal-scientific. Write each section completely and with quality.
Avoid plagiarism. Maintain logical sequence.""",
        }
        return prompts.get(lang, prompts["uz"])
