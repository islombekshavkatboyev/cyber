"""
GenerationContext — barcha generatorlar uchun umumiy kontekst ob'ekti.
"""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class GenerationContext:
    """
    Buyurtma ma'lumotlarini generatorlarga uzatish uchun DTOi.
    """
    order_id: str
    service_type: str          # independent | referat | presentation | course_work | diploma
    topic: str
    doc_language: str          # uz | ru | en
    pages: int
    university_format: bool

    # Universitet ma'lumotlari
    university_name: Optional[str] = None
    faculty: Optional[str] = None
    subject: Optional[str] = None
    student_name: Optional[str] = None
    teacher_name: Optional[str] = None
    group_number: Optional[str] = None
    additional_instructions: Optional[str] = None

    # Generatsiya jarayonida to'ldiriladigan maydonlar
    outline: str = ""
    generated_chunks: list = field(default_factory=list)   # List[str]
    total_tokens_used: int = 0
    total_cost_usd: float = 0.0

    # ─── Qulay xususiyatlar ───────────────────────────────
    @property
    def language_label(self) -> str:
        return {"uz": "o'zbek", "ru": "русский", "en": "English"}.get(
            self.doc_language, "o'zbek"
        )

    @property
    def words_per_page(self) -> int:
        """Har sahifa uchun taxminiy so'zlar soni"""
        return {"uz": 230, "ru": 250, "en": 270}.get(self.doc_language, 250)

    @property
    def target_words(self) -> int:
        return self.pages * self.words_per_page

    @property
    def is_long_document(self) -> bool:
        return self.service_type in ("course_work", "diploma")

    def get_recent_context(self, last_n: int = 2) -> str:
        """
        Chunk arxitekturasi uchun: oldingi chunklar qisqacha xulasasi.
        Context window ni tejash uchun faqat oxirgi N ta chunk.
        """
        if not self.generated_chunks:
            return ""
        recent = self.generated_chunks[-last_n:]
        summaries = []
        for i, chunk in enumerate(recent):
            preview = chunk[:400].replace("\n", " ")
            summaries.append(f"[Oldingi qism {i+1}]: {preview}...")
        return "\n\n".join(summaries)

    def add_chunk(self, content: str, tokens: int = 0, cost: float = 0.0):
        self.generated_chunks.append(content)
        self.total_tokens_used += tokens
        self.total_cost_usd += cost

    def get_full_text(self) -> str:
        return "\n\n".join(self.generated_chunks)

    @classmethod
    def from_order(cls, order) -> "GenerationContext":
        """SQLAlchemy Order modelidan yaratish"""
        return cls(
            order_id=str(order.id),
            service_type=order.service_type,
            topic=order.topic,
            doc_language=order.doc_language,
            pages=order.pages,
            university_format=order.university_format,
            university_name=order.university_name,
            faculty=order.faculty,
            subject=order.subject,
            student_name=order.student_name,
            teacher_name=order.teacher_name,
            group_number=order.group_number,
            additional_instructions=order.additional_instructions,
        )
