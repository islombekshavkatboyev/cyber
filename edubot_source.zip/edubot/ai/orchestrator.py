"""
AIOrchestrator — barcha generatorlarni boshqaruvchi markaziy modul.
Celery worker dan chaqiriladi.
"""
from loguru import logger

from ai.context_builder import GenerationContext
from ai.generators import (
    CourseWorkGenerator,
    DiplomaGenerator,
    IndependentGenerator,
    PresentationGenerator,
    ReferatGenerator,
)


class AIOrchestrator:
    """
    Xizmat turiga qarab to'g'ri generatorni tanlaydi va ishga tushiradi.
    """

    def __init__(self):
        self.generators = {
            "referat": ReferatGenerator(),
            "independent": IndependentGenerator(),
            "course_work": CourseWorkGenerator(),
            "diploma": DiplomaGenerator(),
            "presentation": PresentationGenerator(),
        }

    async def generate(self, ctx: GenerationContext) -> str | list[dict]:
        """
        Asosiy generatsiya metodi.

        Returns:
            - str — DOCX/PDF uchun matn (referat, independent, course_work, diploma)
            - list[dict] — PPTX uchun slaydlar (presentation)
        """
        service = ctx.service_type
        generator = self.generators.get(service)

        if not generator:
            raise ValueError(f"Noto'g'ri xizmat turi: {service}")

        logger.info(
            f"[Orchestrator] Generatsiya boshlandi: "
            f"service={service} lang={ctx.doc_language} "
            f"pages={ctx.pages} order_id={ctx.order_id}"
        )

        result = await generator.generate(ctx)

        logger.info(
            f"[Orchestrator] Tugadi: order_id={ctx.order_id} "
            f"tokens={ctx.total_tokens_used} cost=${ctx.total_cost_usd:.4f}"
        )

        return result

    @staticmethod
    def get_estimated_time(service_type: str, pages: int) -> str:
        """Taxminiy generatsiya vaqti (foydalanuvchiga ko'rsatish uchun)"""
        times = {
            "independent":  "3–5 daqiqa",
            "referat":      "5–10 daqiqa",
            "presentation": "3–7 daqiqa",
            "course_work":  "10–20 daqiqa",
            "diploma":      "20–40 daqiqa",
        }
        return times.get(service_type, "5–15 daqiqa")
