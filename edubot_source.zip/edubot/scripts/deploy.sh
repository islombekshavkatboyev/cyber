#!/bin/bash
# Production deploy skripti

set -e

echo "🚀 EduBot deploy boshlandi..."

# Git pull
git pull origin main

# Docker build
docker-compose -f docker-compose.yml build --no-cache

# DB migratsiyalar
docker-compose run --rm bot alembic upgrade head

# Containerlarni qayta ishga tushirish
docker-compose up -d --force-recreate

echo "✅ Deploy muvaffaqiyatli!"
docker-compose ps
