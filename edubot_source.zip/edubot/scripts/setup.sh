#!/bin/bash
# EduBot — boshlang'ich sozlash skripti

set -e

echo "🚀 EduBot sozlanmoqda..."

# .env fayl
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✅ .env fayl yaratildi. Iltimos, .env faylini to'ldiring!"
fi

# Temp papka
mkdir -p /tmp/edubot logs

# Docker containers
echo "🐳 Docker containerlar ishga tushirilmoqda..."
docker-compose up -d postgres redis minio

# Kutish
echo "⏳ DB tayyorlanishi kutilmoqda..."
sleep 5

# DB migratsiyalar
echo "📦 DB migratsiyalar..."
docker-compose run --rm bot alembic upgrade head

echo "✅ Sozlash tugadi!"
echo ""
echo "Keyingi qadamlar:"
echo "  1. .env faylini to'ldiring (BOT_TOKEN, OPENAI_API_KEY va boshqalar)"
echo "  2. docker-compose up -d"
echo "  3. Bot ishlayotganini tekshiring: docker-compose logs -f bot"
