"""
PaymentService — barcha payment providerlar uchun fasad.
"""
from decimal import Decimal
from typing import Optional

from bot.config import settings


class PaymentService:

    async def create_invoice(
        self,
        provider: str,
        order_id: str,
        amount: Decimal,
        user_id: int,
    ) -> dict:
        """
        Invoice yaratish.
        Returns: {"invoice_url": str, "transaction_id": str}
        """
        if provider == "click":
            return await self._create_click_invoice(order_id, amount)
        elif provider == "payme":
            return await self._create_payme_invoice(order_id, amount)
        elif provider == "humo":
            return await self._create_humo_invoice(order_id, amount)
        else:
            raise ValueError(f"Noto'g'ri provider: {provider}")

    async def check_status(
        self,
        provider: str,
        transaction_id: Optional[str],
    ) -> str:
        """
        To'lov holatini tekshirish.
        Returns: "paid" | "pending" | "failed" | "expired"
        """
        if not transaction_id:
            return "pending"

        if provider == "click":
            return await self._check_click_status(transaction_id)
        elif provider == "payme":
            return await self._check_payme_status(transaction_id)
        elif provider == "humo":
            return await self._check_humo_status(transaction_id)
        return "pending"

    # ─── Click ────────────────────────────────────────────
    async def _create_click_invoice(self, order_id: str, amount: Decimal) -> dict:
        from payment.providers.click import ClickProvider
        provider = ClickProvider(
            service_id=settings.click_service_id,
            merchant_id=settings.click_merchant_id,
            secret_key=settings.click_secret_key,
        )
        return await provider.create_invoice(
            order_id=order_id,
            amount=amount,
            return_url=f"{settings.webhook_host}/payment/success",
        )

    async def _check_click_status(self, transaction_id: str) -> str:
        from payment.providers.click import ClickProvider
        provider = ClickProvider(
            service_id=settings.click_service_id,
            merchant_id=settings.click_merchant_id,
            secret_key=settings.click_secret_key,
        )
        return await provider.check_status(transaction_id)

    # ─── Payme ────────────────────────────────────────────
    async def _create_payme_invoice(self, order_id: str, amount: Decimal) -> dict:
        from payment.providers.payme import PaymeProvider
        provider = PaymeProvider(
            merchant_id=settings.payme_merchant_id,
            key=settings.payme_key,
        )
        return await provider.create_invoice(order_id=order_id, amount=amount)

    async def _check_payme_status(self, transaction_id: str) -> str:
        from payment.providers.payme import PaymeProvider
        provider = PaymeProvider(
            merchant_id=settings.payme_merchant_id,
            key=settings.payme_key,
        )
        return await provider.check_status(transaction_id)

    # ─── Humo ─────────────────────────────────────────────
    async def _create_humo_invoice(self, order_id: str, amount: Decimal) -> dict:
        from payment.providers.humo import HumoProvider
        provider = HumoProvider(
            merchant_id=settings.humo_merchant_id,
            secret_key=settings.humo_secret_key,
            api_url=settings.humo_api_url,
        )
        return await provider.create_invoice(order_id=order_id, amount=amount)

    async def _check_humo_status(self, transaction_id: str) -> str:
        from payment.providers.humo import HumoProvider
        provider = HumoProvider(
            merchant_id=settings.humo_merchant_id,
            secret_key=settings.humo_secret_key,
            api_url=settings.humo_api_url,
        )
        return await provider.check_status(transaction_id)
