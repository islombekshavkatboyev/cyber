from decimal import Decimal
from bot.config import settings


# Sahifalar cheklovi
PAGE_LIMITS: dict[str, tuple[int, int]] = {
    "independent":  (5,  30),
    "referat":      (10, 40),
    "presentation": (10, 40),
    "course_work":  (25, 60),
    "diploma":      (60, 100),
}

# Sahifa boshiga narx (UZS)
PRICE_PER_PAGE: dict[str, Decimal] = {
    "independent":  Decimal("2000"),
    "referat":      Decimal("2500"),
    "presentation": Decimal("3000"),
    "course_work":  Decimal("3000"),
    "diploma":      Decimal("4000"),
}

# Universitet formati qo'shimcha narxi
FORMAT_EXTRA: dict[str, Decimal] = {
    "independent":  Decimal("5000"),
    "referat":      Decimal("5000"),
    "presentation": Decimal("0"),
    "course_work":  Decimal("10000"),
    "diploma":      Decimal("20000"),
}


def get_base_price(service_type: str) -> Decimal:
    prices = {
        "independent":  Decimal(str(settings.price_independent)),
        "referat":      Decimal(str(settings.price_referat)),
        "presentation": Decimal(str(settings.price_presentation)),
        "course_work":  Decimal(str(settings.price_course_work)),
        "diploma":      Decimal(str(settings.price_diploma)),
    }
    return prices.get(service_type, Decimal("0"))


def calculate_price(
    service_type: str,
    pages: int,
    university_format: bool = False,
) -> Decimal:
    """
    Buyurtma narxini hisoblaydi.

    Formula: base_price + (pages * price_per_page) + [format_extra]
    """
    base = get_base_price(service_type)
    per_page = PRICE_PER_PAGE.get(service_type, Decimal("0"))
    extra = FORMAT_EXTRA.get(service_type, Decimal("0")) if university_format else Decimal("0")

    total = base + (per_page * pages) + extra
    return total


def get_price_info(service_type: str) -> dict:
    """Xizmat narx ma'lumotlari"""
    min_p, max_p = PAGE_LIMITS.get(service_type, (5, 40))
    return {
        "base_price": get_base_price(service_type),
        "price_per_page": PRICE_PER_PAGE.get(service_type, Decimal("0")),
        "min_pages": min_p,
        "max_pages": max_p,
        "min_price": calculate_price(service_type, min_p, False),
        "max_price": calculate_price(service_type, max_p, True),
    }
