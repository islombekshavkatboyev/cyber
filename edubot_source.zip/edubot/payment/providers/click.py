"""
Click UZ Payment Provider
API docs: https://docs.click.uz
"""
import hashlib
import hmac
import time
from decimal import Decimal
from typing import Optional

import httpx
from loguru import logger


class ClickProvider:

    BASE_URL = "https://api.click.uz/v2/merchant"

    def __init__(self, service_id: str, merchant_id: str, secret_key: str):
        self.service_id = service_id
        self.merchant_id = merchant_id
        self.secret_key = secret_key

    async def create_invoice(
        self,
        order_id: str,
        amount: Decimal,
        return_url: str = "",
    ) -> dict:
        """
        Click invoice yaratish.
        Returns: {"invoice_url": str, "transaction_id": str}
        """
        # Click checkout URL (redirect usuli)
        amount_tiyin = int(amount * 100)  # tiyin ga aylantirish

        invoice_url = (
            f"https://my.click.uz/services/pay"
            f"?service_id={self.service_id}"
            f"&merchant_id={self.merchant_id}"
            f"&amount={amount_tiyin / 100}"
            f"&transaction_param={order_id}"
            f"&return_url={return_url}"
        )

        logger.info(f"[Click] Invoice yaratildi: order_id={order_id} amount={amount}")

        return {
            "invoice_url": invoice_url,
            "transaction_id": f"click_{order_id}_{int(time.time())}",
            "provider": "click",
        }

    async def check_status(self, transaction_id: str) -> str:
        """
        To'lov holatini tekshirish.
        Returns: "paid" | "pending" | "failed" | "expired"
        """
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                sign_time = int(time.time())
                sign_string = f"{sign_time}{self.secret_key}"
                sign = hashlib.md5(sign_string.encode()).hexdigest()

                response = await client.get(
                    f"{self.BASE_URL}/check_payment",
                    params={
                        "service_id": self.service_id,
                        "payment_id": transaction_id,
                        "sign_time": sign_time,
                        "sign_string": sign,
                    },
                )
                data = response.json()

                if data.get("error") == 0:
                    status = data.get("payment_status", -1)
                    # Click status: 2 = to'langan
                    if status == 2:
                        return "paid"
                    elif status in (0, 1):
                        return "pending"
                    else:
                        return "failed"

                return "pending"

        except Exception as e:
            logger.error(f"[Click] Status tekshirish xatolik: {e}")
            return "pending"

    def verify_webhook(self, data: dict) -> bool:
        """Click webhook imzosini tekshirish"""
        try:
            received_sign = data.get("sign_string", "")
            sign_time = data.get("sign_time", "")

            sign_string = (
                f"{data.get('click_trans_id', '')}"
                f"{self.service_id}"
                f"{self.secret_key}"
                f"{data.get('merchant_trans_id', '')}"
                f"{data.get('amount', '')}"
                f"{data.get('action', '')}"
                f"{sign_time}"
            )
            expected = hashlib.md5(sign_string.encode()).hexdigest()
            return hmac.compare_digest(received_sign, expected)
        except Exception:
            return False

    def handle_prepare(self, data: dict) -> dict:
        """Click PREPARE so'rovi (action=0)"""
        order_id = data.get("merchant_trans_id", "")
        # Buyurtma mavjudligini tekshirish kerak
        return {
            "click_trans_id": data.get("click_trans_id"),
            "merchant_trans_id": order_id,
            "merchant_prepare_id": int(time.time()),
            "error": 0,
            "error_note": "Success",
        }

    def handle_complete(self, data: dict) -> dict:
        """Click COMPLETE so'rovi (action=1)"""
        return {
            "click_trans_id": data.get("click_trans_id"),
            "merchant_trans_id": data.get("merchant_trans_id"),
            "merchant_confirm_id": int(time.time()),
            "error": 0,
            "error_note": "Success",
        }
