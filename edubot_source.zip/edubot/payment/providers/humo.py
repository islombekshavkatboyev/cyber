"""
Humo Payment Provider
"""
import hashlib
import hmac
import time
from decimal import Decimal

import httpx
from loguru import logger


class HumoProvider:

    def __init__(self, merchant_id: str, secret_key: str, api_url: str):
        self.merchant_id = merchant_id
        self.secret_key = secret_key
        self.api_url = api_url.rstrip("/")

    async def create_invoice(
        self,
        order_id: str,
        amount: Decimal,
    ) -> dict:
        """
        Humo invoice yaratish.
        Returns: {"invoice_url": str, "transaction_id": str}
        """
        try:
            timestamp = int(time.time())
            sign = self._generate_sign(order_id, amount, timestamp)

            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.post(
                    f"{self.api_url}/invoice/create",
                    json={
                        "merchant_id": self.merchant_id,
                        "order_id": order_id,
                        "amount": int(amount * 100),
                        "currency": "UZS",
                        "timestamp": timestamp,
                        "sign": sign,
                        "description": f"EduBot buyurtma #{order_id[:8]}",
                    },
                    headers={"Content-Type": "application/json"},
                )

                data = response.json()

                if data.get("status") == "success":
                    logger.info(f"[Humo] Invoice yaratildi: order_id={order_id}")
                    return {
                        "invoice_url": data.get("payment_url", ""),
                        "transaction_id": data.get("invoice_id", f"humo_{order_id}"),
                        "provider": "humo",
                    }

        except Exception as e:
            logger.error(f"[Humo] Invoice xatolik: {e}")

        # Fallback: oddiy redirect URL
        return {
            "invoice_url": f"{self.api_url}/pay/{order_id}",
            "transaction_id": f"humo_{order_id}_{int(time.time())}",
            "provider": "humo",
        }

    async def check_status(self, transaction_id: str) -> str:
        """To'lov holatini tekshirish"""
        try:
            timestamp = int(time.time())
            sign = hmac.new(
                self.secret_key.encode(),
                f"{transaction_id}{timestamp}".encode(),
                hashlib.sha256,
            ).hexdigest()

            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.get(
                    f"{self.api_url}/invoice/status",
                    params={
                        "merchant_id": self.merchant_id,
                        "invoice_id": transaction_id,
                        "timestamp": timestamp,
                        "sign": sign,
                    },
                )
                data = response.json()

                status = data.get("payment_status", "")
                if status in ("PAID", "SUCCESS", "COMPLETED"):
                    return "paid"
                elif status in ("FAILED", "REJECTED", "CANCELLED"):
                    return "failed"
                elif status in ("EXPIRED",):
                    return "expired"
                return "pending"

        except Exception as e:
            logger.error(f"[Humo] Status tekshirish xatolik: {e}")
            return "pending"

    def verify_webhook(self, data: dict, signature: str) -> bool:
        """Webhook imzosini tekshirish"""
        try:
            payload = f"{data.get('invoice_id', '')}{data.get('amount', '')}{data.get('status', '')}"
            expected = hmac.new(
                self.secret_key.encode(),
                payload.encode(),
                hashlib.sha256,
            ).hexdigest()
            return hmac.compare_digest(signature, expected)
        except Exception:
            return False

    def _generate_sign(self, order_id: str, amount: Decimal, timestamp: int) -> str:
        """HMAC-SHA256 imzo"""
        payload = f"{self.merchant_id}{order_id}{int(amount * 100)}{timestamp}"
        return hmac.new(
            self.secret_key.encode(),
            payload.encode(),
            hashlib.sha256,
        ).hexdigest()
