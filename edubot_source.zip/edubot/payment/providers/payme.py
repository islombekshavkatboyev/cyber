"""
Payme Business Payment Provider
API docs: https://developer.help.paycom.uz
"""
import base64
import time
from decimal import Decimal
from typing import Optional

import httpx
from loguru import logger


class PaymeProvider:

    CHECKOUT_URL = "https://checkout.paycom.uz"
    API_URL = "https://checkout.paycom.uz/api"

    def __init__(self, merchant_id: str, key: str, test_mode: bool = False):
        self.merchant_id = merchant_id
        self.key = key
        self.test_mode = test_mode

    async def create_invoice(
        self,
        order_id: str,
        amount: Decimal,
    ) -> dict:
        """
        Payme checkout URL yaratish.
        Returns: {"invoice_url": str, "transaction_id": str}
        """
        # Payme: tiyin da (1 so'm = 100 tiyin)
        amount_tiyin = int(amount * 100)

        # Base64 encode qilish
        params = (
            f"m={self.merchant_id};"
            f"ac.order_id={order_id};"
            f"a={amount_tiyin};"
            f"c=https://t.me"  # callback URL
        )
        encoded = base64.b64encode(params.encode()).decode()
        invoice_url = f"{self.CHECKOUT_URL}/{encoded}"

        logger.info(f"[Payme] Invoice yaratildi: order_id={order_id} amount={amount}")

        return {
            "invoice_url": invoice_url,
            "transaction_id": f"payme_{order_id}_{int(time.time())}",
            "provider": "payme",
        }

    async def check_status(self, transaction_id: str) -> str:
        """To'lov holatini CheckTransaction orqali tekshirish"""
        try:
            # transaction_id dan payme trans ID ni ajratib olish
            if transaction_id.startswith("payme_"):
                parts = transaction_id.split("_")
                if len(parts) >= 2:
                    order_id = parts[1]
                else:
                    return "pending"
            else:
                order_id = transaction_id

            auth = base64.b64encode(
                f"Paycom:{self.key}".encode()
            ).decode()

            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.post(
                    self.API_URL,
                    json={
                        "id": int(time.time()),
                        "method": "CheckTransaction",
                        "params": {
                            "id": transaction_id,
                        },
                    },
                    headers={
                        "X-Auth": auth,
                        "Content-Type": "application/json",
                    },
                )
                data = response.json()

                if "result" in data:
                    state = data["result"].get("transaction", {}).get("state", 0)
                    # Payme states: 2 = to'langan, -1/-2 = bekor, 1 = kutilmoqda
                    if state == 2:
                        return "paid"
                    elif state in (-1, -2):
                        return "failed"
                    elif state == 4:
                        return "expired"
                    else:
                        return "pending"

                return "pending"

        except Exception as e:
            logger.error(f"[Payme] Status tekshirish xatolik: {e}")
            return "pending"

    def verify_rpc_auth(self, auth_header: str) -> bool:
        """Basic auth tekshirish"""
        try:
            scheme, credentials = auth_header.split(" ", 1)
            if scheme.lower() != "basic":
                return False
            decoded = base64.b64decode(credentials).decode()
            _, password = decoded.split(":", 1)
            return password == self.key
        except Exception:
            return False

    def handle_check_perform_transaction(self, params: dict) -> dict:
        """CheckPerformTransaction — buyurtma mavjudligini tekshirish"""
        order_id = params.get("account", {}).get("order_id", "")
        # Bu yerda DB dan buyurtmani tekshirish kerak
        return {
            "allow": True,
            "additional": {
                "title": f"Buyurtma #{order_id[:8]}",
            },
        }

    def handle_create_transaction(self, params: dict) -> dict:
        """CreateTransaction — yangi tranzaksiya yaratish"""
        return {
            "create_time": int(time.time() * 1000),
            "transaction": params.get("id", ""),
            "state": 1,
            "additional": {},
        }

    def handle_perform_transaction(self, params: dict) -> dict:
        """PerformTransaction — to'lovni tasdiqlash"""
        return {
            "transaction": params.get("id", ""),
            "perform_time": int(time.time() * 1000),
            "state": 2,
        }

    def handle_cancel_transaction(self, params: dict) -> dict:
        """CancelTransaction — tranzaksiyani bekor qilish"""
        return {
            "transaction": params.get("id", ""),
            "cancel_time": int(time.time() * 1000),
            "state": -1,
        }

    def handle_check_transaction(self, params: dict) -> dict:
        """CheckTransaction — tranzaksiya holatini tekshirish"""
        return {
            "create_time": int(time.time() * 1000),
            "perform_time": 0,
            "cancel_time": 0,
            "transaction": params.get("id", ""),
            "state": 1,
            "reason": None,
        }
