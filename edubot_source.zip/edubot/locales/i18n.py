"""
i18n — Lokalizatsiya yordamchi moduli.
Faqat o'zbek tili ishlatiladi (bot interfeysi uchun).

Ishlatish:
    from locales.i18n import t
    text = t("start.welcome")
    text = t("order.confirm_service", service="Referat")
"""
import json
from pathlib import Path
from typing import Any


_locale_cache: dict = {}


def _load_locale() -> dict:
    if "uz" not in _locale_cache:
        path = Path(__file__).parent / "uz.json"
        with open(path, encoding="utf-8") as f:
            _locale_cache["uz"] = json.load(f)
    return _locale_cache["uz"]


def t(key: str, **kwargs: Any) -> str:
    """
    Kalit bo'yicha matnni qaytaradi.

    key: nuqta bilan ajratilgan yo'l (masalan: "start.welcome")
    kwargs: shablondagi o'zgaruvchilar

    Misol:
        t("order.confirm_service", service="Referat")
        t("payment.invoice_created", amount="25000", provider="Click")
    """
    data = _load_locale()
    keys = key.split(".")
    value = data

    for k in keys:
        if isinstance(value, dict) and k in value:
            value = value[k]
        else:
            return f"[{key}]"  # Topilmagan kalit

    if isinstance(value, str) and kwargs:
        try:
            return value.format(**kwargs)
        except KeyError:
            return value

    return str(value) if not isinstance(value, str) else value


def get_service_name(service_type: str) -> str:
    """Xizmat turining o'zbekcha nomi"""
    return t(f"service_names.{service_type}")


def get_doc_language_name(lang: str) -> str:
    """Hujjat tili nomi"""
    return t(f"doc_languages.{lang}")


def get_status_name(status: str) -> str:
    """Holat nomi"""
    return t(f"orders.status_{status}")


def get_format_name(university_format: bool) -> str:
    """Format nomi"""
    key = "university" if university_format else "simple"
    return t(f"format_names.{key}")


def format_price(amount: int | float) -> str:
    """Narxni formatlash: 25000 → '25 000'"""
    return f"{int(amount):,}".replace(",", " ")
